"""F004–F008 — issue queries (list / roots / tree / get).

This first functional release queries the **live** Jira API (cache-backed reads
and ``--no-cache`` semantics arrive with sync, F010). ``--json`` is a render
concern owned by the CLI, not here. People filters accept names or account-ids
(names resolved via the account store, F003); unknown values pass through as
account-ids so raw ids work without a store entry.

Implemented: ``list`` (by assignee(s) / raw JQL / created-range) and ``get``.
``roots``/``tree`` (F006) stay stubbed.
"""

from __future__ import annotations

from typing import Any

from . import account
from .errors import JiraHelperError

Issue = dict[str, Any]

# Fields requested from Jira and projected onto every Issue dict.
_FIELDS = ["summary", "status", "issuetype", "assignee", "project", "parent", "created", "updated"]
_PAGE_SIZE = 100
# Safety cap against the known runaway-nextPageToken bug (~10k issues at this size).
_MAX_PAGES = 100


def _jql_quote(value: str) -> str:
    """Quote a value for safe inclusion in JQL (escape backslash + double-quote)."""
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _resolve_assignee(name_or_id: str, config_path: str | None) -> str:
    """Map a stored name to its account-id; pass an unknown value through unchanged."""
    entry = account.get(name_or_id, config_path=config_path)
    return entry["account_id"] if entry else name_or_id


def _build_jql(
    *,
    assignee: list[str] | None,
    created_from: str | None,
    created_to: str | None,
    config_path: str | None,
) -> str | None:
    """Compose a JQL query from the people/date filters (``None`` if no filter)."""
    clauses: list[str] = []
    if assignee:
        ids = ", ".join(_jql_quote(_resolve_assignee(a, config_path)) for a in assignee)
        clauses.append(f"assignee in ({ids})")
    if created_from:
        clauses.append(f"created >= {_jql_quote(created_from)}")
    if created_to:
        clauses.append(f"created <= {_jql_quote(created_to)}")
    if not clauses:
        return None
    return " AND ".join(clauses) + " ORDER BY created DESC"


def _parse_issue(raw: dict[str, Any]) -> Issue:
    """Project a raw Jira issue onto the flat Issue shape (cache-schema aligned)."""
    f = raw.get("fields") or {}
    assignee = f.get("assignee") or {}
    return {
        "key": raw.get("key"),
        "summary": f.get("summary"),
        "status": (f.get("status") or {}).get("name"),
        "issue_type": (f.get("issuetype") or {}).get("name"),
        "assignee": assignee.get("displayName"),
        "assignee_id": assignee.get("accountId"),
        "project": (f.get("project") or {}).get("key"),
        "parent": (f.get("parent") or {}).get("key"),
        "created": f.get("created"),
        "updated": f.get("updated"),
    }


def _search(client: Any, jql: str) -> list[Issue]:
    """Run a JQL search, following ``nextPageToken`` pagination to the last page."""
    issues: list[Issue] = []
    token: str | None = None
    for _ in range(_MAX_PAGES):
        body: dict[str, Any] = {"jql": jql, "fields": _FIELDS, "maxResults": _PAGE_SIZE}
        if token:
            body["nextPageToken"] = token
        data = client.post("/search/jql", json=body) or {}  # tolerate an empty body
        issues.extend(_parse_issue(i) for i in (data.get("issues") or []))
        token = data.get("nextPageToken")
        if data.get("isLast") or not token:
            break
    return issues


def list(
    *,
    assignee: list[str] | None = None,
    team: list[str] | None = None,
    jql: str | None = None,
    created_from: str | None = None,
    created_to: str | None = None,
    assigned_from: str | None = None,
    assigned_to: str | None = None,
    roots: bool = False,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> list[Issue]:
    """F004/F005/F008: list issues by assignee(s) / created-range / raw JQL (live).

    ``--team`` (F007), ``--assigned-from/--to`` (changelog) and ``roots`` (F006)
    are deferred past this release and raise a clear "not implemented".
    """
    if team:
        raise NotImplementedError("issue list --team requires virtual teams (F007); deferred")
    if assigned_from or assigned_to:
        raise NotImplementedError(
            "issue list --assigned-from/--assigned-to requires changelog history; deferred"
        )
    if roots:
        raise NotImplementedError("issue list --roots requires parent rules (F006); deferred")

    query = jql or _build_jql(
        assignee=assignee,
        created_from=created_from,
        created_to=created_to,
        config_path=config_path,
    )
    if not query:
        raise JiraHelperError(
            "issue list needs a filter: --assignee, --jql, or --created-from/--created-to"
        )

    from .client import JiraClient  # local import: keep module import-light / cycle-free

    with JiraClient.from_config(config_path=config_path, profile=profile) as client:
        return _search(client, query)


def roots(
    *,
    assignee: list[str] | None = None,
    team: list[str] | None = None,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> list[Issue]:
    """F006: the root issues of an assignee/team set (walk effective parents to the top)."""
    raise NotImplementedError("jira_helper.issue.roots: not yet implemented (scaffold)")


def tree(
    key: str,
    *,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> dict[str, Any]:
    """F006: the parent→child hierarchy for KEY (native parents + virtual rules)."""
    raise NotImplementedError("jira_helper.issue.tree: not yet implemented (scaffold)")


def get(
    key: str,
    *,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> Issue:
    """F004: one issue's fields (live)."""
    from .client import JiraClient

    with JiraClient.from_config(config_path=config_path, profile=profile) as client:
        raw = client.get(f"/issue/{key}", fields=",".join(_FIELDS))
    return _parse_issue(raw or {})  # tolerate an empty body
