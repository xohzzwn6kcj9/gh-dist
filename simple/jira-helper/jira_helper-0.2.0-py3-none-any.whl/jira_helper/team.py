"""F007/F009 — virtual team / member CRUD.

A "team" here is a user-defined virtual group (NOT a Jira/Confluence Team); its
members are Atlassian account-ids (names resolved via the account store, F003).
Teams live in a YAML file beside the config. Querying a team's issues is
``issue list --team`` (F007), not a team verb — this module is team metadata only.

Only ``path`` is wired in this scaffold; the rest are stubs.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from . import config

STORE_FILENAME = "teams.yaml"


def path(*, config_path: str | None = None) -> Path:
    """Resolve the team-store file location (beside the config)."""
    return config.config_dir(config_path) / STORE_FILENAME


def list(*, config_path: str | None = None) -> list[str]:
    """F009: list all virtual team names."""
    raise NotImplementedError("jira_helper.team.list: not yet implemented (scaffold)")


def show(team: str, *, config_path: str | None = None) -> dict[str, Any]:
    """F009: a team + its members resolved to names (via the account store)."""
    raise NotImplementedError("jira_helper.team.show: not yet implemented (scaffold)")


def create(
    team: str, *, members: list[str] | None = None, config_path: str | None = None
) -> dict[str, Any]:
    """F009: create a team, optionally seeded with members."""
    raise NotImplementedError("jira_helper.team.create: not yet implemented (scaffold)")


def delete(team: str, *, config_path: str | None = None) -> bool:
    """F009: delete a team."""
    raise NotImplementedError("jira_helper.team.delete: not yet implemented (scaffold)")


def rename(old: str, new: str, *, config_path: str | None = None) -> dict[str, Any]:
    """F009: rename a team."""
    raise NotImplementedError("jira_helper.team.rename: not yet implemented (scaffold)")


def add_member(team: str, members: list[str], *, config_path: str | None = None) -> dict[str, Any]:
    """F009: add member(s) to a team (names resolved via the account store)."""
    raise NotImplementedError("jira_helper.team.add_member: not yet implemented (scaffold)")


def remove_member(
    team: str, members: list[str], *, config_path: str | None = None
) -> dict[str, Any]:
    """F009: remove member(s) from a team."""
    raise NotImplementedError("jira_helper.team.remove_member: not yet implemented (scaffold)")
