"""jira-helper — admin toolkit for Atlassian Cloud (Jira now, Confluence later).

Library-first: every CLI command is a thin wrapper over a function in these
modules, with a 1:1 mapping (``noun`` = module, ``verb`` = function). Import the
package and call the API directly::

    import jira_helper
    jira_helper.issue.roots(assignee=["alice"])
    jira_helper.team.add_member("backend", ["alice", "bob"])

The CLI (``jira_helper.cli:app``) only parses arguments and renders output; it
adds no behavior of its own. See ``CLAUDE.md`` for the full command system.
"""

from importlib import metadata

from . import account, cache, client, config, errors, issue, output, rule, sync, team

try:
    __version__ = metadata.version("jira-helper")
except metadata.PackageNotFoundError:  # running from a source tree, not installed
    __version__ = "0.0.0"

__all__ = [
    "account",
    "cache",
    "client",
    "config",
    "errors",
    "issue",
    "output",
    "rule",
    "sync",
    "team",
    "__version__",
]
