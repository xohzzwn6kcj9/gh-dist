"""`team` commands — virtual team / member CRUD (F007, F009)."""

from typing import Annotated

import typer

from .. import team as team_lib
from . import _common

app = typer.Typer(no_args_is_help=True, help="Manage virtual teams + members (F009).")

_CFG = ("config_path",)


@app.command("list")
def list_(ctx: typer.Context) -> None:
    """List all virtual teams. Feature: F009.

    Example:
        jira-helper team list
    """
    _common.run(ctx, lambda: team_lib.list(**_common.opt_kwargs(ctx, _CFG)))


@app.command()
def show(
    ctx: typer.Context,
    team: Annotated[str, typer.Argument(help="Team name.")],
) -> None:
    """A team + its members resolved to names (via the account store). Feature: F009.

    Example:
        jira-helper team show backend
    """
    _common.run(ctx, lambda: team_lib.show(team, **_common.opt_kwargs(ctx, _CFG)))


@app.command()
def create(
    ctx: typer.Context,
    team: Annotated[str, typer.Argument(help="New team name.")],
    member: Annotated[
        list[str] | None, typer.Option("--member", help="Seed member name(s) or account-id(s).")
    ] = None,
) -> None:
    """Create a team, optionally seeded with members. Feature: F009.

    Example:
        jira-helper team create backend --member alice --member bob
    """
    _common.run(ctx, lambda: team_lib.create(team, members=member, **_common.opt_kwargs(ctx, _CFG)))


@app.command()
def delete(
    ctx: typer.Context,
    team: Annotated[str, typer.Argument(help="Team to delete.")],
) -> None:
    """Delete a team (use -y to skip confirmation). Feature: F009.

    Example:
        jira-helper -y team delete backend
    """
    _common.run(ctx, lambda: team_lib.delete(team, **_common.opt_kwargs(ctx, _CFG)))


@app.command()
def rename(
    ctx: typer.Context,
    old: Annotated[str, typer.Argument(help="Current team name.")],
    new: Annotated[str, typer.Argument(help="New team name.")],
) -> None:
    """Rename a team. Feature: F009.

    Example:
        jira-helper team rename backend platform
    """
    _common.run(ctx, lambda: team_lib.rename(old, new, **_common.opt_kwargs(ctx, _CFG)))


@app.command("add-member")
def add_member(
    ctx: typer.Context,
    team: Annotated[str, typer.Argument(help="Team name.")],
    member: Annotated[list[str], typer.Argument(help="Member name(s) or account-id(s).")],
) -> None:
    """Add member(s) (names resolved via the account store). Feature: F009.

    Example:
        jira-helper team add-member backend alice bob
    """
    _common.run(ctx, lambda: team_lib.add_member(team, member, **_common.opt_kwargs(ctx, _CFG)))


@app.command("remove-member")
def remove_member(
    ctx: typer.Context,
    team: Annotated[str, typer.Argument(help="Team name.")],
    member: Annotated[list[str], typer.Argument(help="Member(s) to remove.")],
) -> None:
    """Remove member(s) from a team. Feature: F009.

    Example:
        jira-helper team remove-member backend bob
    """
    _common.run(ctx, lambda: team_lib.remove_member(team, member, **_common.opt_kwargs(ctx, _CFG)))


@app.command()
def path(ctx: typer.Context) -> None:
    """Print the team-store file location. Feature: F009.

    Example:
        jira-helper team path
    """
    _common.run(ctx, lambda: team_lib.path(**_common.opt_kwargs(ctx, _CFG)))
