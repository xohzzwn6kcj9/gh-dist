"""`issue` commands — ticket queries (F004–F008)."""

from typing import Annotated

import typer

from .. import issue as issue_lib
from . import _common

app = typer.Typer(no_args_is_help=True, help="Query Jira issues (F004–F008).")

_READ = ("profile", "no_cache", "cache_path", "config_path")


@app.command("list")
def list_(
    ctx: typer.Context,
    assignee: Annotated[
        list[str] | None, typer.Option("--assignee", help="Assignee name(s) or account-id(s).")
    ] = None,
    team: Annotated[
        list[str] | None, typer.Option("--team", help="Virtual team name(s) to expand.")
    ] = None,
    jql: Annotated[
        str | None, typer.Option("--jql", help="Raw JQL passthrough (escape hatch).")
    ] = None,
    created_from: Annotated[
        str | None, typer.Option("--created-from", help="Created on/after (YYYY-MM-DD).")
    ] = None,
    created_to: Annotated[
        str | None, typer.Option("--created-to", help="Created on/before (YYYY-MM-DD).")
    ] = None,
    assigned_from: Annotated[
        str | None, typer.Option("--assigned-from", help="Assigned on/after (with --assignee).")
    ] = None,
    assigned_to: Annotated[
        str | None, typer.Option("--assigned-to", help="Assigned on/before (with --assignee).")
    ] = None,
    roots: Annotated[
        bool, typer.Option("--roots", help="Collapse the result to its root issues (F006).")
    ] = False,
) -> None:
    """List issues by assignee(s), team(s), date range, or raw JQL. Feature: F004/F005/F007/F008.

    '--roots' collapses the result to its root issues (F006).

    Example:
        jira-helper issue list --assignee alice --assignee bob --roots
    Example output (--json):
        [{"key": "PROJA-1", "summary": "...", "status": "...", "assignee_id": "..."}]
    """
    _common.run(
        ctx,
        lambda: issue_lib.list(
            assignee=assignee,
            team=team,
            jql=jql,
            created_from=created_from,
            created_to=created_to,
            assigned_from=assigned_from,
            assigned_to=assigned_to,
            roots=roots,
            **_common.opt_kwargs(ctx, _READ),
        ),
    )


@app.command()
def roots(
    ctx: typer.Context,
    assignee: Annotated[
        list[str] | None, typer.Option("--assignee", help="Assignee name(s)/id(s).")
    ] = None,
    team: Annotated[list[str] | None, typer.Option("--team", help="Virtual team name(s).")] = None,
) -> None:
    """Root issues of an assignee/team set (walk effective parents). Feature: F006.

    Example:
        jira-helper issue roots --team backend
    """
    _common.run(
        ctx,
        lambda: issue_lib.roots(assignee=assignee, team=team, **_common.opt_kwargs(ctx, _READ)),
    )


@app.command()
def tree(
    ctx: typer.Context,
    key: Annotated[str, typer.Argument(help="Issue key, e.g. PROJA-123.")],
) -> None:
    """Parent→child hierarchy for KEY (native + virtual rules). Feature: F006.

    Example:
        jira-helper issue tree PROJA-123
    """
    _common.run(ctx, lambda: issue_lib.tree(key, **_common.opt_kwargs(ctx, _READ)))


@app.command()
def get(
    ctx: typer.Context,
    key: Annotated[str, typer.Argument(help="Issue key, e.g. PROJA-123.")],
) -> None:
    """One issue's fields. Feature: F004.

    Example:
        jira-helper issue get PROJA-123
    """
    _common.run(ctx, lambda: issue_lib.get(key, **_common.opt_kwargs(ctx, _READ)))
