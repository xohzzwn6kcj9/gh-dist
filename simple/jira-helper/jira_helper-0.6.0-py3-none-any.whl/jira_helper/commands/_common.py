"""Shared CLI glue: global options + the stub runner + kwarg plumbing.

Lives in the commands package (not ``cli.py``) so the root app and every noun
command module can import it without an import cycle.
"""

import json as _json
import os
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import typer

from .. import output
from ..errors import ConfigError, JiraHelperError, NotFoundError


@dataclass
class GlobalOptions:
    """Resolved global flags, stashed on the Typer context (``ctx.obj``)."""

    json: bool = False
    config: Path | None = None
    profile: str | None = None
    cache: Path | None = None
    no_cache: bool = False
    quiet: bool = False
    verbose: bool = False
    color: bool | None = None
    yes: bool = False
    dry_run: bool = False


def get_opts(ctx: typer.Context) -> GlobalOptions:
    """Return the GlobalOptions on *ctx* (defaults if the callback didn't run)."""
    return ctx.obj if isinstance(ctx.obj, GlobalOptions) else GlobalOptions()


def as_str(value: Path | None) -> str | None:
    """Path → str for passing override paths down to the library layer."""
    return str(value) if value is not None else None


def opt_kwargs(ctx: typer.Context, names: tuple[str, ...]) -> dict:
    """Select global options to forward to a library call as explicit kwargs.

    Globals never become hidden state: each maps to a named keyword argument, and
    a command forwards only the names its library function actually accepts.
    """
    o = get_opts(ctx)
    available = {
        "profile": o.profile,
        "no_cache": o.no_cache,
        "cache_path": as_str(o.cache),
        "config_path": as_str(o.config),
    }
    return {name: available[name] for name in names}


def stub(name: str):
    """Raise the standard scaffold 'not implemented' error for *name*."""
    raise NotImplementedError(f"jira_helper {name}: not yet implemented (scaffold)")


def require(value: Any, message: str) -> Any:
    """Return *value*, or raise ``NotFoundError(message)`` when it is ``None``.

    A CLI-layer guard so a library "absent → None" (``account.get`` / ``cache.get``)
    renders as a structured ``not_found`` (exit 2) instead of a silent ``null``
    (F011 actionable errors). The library keeps its None-returning ergonomics.
    """
    if value is None:
        raise NotFoundError(message)
    return value


def open_in_editor(path: Path, *, seed: str) -> str:
    """Seed *path* if absent, open it in $EDITOR/$VISUAL (else vi), return its path.

    Routed through :func:`run` by the ``edit`` commands so ``--json`` is honored
    and a missing editor surfaces as a structured ``ConfigError`` (exit 1) rather
    than a raw ``FileNotFoundError`` traceback (F011 actionable errors).
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text(seed, encoding="utf-8")
    editor = os.environ.get("EDITOR") or os.environ.get("VISUAL") or "vi"
    try:
        subprocess.call([editor, str(path)])
    except OSError as exc:
        raise ConfigError(
            f"editor {editor!r} not found; set $EDITOR (e.g. export EDITOR=vi)"
        ) from exc
    return str(path)


def _fail(ctx_json: bool, *, code: str, message: str, exit_code: int) -> typer.Exit:
    """Render a structured error to stderr (stdout stays reserved for machine data)."""
    if ctx_json:
        payload = {"error": code, "message": message, "exit_code": exit_code}
        typer.echo(_json.dumps(payload), err=True)
    else:
        typer.secho(f"{code.replace('_', ' ')}: {message}", fg=typer.colors.RED, err=True)
    return typer.Exit(code=exit_code)


def run(ctx: typer.Context, call, *, human=None) -> None:
    """Invoke a library thunk and render its result, or a structured error.

    Two error classes never produce a traceback: stub ``NotImplementedError``
    (exit 2) and expected ``JiraHelperError`` (its own ``code``/``exit_code``).
    Anything else propagates — it's a real bug (F011 actionable errors).

    ``human`` is an optional ``result -> str`` formatter used for the non-JSON
    view (e.g. an indented tree); ``--json`` always uses the structured renderer.
    """
    opts = get_opts(ctx)
    try:
        result = call()
    except NotImplementedError as exc:
        raise _fail(
            opts.json,
            code="not_implemented",
            message=str(exc) or "not implemented",
            exit_code=2,
        ) from exc
    except JiraHelperError as exc:
        raise _fail(opts.json, code=exc.code, message=str(exc), exit_code=exc.exit_code) from exc
    if human is not None and not opts.json:
        typer.echo(human(result))
    else:
        output.render(result, as_json=opts.json)
