"""`logs` commands — locate and read the rotating CLI log file (F013)."""

from typing import Annotated

import typer

from .. import logs as logs_lib
from . import _common

app = typer.Typer(no_args_is_help=True, help="Locate and read the CLI log file (F013).")

_LOGS = ("config_path",)


@app.command()
def path(ctx: typer.Context) -> None:
    """Print the log file location. Feature: F013.

    Honors --config / falls back to the ``logs/`` dir beside the resolved config;
    override the directory with $JIRA_HELPER_LOG_DIR or the ``log_dir`` config key.

    Example:
        jira-helper logs path
    Example output:
        /Users/me/.config/jira-helper/logs/jira-helper.log
    """
    _common.run(ctx, lambda: logs_lib.path(**_common.opt_kwargs(ctx, _LOGS)))


@app.command()
def status(ctx: typer.Context) -> None:
    """File path, size, line count, time span, rotation backups. Feature: F013.

    Each field degrades (never raises) when the log file doesn't exist yet.

    Example:
        jira-helper --json logs status
    Example output (--json):
        {"path": "~/.config/jira-helper/logs/jira-helper.log", "exists": true,
         "size_bytes": 40960, "lines": 512, "oldest": "2026-06-21T08:00:00+0900",
         "newest": "2026-06-21T09:30:00+0900", "backups": 1}
    """
    _common.run(ctx, lambda: logs_lib.status(**_common.opt_kwargs(ctx, _LOGS)))


@app.command()
def show(
    ctx: typer.Context,
    lines: Annotated[int, typer.Option("--lines", help="Max lines to show (default 50).")] = 50,
    level: Annotated[
        str | None,
        typer.Option("--level", help="Filter by level: DEBUG/INFO/WARNING/ERROR/CRITICAL."),
    ] = None,
) -> None:
    """Print the last N log lines (tail), optionally filtered by level. Feature: F013.

    ``--level`` (case-insensitive) is applied BEFORE the ``--lines`` cap, so
    ``--lines 20 --level ERROR`` returns the last 20 errors. Credentials are
    redacted at write time, so the output never contains the API token.

    Example:
        jira-helper logs show --lines 20 --level ERROR
    Example output:
        2026-06-21T09:30:01+0900 WARNING jira_helper.client [a1b2c3d4] http GET /myself -> 401
        2026-06-21T09:30:05+0900 ERROR jira_helper [a1b2c3d4] uncaught exception
    """
    _common.run(
        ctx,
        lambda: logs_lib.show(lines=lines, level=level, **_common.opt_kwargs(ctx, _LOGS)),
        human=logs_lib.format_records,
    )


@app.command()
def clear(ctx: typer.Context) -> None:
    """Truncate the log file + drop rotation backups (use -y to skip confirm). Feature: F013.

    Prompts before clearing unless the global ``-y/--yes`` is set; returns the
    bytes reclaimed and the number of rotation backups removed.

    Example:
        jira-helper -y logs clear
    Example output (--json):
        {"bytes_reclaimed": 40960, "backups_removed": 1}
    """
    if not _common.get_opts(ctx).yes:
        typer.confirm("Clear the log file (truncate + drop rotation backups)?", abort=True)
    _common.run(ctx, lambda: logs_lib.clear(**_common.opt_kwargs(ctx, _LOGS)))
