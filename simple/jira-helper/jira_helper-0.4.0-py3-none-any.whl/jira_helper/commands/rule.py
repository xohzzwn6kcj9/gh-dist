"""`rule` commands — virtual-parent rules (F006)."""

import os
import subprocess
from typing import Annotated

import typer

from .. import rule as rule_lib
from . import _common

app = typer.Typer(no_args_is_help=True, help="Virtual-parent rules (F006).")

_CFG = ("config_path",)
_SEED = "virtual_parent_rules: []\nmanual_parents: []\n"


# --- human renderers (non-JSON views the generic table can't express) --------


def _format_list(data: dict) -> str:
    lines: list[str] = ["virtual_parent_rules:"]
    rules = data.get("virtual_parent_rules") or []
    if not rules:
        lines.append("  (none)")
    for r in rules:
        when = ", ".join(f"{k}={v}" for k, v in (r.get("when") or {}).items()) or "(any)"
        override = " [override]" if r.get("override") else ""
        lines.append(
            f"  - {r.get('name', '(unnamed)')}: when {when} → parent={r.get('parent')}{override}"
        )
    lines.append("manual_parents:")
    manual = data.get("manual_parents") or []
    if not manual:
        lines.append("  (none)")
    lines += [f"  - {e.get('child')} → {e.get('parent')}" for e in manual]
    return "\n".join(lines)


def _format_resolve(d: dict) -> str:
    links = ", ".join(d.get("linked_keys") or []) or "(none)"
    return "\n".join(
        [
            f"key: {d['key']}",
            f"native_parent: {d.get('native_parent') or '(none)'}",
            f"effective_parent: {d.get('effective_parent') or '(root)'}",
            f"source: {d.get('source') or '(root)'}",
            f"linked_keys: {links}",
        ]
    )


# --- commands ----------------------------------------------------------------


@app.command("list")
def list_(ctx: typer.Context) -> None:
    """Render parsed conditional rules + manual edges. Feature: F006.

    Example:
        jira-helper rule list
    """
    _common.run(ctx, lambda: rule_lib.list(**_common.opt_kwargs(ctx, _CFG)), human=_format_list)


@app.command()
def edit(ctx: typer.Context) -> None:
    """Open rules.yaml in $EDITOR (author conditional rules). Feature: F006.

    Example:
        jira-helper rule edit
    """
    p = rule_lib.path(**_common.opt_kwargs(ctx, _CFG))
    p.parent.mkdir(parents=True, exist_ok=True)
    if not p.exists():
        p.write_text(_SEED, encoding="utf-8")
    editor = os.environ.get("EDITOR") or os.environ.get("VISUAL") or "vi"
    subprocess.call([editor, str(p)])
    typer.echo(str(p))


@app.command()
def add(
    ctx: typer.Context,
    child: Annotated[str, typer.Argument(help="Child issue key, e.g. PROJA-101.")],
    parent: Annotated[str, typer.Argument(help="Parent issue key, e.g. PROJA-50.")],
) -> None:
    """Append a one-off manual parent edge (child → parent). Feature: F006.

    Example:
        jira-helper rule add PROJA-101 PROJA-50
    """
    _common.run(ctx, lambda: rule_lib.add(child, parent, **_common.opt_kwargs(ctx, _CFG)))


@app.command()
def remove(
    ctx: typer.Context,
    child: Annotated[str, typer.Argument(help="Child key whose manual edge to drop.")],
) -> None:
    """Drop a manual edge. Feature: F006.

    Example:
        jira-helper rule remove PROJA-101
    """
    _common.run(ctx, lambda: rule_lib.remove(child, **_common.opt_kwargs(ctx, _CFG)))


@app.command()
def test(
    ctx: typer.Context,
    key: Annotated[str, typer.Argument(help="Issue key to resolve.")],
) -> None:
    """Dry-run: effective parent for KEY + which rule fired. Feature: F006.

    Example:
        jira-helper rule test PROJA-123
    """
    _common.run(
        ctx,
        lambda: rule_lib.resolve(
            key, **_common.opt_kwargs(ctx, ("profile", "config_path", "cache_path"))
        ),
        human=_format_resolve,
    )


@app.command()
def validate(ctx: typer.Context) -> None:
    """Schema + cycle + ambiguity checks before traversal. Feature: F006.

    Example:
        jira-helper rule validate
    """
    _common.run(ctx, lambda: rule_lib.validate(**_common.opt_kwargs(ctx, _CFG)))


@app.command()
def path(ctx: typer.Context) -> None:
    """Print the rules file location. Feature: F006.

    Example:
        jira-helper rule path
    """
    _common.run(ctx, lambda: rule_lib.path(**_common.opt_kwargs(ctx, _CFG)))
