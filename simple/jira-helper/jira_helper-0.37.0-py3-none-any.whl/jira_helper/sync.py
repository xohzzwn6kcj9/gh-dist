"""F010 — background auto-sync (cron / launchd friendly).

A CLI-invocable refresh that keeps the local SQLite cache current. Incremental
and idempotent (UPSERT keyed on ``key`` + an ``updated`` watermark) so repeated
runs are cheap; WAL lets a sync write while reads run. ``--product`` is honored
from day one so Confluence is purely additive.

What ``run`` populates (the seed scope, F010 design):

1. **base set** — every issue assigned to a member of the config ``sync_orgs``
   org unit(s) (``org.member_ids`` union), filtered to ``updated >= watermark``
   on an incremental run;
2. **ancestor closure** — every ``effective_parent`` reachable from the base set,
   fetched recursively, so cache-backed ``roots``/``tree`` traversal sees the same
   chains a live walk would (epics/parents assigned to others land here too).

``effective_parent`` (+ its ``source``) is recomputed per issue at write time via
the pure rule engine; a change to ``rules.yaml`` (tracked by a fingerprint in
``meta``) triggers a full recompute from stored columns with no refetch. The whole
fetch + write is one transaction, so a crash rolls back to the prior snapshot.
"""

from __future__ import annotations

import fcntl
import hashlib
import json
import re
import shutil
import sqlite3
from datetime import UTC, datetime, timedelta
from typing import Any
from xml.sax.saxutils import escape as _xml_escape

from . import cache, config
from . import issue as issue_lib
from . import org as org_lib
from . import rule as rule_lib
from .client import JiraClient
from .errors import JiraHelperError

_LOCKFILE = "sync.lock"
# A sync may page through far more than the live-read default; cap well above any
# single org's backlog (≈100k issues at the 100/page size) as a runaway backstop.
_SYNC_MAX_PAGES = 1000
# Ancestor-closure safety cap (rounds of "fetch the still-missing parents").
_CLOSURE_MAX_ROUNDS = 50

_UPSERT = """
INSERT INTO issue (
    key, product, project, issue_type, summary, status,
    assignee_id, native_parent, effective_parent, source,
    created, updated, status_category_changed_at, raw, synced_at
) VALUES (
    :key, :product, :project, :issue_type, :summary, :status,
    :assignee_id, :native_parent, :effective_parent, :source,
    :created, :updated, :status_category_changed_at, :raw, :synced_at
)
ON CONFLICT(key) DO UPDATE SET
    product=excluded.product, project=excluded.project, issue_type=excluded.issue_type,
    summary=excluded.summary, status=excluded.status, assignee_id=excluded.assignee_id,
    native_parent=excluded.native_parent, effective_parent=excluded.effective_parent,
    source=excluded.source, created=excluded.created, updated=excluded.updated,
    status_category_changed_at=excluded.status_category_changed_at,
    raw=excluded.raw, synced_at=excluded.synced_at
"""


# --- small pure helpers -------------------------------------------------------


def _now_iso() -> str:
    """Local wall-clock stamp for ``synced_at`` / ``last_sync_at`` (provenance only)."""
    return datetime.now(UTC).isoformat()


def _max_iso(a: str | None, b: str | None) -> str | None:
    """Lexically-greater of two ISO-8601 ``updated`` strings (None-safe)."""
    if a is None:
        return b
    if b is None:
        return a
    return a if a >= b else b


def _parse_sync_orgs(value: Any) -> list[str]:
    """Config ``sync_orgs`` → org-unit names. Accepts a YAML list or a comma string."""
    if isinstance(value, str):
        return [s.strip() for s in value.split(",") if s.strip()]
    if isinstance(value, (list, tuple)):
        return [str(v).strip() for v in value if str(v).strip()]
    return []


def _rules_fingerprint(config_path: str | None) -> str:
    """sha256 of ``rules.yaml`` bytes (``""`` if absent) — the recompute trigger."""
    p = rule_lib.path(config_path=config_path)
    return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else ""


def _union_member_ids(units: list[str], config_path: str | None) -> list[str]:
    """De-duped account-id union across every ``sync_orgs`` unit's subtree (F007)."""
    ids: list[str] = []
    for unit in units:
        ids.extend(org_lib.member_ids(unit, config_path=config_path))
    return [*dict.fromkeys(ids)]


def _sync_jql(id_chunk: list[str], floor: str | None) -> str:
    """Assignee-chunk JQL, oldest-first so the watermark advances monotonically.

    *floor* is the ``updated >=`` lower bound — the later of the incremental watermark and
    the ``sync_max_age`` horizon (computed by the caller).
    """
    clause = f"assignee in ({', '.join(issue_lib._jql_quote(i) for i in id_chunk)})"
    if floor:
        clause += f" AND updated >= {issue_lib._jql_quote(floor)}"
    return clause + " ORDER BY updated ASC"


# --- sync horizon (cap the base set by `updated` age, so a full/first sync doesn't drag in
# years of dormant issues — each issue costs a changelog GET, #79). Default 6 months ON.
_MAX_AGE_UNITS = {"d": 1, "w": 7, "m": 30, "y": 365}  # m≈30d, y≈365d (coarse retention floor)
_DEFAULT_MAX_AGE_DAYS = 180


def _parse_max_age(value: Any) -> timedelta | None:
    """Config ``sync_max_age`` → a retention floor, or ``None`` (no horizon).

    Accepts ``180d`` / ``26w`` / ``6m`` / ``1y`` or a bare day count; unset → the 180-day
    (6-month) default; ``0`` / ``""`` / ``off`` / ``none`` disables the horizon entirely.
    """
    if value is None:
        return timedelta(days=_DEFAULT_MAX_AGE_DAYS)
    s = str(value).strip().lower()
    if s in ("", "0", "off", "none", "false"):
        return None
    m = re.match(r"^(\d+)\s*([dwmy]?)$", s)
    if not m:
        raise JiraHelperError(
            f"invalid sync_max_age {value!r}; use e.g. 180d, 26w, 6m, 1y, or 0 to disable"
        )
    return timedelta(days=int(m.group(1)) * _MAX_AGE_UNITS[m.group(2) or "d"])


def _horizon_floor(max_age: timedelta | None, *, now: datetime | None = None) -> str | None:
    """The absolute ``updated >=`` date (``now - max_age``) for the base fetch, or ``None``."""
    if max_age is None:
        return None
    return ((now or datetime.now(UTC)) - max_age).strftime("%Y-%m-%d")


# --- store writes (own the cache mutation; cache.py owns schema + reads) -------


def _upsert(
    conn: sqlite3.Connection,
    raw: dict[str, Any],
    rules: list[dict[str, Any]],
    manual: dict[str, str],
    *,
    product: str,
    synced_at: str,
) -> dict[str, Any] | None:
    """UPSERT one raw issue (+ its typed links); return the parsed node (None if keyless).

    ``status_category_changed_at`` (#79) is sourced INLINE from ``statuscategorychangedate``
    field — the last status-CATEGORY (To Do / In Progress / Done) transition. It already
    rides back on every search result jh makes (no extra request, unlike the old per-issue
    changelog GET), and unlike ``updated`` it doesn't advance on comment/link housekeeping —
    so a long-closed issue stays excluded from ``--status-category-changed-from``. Falls back to
    ``created`` when the field is absent (a never-transitioned issue, or an instance/project
    that doesn't surface it — confirm live, #31 gate).
    """
    node = issue_lib._node_from_raw(raw)
    key = node.get("key")
    if not key:
        return None
    eff, src = rule_lib.effective_parent_of_node(node, rules, manual)
    scat = (raw.get("fields") or {}).get("statuscategorychangedate") or node.get("created")
    conn.execute(
        _UPSERT,
        {
            "key": key,
            "product": product,
            "project": node.get("project"),
            "issue_type": node.get("issue_type"),
            "summary": node.get("summary"),
            "status": node.get("status"),
            "assignee_id": node.get("assignee_id"),
            "native_parent": node.get("parent"),  # cache column rename
            "effective_parent": eff,
            "source": src,
            "created": node.get("created"),
            "updated": node.get("updated"),
            "status_category_changed_at": scat,
            "raw": json.dumps(raw, ensure_ascii=False),
            "synced_at": synced_at,
        },
    )
    conn.execute("DELETE FROM issue_link WHERE src = ?", (key,))
    links = issue_lib._link_rows(raw)
    if links:
        conn.executemany(
            "INSERT OR IGNORE INTO issue_link (src, dst, type) VALUES (?, ?, ?)", links
        )
    return node


def _refresh_stale_ancestors(
    conn: sqlite3.Connection,
    client: Any,
    rules: list[dict[str, Any]],
    manual: dict[str, str],
    *,
    product: str,
    synced_at: str,
    member_ids: list[str],
    watermark: str | None,
) -> int:
    """Refresh cached rows the base assignee query never covers — closure-pulled ancestors
    (epics/parents assigned to non-members or nobody) — whose ``updated`` advanced since the
    *watermark*, so an incremental ``sync run`` keeps them fresh (not only ``--full``).

    The base fetch is ``assignee in (members)``; ancestors aren't, and ``_close_ancestors``
    only pulls parents MISSING from the cache — so a cached ancestor would otherwise go stale
    (a reparent / status / summary change unseen until a full resync). We poll the cached
    non-member keys with ``key in (...) AND updated >= watermark`` (Jira returns only the ones
    that actually changed) and re-UPSERT them. No-op without a watermark (a first/``--full``
    run rebuilds every row anyway). Cost: one search per ~``_ASSIGNEE_BATCH`` cached ancestors
    per incremental run, regardless of how many changed. Returns rows refreshed.
    """
    if not watermark:
        return 0
    keys = [
        r[0]
        for r in conn.execute(
            "SELECT key FROM issue WHERE product = ? AND (assignee_id IS NULL "
            "OR assignee_id NOT IN (SELECT value FROM json_each(?)))",
            (product, json.dumps(member_ids)),
        )
    ]
    refreshed = 0
    for chunk in issue_lib._chunks(keys, issue_lib._ASSIGNEE_BATCH):
        jql = (
            f"key in ({', '.join(issue_lib._jql_quote(k) for k in chunk)}) "
            f"AND updated >= {issue_lib._jql_quote(watermark)} ORDER BY updated ASC"
        )
        for raw in issue_lib._search_raw(client, jql, with_links=True, max_pages=_SYNC_MAX_PAGES):
            if _upsert(conn, raw, rules, manual, product=product, synced_at=synced_at):
                refreshed += 1
    return refreshed


def _close_ancestors(
    conn: sqlite3.Connection,
    client: Any,
    rules: list[dict[str, Any]],
    manual: dict[str, str],
    *,
    product: str,
    synced_at: str,
    collapse_links: bool = False,
) -> int:
    """Fetch every effective-parent not yet cached, recursively; return rows added.

    Stops when nothing is missing, when a round fetches nothing new (a deleted /
    not-visible ancestor stays dangling — the climb CTE tolerates it), or at the
    safety cap. With *collapse_links* (a ``linked`` strategy OR ``linked_count`` matcher is in
    play — see :func:`rule._rules_need_link_closure`) the frontier also pulls ``issue_link``
    endpoints + uncached ``native_parent`` chains, so the cache can climb each link's complete
    native subtree — both to collapse it and to detect the issue's own native descendants.
    """
    frontier = (
        "SELECT effective_parent AS k FROM issue "
        "WHERE effective_parent IS NOT NULL AND effective_parent NOT IN (SELECT key FROM issue)"
    )
    if collapse_links:
        frontier += (
            " UNION SELECT native_parent FROM issue "
            "WHERE native_parent IS NOT NULL AND native_parent NOT IN (SELECT key FROM issue)"
            " UNION SELECT dst FROM issue_link WHERE dst NOT IN (SELECT key FROM issue)"
            " UNION SELECT src FROM issue_link WHERE src NOT IN (SELECT key FROM issue)"
        )
    query = f"SELECT DISTINCT k FROM ({frontier})"
    added = 0
    for _ in range(_CLOSURE_MAX_ROUNDS):
        missing = [row[0] for row in conn.execute(query)]
        if not missing:
            break
        fetched = False
        for chunk in issue_lib._chunks(missing, issue_lib._ASSIGNEE_BATCH):
            jql = f"key in ({', '.join(issue_lib._jql_quote(k) for k in chunk)})"
            for raw in issue_lib._search_raw(
                client, jql, with_links=True, max_pages=_SYNC_MAX_PAGES
            ):
                if _upsert(conn, raw, rules, manual, product=product, synced_at=synced_at):
                    added += 1
                    fetched = True
        if not fetched:
            break
    return added


def _recompute_effective_parents(
    conn: sqlite3.Connection,
    rules: list[dict[str, Any]],
    manual: dict[str, str],
    *,
    product: str,
) -> int:
    """Re-derive ``effective_parent``/``source`` for every product row from stored
    columns + ``issue_link`` (no network) — for when ``rules.yaml`` changed."""
    rows = conn.execute(
        "SELECT key, project, issue_type, native_parent, summary FROM issue WHERE product = ?",
        (product,),
    ).fetchall()
    for r in rows:
        node = cache.engine_node(
            conn,
            key=r["key"],
            project=r["project"],
            issue_type=r["issue_type"],
            native_parent=r["native_parent"],
            summary=r["summary"],
        )
        eff, src = rule_lib.effective_parent_of_node(node, rules, manual)
        conn.execute(
            "UPDATE issue SET effective_parent = ?, source = ? WHERE key = ?", (eff, src, r["key"])
        )
    return len(rows)


def _write_meta(
    conn: sqlite3.Connection,
    product: str,
    *,
    last_sync_at: str | None,
    watermark: str | None,
    last_error: str | None,
    rules_fingerprint: str | None,
) -> None:
    conn.execute(
        "INSERT INTO meta (product, last_sync_at, watermark, last_error, rules_fingerprint) "
        "VALUES (?, ?, ?, ?, ?) "
        "ON CONFLICT(product) DO UPDATE SET "
        "last_sync_at=excluded.last_sync_at, watermark=excluded.watermark, "
        "last_error=excluded.last_error, rules_fingerprint=excluded.rules_fingerprint",
        (product, last_sync_at, watermark, last_error, rules_fingerprint),
    )


# --- file lock (crash-safe: the OS releases the flock on process death) --------


def _lock_path(config_path: str | None):
    return config.config_dir(config_path) / _LOCKFILE


def _acquire_lock(config_path: str | None):
    """Non-blocking exclusive flock; returns the open handle, or None if held."""
    p = _lock_path(config_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    fh = open(p, "a")
    try:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        fh.close()
        return None
    return fh


def _release_lock(fh) -> None:
    if fh is None:
        return
    try:
        fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
    finally:
        fh.close()


def _probe_lock(config_path: str | None) -> bool:
    """True if a sync currently holds the lock (acquire-then-release probe)."""
    fh = _acquire_lock(config_path)
    if fh is None:
        return True
    _release_lock(fh)
    return False


# --- public API ---------------------------------------------------------------


def run(
    *,
    product: str = "jira",
    full: bool = False,
    since: str | None = None,
    profile: str | None = None,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> dict[str, Any]:
    """F010: incremental, idempotent cache refresh (``--full`` for a complete resync).

    Precedence: ``--full`` (ignore watermark + wipe the product's rows first) >
    ``--since`` (watermark lower-bound override) > the stored watermark > none
    (first run = full base). Single-instance: refuses to start if another sync
    holds the lock.

    Example:
        jira_helper.sync.run(product="jira")            # incremental
    """
    cfg = config.load(config_path=config_path)
    sync_orgs = _parse_sync_orgs(cfg.get("sync_orgs"))
    if not sync_orgs:
        raise JiraHelperError(
            "sync needs config 'sync_orgs' (org unit name(s)); set via `config edit` "
            'or `config set sync_orgs "실A,실B"`'
        )

    cache.init_db(cache_path=cache_path, config_path=config_path)
    lock = _acquire_lock(config_path)
    if lock is None:
        raise JiraHelperError("another sync is already running (sync.lock is held)")

    conn = cache.connect(cache_path=cache_path, config_path=config_path)
    try:
        rules, manual = rule_lib.load(config_path=config_path)
        fp_now = _rules_fingerprint(config_path)
        prior = cache.read_meta(conn, product)
        synced_at = _now_iso()
        watermark = None if full else (since or prior.get("watermark"))
        member_ids = _union_member_ids(sync_orgs, config_path)
        # sync_max_age horizon: cap the base set by `updated` age (default 6 months) so a
        # full/first sync doesn't pull years of dormant issues — each costs a changelog GET
        # (#79). An explicit `--since` is the operator overriding the floor → bypass the horizon.
        horizon_floor = None if since else _horizon_floor(_parse_max_age(cfg.get("sync_max_age")))
        try:
            result = _do_sync(
                conn,
                product=product,
                full=full,
                watermark=watermark,
                horizon_floor=horizon_floor,
                member_ids=member_ids,
                rules=rules,
                manual=manual,
                fp_now=fp_now,
                fp_prior=prior.get("rules_fingerprint"),
                synced_at=synced_at,
                profile=profile,
                config_path=config_path,
            )
        except Exception as exc:
            _record_error(conn, product, str(exc))
            raise
    finally:
        conn.close()
        _release_lock(lock)
    return result


def _do_sync(
    conn: sqlite3.Connection,
    *,
    product: str,
    full: bool,
    watermark: str | None,
    horizon_floor: str | None,
    member_ids: list[str],
    rules: list[dict[str, Any]],
    manual: dict[str, str],
    fp_now: str,
    fp_prior: str | None,
    synced_at: str,
    profile: str | None,
    config_path: str | None,
) -> dict[str, Any]:
    """The fetch + write, all in one transaction (atomic commit via WAL)."""
    synced = 0
    max_updated = None if full else watermark
    # The base `updated >=` floor: the later of the incremental watermark and the age horizon.
    # Incremental → watermark wins (recent); full/first → the horizon binds (None = no horizon).
    floor = _max_iso(watermark, horizon_floor)
    with conn:
        if full:
            conn.execute(
                "DELETE FROM issue_link WHERE src IN (SELECT key FROM issue WHERE product = ?)",
                (product,),
            )
            conn.execute("DELETE FROM issue WHERE product = ?", (product,))

        # Bypass the response memoize: sync is the source of truth for cache.db and must
        # fetch fresh, never seed the issue store from a (≤TTL) stale HTTP response.
        with JiraClient.from_config(
            config_path=config_path, profile=profile, cache_enabled=False
        ) as client:
            # status_category_changed_at now rides inline on each search result (the issue's
            # statuscategorychangedate field), so the base fetch is back to a plain paginated
            # search + upsert — no per-issue changelog GET, no parallel fan-out (#79 redesign).
            for chunk in issue_lib._chunks(member_ids, issue_lib._ASSIGNEE_BATCH):
                for raw in issue_lib._search_raw(
                    client, _sync_jql(chunk, floor), with_links=True, max_pages=_SYNC_MAX_PAGES
                ):
                    node = _upsert(conn, raw, rules, manual, product=product, synced_at=synced_at)
                    if node:
                        synced += 1
                        max_updated = _max_iso(max_updated, node.get("updated"))

            # Incremental keeps cached ANCESTORS fresh too: the base query above only covers
            # member-assigned issues, so an epic/parent owned by others would go stale once
            # cached. Poll the cached non-member rows for changes since the watermark.
            ancestors_refreshed = _refresh_stale_ancestors(
                conn,
                client,
                rules,
                manual,
                product=product,
                synced_at=synced_at,
                member_ids=member_ids,
                watermark=watermark,
            )

            # A rules.yaml change flips parents on issues we didn't refetch → recompute
            # the whole product from stored columns BEFORE closing ancestors.
            recomputed = 0
            if fp_prior not in (None, fp_now):
                recomputed = _recompute_effective_parents(conn, rules, manual, product=product)

            # A `linked` strategy OR any `linked_count` matcher needs each issue's native
            # subtree cached — to collapse, and to compute the external count (own-descendant
            # exclusion). One predicate gates the closure widening AND the recompute below.
            needs_closure = rule_lib._rules_need_link_closure(rules)
            ancestors = _close_ancestors(
                conn,
                client,
                rules,
                manual,
                product=product,
                synced_at=synced_at,
                collapse_links=needs_closure,
            )

        # The widened closure can complete an issue's native subtree (a previously uncached
        # epic / intermediate), flipping its `linked` collapse or external count — so recompute
        # the stored effective_parent AFTER the closure, even when the fingerprint is unchanged.
        linked_recomputed = (
            _recompute_effective_parents(conn, rules, manual, product=product)
            if needs_closure
            else 0
        )

        new_watermark = max_updated if max_updated is not None else watermark
        _write_meta(
            conn,
            product,
            last_sync_at=synced_at,
            watermark=new_watermark,
            last_error=None,
            rules_fingerprint=fp_now,
        )
    return {
        "product": product,
        "synced": synced,
        "ancestors_added": ancestors,
        "ancestors_refreshed": ancestors_refreshed,
        "recomputed": recomputed,
        "linked_recomputed": linked_recomputed,
        "horizon": horizon_floor,
        "watermark": new_watermark,
        "full": full,
    }


def _record_error(conn: sqlite3.Connection, product: str, message: str) -> None:
    """Persist ``last_error`` after a failed run (the txn rolled back; keep prior state)."""
    prior = cache.read_meta(conn, product)
    _write_meta(
        conn,
        product,
        last_sync_at=prior.get("last_sync_at"),
        watermark=prior.get("watermark"),
        last_error=message,
        rules_fingerprint=prior.get("rules_fingerprint"),
    )
    conn.commit()


def status(*, cache_path: str | None = None, config_path: str | None = None) -> dict[str, Any]:
    """F010: last run time, watermark, lock state, last error.

    Example:
        jira_helper.sync.status()
    """
    cache.init_db(cache_path=cache_path, config_path=config_path)
    conn = cache.connect(cache_path=cache_path, config_path=config_path)
    try:
        meta = cache.read_meta(conn, "jira")
    finally:
        conn.close()
    return {
        "last_sync_at": meta.get("last_sync_at"),
        "watermark": meta.get("watermark"),
        "locked": _probe_lock(config_path),
        "last_error": meta.get("last_error"),
    }


_PLIST_LABEL = "com.jira-helper.sync"
_DEFAULT_INTERVAL = 3600  # launchd StartInterval (seconds)
_DEFAULT_CRON = "0 * * * *"  # crontab schedule (hourly)


def _sync_argv(config_path: str | None) -> list[str]:
    """The ``jira-helper sync run`` invocation a scheduler should call."""
    exe = shutil.which("jira-helper") or "jira-helper"
    argv = [exe, "sync", "run"]
    if config_path:
        argv += ["--config", config_path]
    return argv


def _launchd_plist(argv: list[str], interval: int) -> str:
    # escape each arg: a config path may carry XML-special chars (< > &).
    args_xml = "\n".join(f"        <string>{_xml_escape(a)}</string>" for a in argv)
    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" '
        '"http://www.apple.com/DTD/PropertyList-1.0.dtd">\n'
        '<plist version="1.0">\n'
        "<dict>\n"
        f"    <key>Label</key>\n    <string>{_PLIST_LABEL}</string>\n"
        f"    <key>ProgramArguments</key>\n    <array>\n{args_xml}\n    </array>\n"
        f"    <key>StartInterval</key>\n    <integer>{interval}</integer>\n"
        "    <key>RunAtLoad</key>\n    <true/>\n"
        "</dict>\n"
        "</plist>\n"
    )


def install(
    *,
    scheduler: str = "launchd",
    schedule: str | None = None,
    config_path: str | None = None,
) -> dict[str, Any]:
    """F010: render a scheduler unit + write it beside the config; return the next step.

    ``scheduler`` = ``launchd`` (``schedule`` = interval seconds, default 3600) or
    ``cron`` (``schedule`` = a crontab expression, default hourly). The unit is only
    *emitted* — loading it (``launchctl load`` / ``crontab``) is the returned manual
    step, so this never touches the live scheduler (and stays unit-testable offline).

    Example:
        jira_helper.sync.install(scheduler="cron", schedule="*/30 * * * *")
    """
    if scheduler not in ("launchd", "cron"):
        raise JiraHelperError(f"unknown scheduler {scheduler!r} (use 'launchd' or 'cron')")

    argv = _sync_argv(config_path)
    cfg_dir = config.config_dir(config_path)
    cfg_dir.mkdir(parents=True, exist_ok=True)

    if scheduler == "launchd":
        interval = int(schedule) if schedule and schedule.isdigit() else _DEFAULT_INTERVAL
        unit = _launchd_plist(argv, interval)
        path = cfg_dir / f"{_PLIST_LABEL}.plist"
        next_step = f"launchctl load {path}"
    else:
        cron_expr = schedule or _DEFAULT_CRON
        unit = f"{cron_expr} {' '.join(argv)}\n"
        path = cfg_dir / "jira-helper.cron"
        next_step = f"crontab {path}  # or append the line to your existing crontab"

    path.write_text(unit, encoding="utf-8")
    return {"scheduler": scheduler, "path": str(path), "unit": unit, "next_step": next_step}
