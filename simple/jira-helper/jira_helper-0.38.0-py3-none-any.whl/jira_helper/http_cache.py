"""Disk-persistent TTL memoize for Jira REST read responses.

Motivation: ``GET /issue/{key}`` is hit heavily — within one run (tree climb /
ancestor closure / link resolution) and across repeated short-lived CLI
invocations. An in-process memo can't help the cross-invocation case, so this is
a small SQLite store (``http_cache.db``, beside ``cache.db``) keyed by a content
hash of the request; a hit within its TTL short-circuits the network.

Scope is deliberately narrow and low-risk:

* **JiraClient only** — wired at the shared ``client._send`` chokepoint, but only
  ``JiraClient`` passes a cache handle (Confluence ``page`` is live-only).
* **Reads only** — :func:`_cacheable` admits any ``GET`` plus the ``POST
  /search/jql`` query; a future write POST is never cached.
* **Separate file** — independent of ``cache.db``'s sync schema / migration ladder,
  so this store can be flushed or deleted without touching the issue cache.
* **Fail-open** — every operation swallows :class:`sqlite3.Error`; a cache fault
  degrades to a miss / no-op and never breaks a live request. Each op opens its
  own short-lived connection, so the #65 worker pool (up to 8 threads sharing one
  client) hits it safely without shared state.

The TTL is uniform and config-driven (:func:`config.resolve_cache_ttl`,
``api_cache_ttl``, default 600s; ``0`` disables by having ``from_config`` build no
cache at all).
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
import time
from pathlib import Path
from typing import Any

from . import config

_CACHE_FILENAME = "http_cache.db"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS http_cache (
    key        TEXT PRIMARY KEY,
    method     TEXT,
    url_path   TEXT,
    body       TEXT,
    stored_at  REAL,
    expires_at REAL
);
CREATE INDEX IF NOT EXISTS idx_http_expires ON http_cache(expires_at);
"""


def path(*, cache_path: str | None = None, config_path: str | None = None) -> Path:
    """Resolve ``http_cache.db`` — beside ``cache.db`` (honoring ``--cache``)."""
    if cache_path is not None:
        return Path(cache_path).expanduser().parent / _CACHE_FILENAME
    return config.config_dir(config_path) / _CACHE_FILENAME


def _cacheable(method: str, url_path: str) -> bool:
    """Only idempotent reads are memoized: any ``GET``, plus the JQL search ``POST``.

    No write endpoints exist today; gating ``POST`` to ``/search/jql`` keeps a
    future create / transition / delete from ever being served from cache.
    """
    method = method.upper()
    if method == "GET":
        return True
    return method == "POST" and url_path == "/search/jql"


def _canonical(value: Any) -> str:
    """Order-independent, stable JSON for dict params / bodies (``None`` → empty)."""
    if value is None:
        return ""
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)


def _make_key(scope: str, method: str, url_path: str, params: Any, body: Any) -> str:
    """Content hash over identity + request shape.

    ``scope`` (``base_url|email``) isolates profiles / sites that share one config
    dir; ``params`` (e.g. the ``fields`` projection) keeps the two ``/issue/{key}``
    variants — ``_FIELDS`` vs ``_LINK_FIELDS`` — from colliding.
    """
    payload = "\x00".join((scope, method.upper(), url_path, _canonical(params), _canonical(body)))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


class HttpCache:
    """A disk-persistent TTL memoize bound to one identity (*scope*).

    Lazy — construction opens no database, so :meth:`JiraClient.from_config` stays
    side-effect-free. Every :meth:`get` / :meth:`set` opens its own short-lived
    WAL connection and is fail-open.
    """

    def __init__(self, db_path: Path, *, ttl: int, scope: str) -> None:
        self._db_path = db_path
        self.ttl = ttl
        self._scope = scope

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._db_path, check_same_thread=False, timeout=5.0)
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA busy_timeout = 3000")
        return conn

    def get(self, method: str, url_path: str, params: Any, body: Any) -> Any | None:
        """Return the cached JSON if present and unexpired, else ``None`` (miss)."""
        if not self._db_path.exists():
            return None
        key = _make_key(self._scope, method, url_path, params, body)
        try:
            conn = self._connect()
            try:
                row = conn.execute(
                    "SELECT body, expires_at FROM http_cache WHERE key = ?", (key,)
                ).fetchone()
            finally:
                conn.close()
        except sqlite3.Error:
            return None  # fail-open: a cache read fault is just a miss
        if row is None:
            return None
        body_text, expires_at = row
        if expires_at is None or expires_at <= time.time():
            return None
        try:
            return json.loads(body_text)
        except (ValueError, TypeError):
            return None

    def set(self, method: str, url_path: str, params: Any, body: Any, value: Any) -> None:
        """Store *value* under the request key with this cache's TTL (best-effort)."""
        try:
            payload = json.dumps(value)
        except (TypeError, ValueError):
            return  # non-serializable response: skip caching, never raise
        key = _make_key(self._scope, method, url_path, params, body)
        now = time.time()
        try:
            self._db_path.parent.mkdir(parents=True, exist_ok=True)
            conn = self._connect()
            try:
                conn.executescript(_SCHEMA)
                conn.execute(
                    "INSERT OR REPLACE INTO http_cache "
                    "(key, method, url_path, body, stored_at, expires_at) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (key, method.upper(), url_path, payload, now, now + self.ttl),
                )
                conn.execute("DELETE FROM http_cache WHERE expires_at <= ?", (now,))
                conn.commit()
            finally:
                conn.close()
        except sqlite3.Error:
            return  # fail-open: a cache write fault is a no-op


def clear(*, cache_path: str | None = None, config_path: str | None = None) -> int:
    """Delete all cached responses; return the number removed (0 if absent)."""
    db = path(cache_path=cache_path, config_path=config_path)
    if not db.exists():
        return 0
    try:
        conn = sqlite3.connect(db, timeout=5.0)
        try:
            row = conn.execute("SELECT count(*) FROM http_cache").fetchone()
            removed = row[0] if row else 0
            conn.execute("DELETE FROM http_cache")
            conn.commit()
            return removed
        finally:
            conn.close()
    except sqlite3.Error:
        return 0


def status(*, cache_path: str | None = None, config_path: str | None = None) -> dict[str, Any]:
    """Path / existence / row-count / size summary (for ``cache status``)."""
    db = path(cache_path=cache_path, config_path=config_path)
    info: dict[str, Any] = {
        "path": str(db),
        "exists": db.exists(),
        "rows": 0,
        "size_bytes": 0,
    }
    if not db.exists():
        return info
    try:
        info["size_bytes"] = db.stat().st_size
        conn = sqlite3.connect(db, timeout=5.0)
        try:
            row = conn.execute("SELECT count(*) FROM http_cache").fetchone()
            info["rows"] = row[0] if row else 0
        finally:
            conn.close()
    except (sqlite3.Error, OSError):
        pass
    return info
