"""`cache` commands — local SQLite store inspection (infra, F006)."""

from typing import Annotated

import typer

from .. import cache as cache_lib
from .. import http_cache
from . import _common

app = typer.Typer(no_args_is_help=True, help="Inspect/manage the local SQLite cache.")

_CACHE = ("cache_path", "config_path")


@app.command()
def status(ctx: typer.Context) -> None:
    """Rows (per product), last sync, on-disk size, schema version. Feature: F010.

    The ``http_cache`` block reports the separate API response memoize
    (``http_cache.db``): its path, row count, and on-disk size.

    Example:
        jira-helper cache status
    Example output (--json):
        {"path": "~/.config/jira-helper/cache.db", "schema_version": 2, "rows": 128,
         "per_product": {"jira": 128},
         "meta": {"jira": {"last_sync_at": "2026-06-21T09:00:00Z", "watermark": "..."}},
         "size_bytes": 90112,
         "http_cache": {"path": "~/.config/jira-helper/http_cache.db", "exists": true,
                        "rows": 12, "size_bytes": 24576}}
    """

    def _status() -> dict:
        kw = _common.opt_kwargs(ctx, _CACHE)
        report = cache_lib.status(**kw)
        report["http_cache"] = http_cache.status(**kw)
        return report

    _common.run(ctx, _status)


@app.command()
def get(
    ctx: typer.Context,
    key: Annotated[str, typer.Argument(help="Cached record key, e.g. PROJA-123.")],
) -> None:
    """One cached record (table/JSON). Feature: F006.

    Returns the flat issue row (``raw`` left as its JSON string); errors with
    ``not_found`` (exit 2) when the key is not cached.

    Example:
        jira-helper cache get PROJA-123
    Example output (--json):
        {"key": "PROJA-123", "product": "jira", "summary": "Fix login", "status": "In Progress",
         "assignee_id": "5b10a2...", "effective_parent": "PROJA-50", "source": "native", ...}
    """
    _common.run(
        ctx,
        lambda: _common.require(
            cache_lib.get(key, **_common.opt_kwargs(ctx, _CACHE)),
            f"{key!r} not in cache (run `sync run` first, or check `cache status`)",
        ),
    )


@app.command()
def export(
    ctx: typer.Context,
    product: Annotated[str | None, typer.Option("--product", help="Limit to one product.")] = None,
) -> None:
    """Dump the whole cache as JSON for eyeballing / grep. Feature: F006.

    ``--product`` limits the dump to one product (default: all).

    Example:
        jira-helper --json cache export --product jira
    Example output (--json):
        [{"key": "PROJA-123", "product": "jira", "status": "In Progress",
          "effective_parent": "PROJA-50", "source": "native", ...}, ...]
    """
    _common.run(ctx, lambda: cache_lib.export(product=product, **_common.opt_kwargs(ctx, _CACHE)))


@app.command()
def clear(
    ctx: typer.Context,
    product: Annotated[
        str | None, typer.Option("--product", help="Wipe only this product.")
    ] = None,
) -> None:
    """Wipe cache (optionally per-product; use -y to skip confirmation). Feature: F010.

    Prompts before deleting unless the global ``-y/--yes`` is set; ``--product``
    wipes only that product's rows + sync-state. Returns the issue rows removed. A
    full wipe (no ``--product``) also flushes the API response memoize
    (``http_cache.db``), so it is the way to force-refresh cached live reads.

    Example:
        jira-helper -y cache clear --product jira
    Example output:
        128
    """
    if not _common.get_opts(ctx).yes:
        scope = f"product {product!r}" if product else "ALL products"
        typer.confirm(f"Wipe the cache ({scope})? This cannot be undone.", abort=True)

    def _clear() -> int:
        kw = _common.opt_kwargs(ctx, _CACHE)
        removed = cache_lib.clear(product=product, **kw)
        if product is None:  # a full wipe also flushes the API response cache
            http_cache.clear(**kw)
        return removed

    _common.run(ctx, _clear)


@app.command()
def path(ctx: typer.Context) -> None:
    """Print the cache file location (cache.db). Feature: F010.

    Honors ``--cache`` / falls back to beside the resolved config.

    Example:
        jira-helper cache path
    Example output:
        ~/.config/jira-helper/cache.db
    """
    _common.run_path(ctx, lambda: cache_lib.path(**_common.opt_kwargs(ctx, _CACHE)))
