"""F013 — file logging infra + the ``logs`` noun (locate/read the log file).

Every CLI run persists its activity to a **rotating log file** under the config
dir (default ``~/.config/jira-helper/logs/jira-helper.log``) so errors — including
uncaught tracebacks — are always recoverable. Credentials are redacted at write
time: the API token and any ``Authorization: Basic …`` header are replaced with
``****`` before a record is written. base_url / email / account-ids / JQL are kept
(the log is local and needed for debugging).

This module mirrors ``cache.py``: it holds both the infra (``configure`` + the
redaction/run-id filters + path helpers) and the noun verbs (``path`` / ``status``
/ ``show`` / ``clear``) the ``logs`` command group wraps. ``configure`` is the one
thing the CLI wires in (from the root callback); it is idempotent so the test
runner can invoke the app many times without stacking handlers.
"""

from __future__ import annotations

import logging
import logging.handlers
import os
import re
import secrets
import sys
from pathlib import Path
from typing import Any

from . import config
from .errors import NotFoundError

LOGGER_NAME = "jira_helper"
LOG_SUBDIR = "logs"
LOG_FILENAME = "jira-helper.log"

_MAX_BYTES = 2_000_000
_BACKUP_COUNT = 3
_FORMAT = "%(asctime)s %(levelname)-7s %(name)s [%(run_id)s] %(message)s"
_DATEFMT = "%Y-%m-%dT%H:%M:%S%z"
_REDACTED = "****"  # noqa: S105 — a redaction placeholder, not a secret
_LEVELS = ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL")
_SECRET_FLAGS = ("--token", "--api-token", "--password", "--secret")
# A `config set <key> <value>` whose key looks credential-ish gets its value masked in
# the startup argv line — leaf-segment match (so `profiles.x.api_token` is covered too)
# OR a hint substring, not just the literal `api_token`.
_SECRET_KEY_HINTS = ("token", "secret", "password")

# Module state: the literal secrets to scrub (the api_token) and the resolved log
# path of the most recent ``configure`` (so ``main_entry`` can name the file in a
# crash message). Process-global by design — there is one logger per process.
_secrets: set[str] = set()
_last_log_path: Path | None = None
# Whether the *global* -v/--verbose was set this run (set by `configure`). `main_entry`
# reads it to decide raw-traceback vs. clean one-liner — sniffing sys.argv would now
# also match a subcommand-level `--verbose` (e.g. `issue list --verbose`, the path tree).
_verbose: bool = False

_LINE_RE = re.compile(
    r"^(?P<timestamp>\S+)\s+(?P<level>\w+)\s+(?P<logger>\S+)\s+"
    r"\[(?P<run_id>[^\]]*)\]\s(?P<message>.*)$"
)


# --- redaction (credentials only) ---------------------------------------------


def register_secret(value: Any) -> None:
    """Register a literal secret to scrub from every log record (e.g. the api_token).

    Short/empty values are ignored: redacting a 1–2 char string would corrupt the
    whole log, and an empty token is not a secret.
    """
    if isinstance(value, str) and len(value) >= 6:
        _secrets.add(value)


def _scrub(text: str) -> str:
    """Replace registered secret literals + credential-shaped substrings with ``****``."""
    if not text:
        return text
    for secret in _secrets:
        text = text.replace(secret, _REDACTED)
    text = re.sub(r"Basic\s+[A-Za-z0-9+/=]{8,}", f"Basic {_REDACTED}", text)
    text = re.sub(r"(?i)(authorization)(\s*[:=]\s*)\S+", rf"\1\2{_REDACTED}", text)
    text = re.sub(
        r"(?i)\b(api_token|token|password|secret)(\s*[=:]\s*)\S+", rf"\1\2{_REDACTED}", text
    )
    return text


def _is_secret_key(key: str) -> bool:
    """Whether a ``config set`` key names a credential (leaf-segment or hint match)."""
    leaf = key.rsplit(".", 1)[-1].lower()
    return leaf in config._SECRET_KEYS or any(hint in leaf for hint in _SECRET_KEY_HINTS)


def sanitize_argv(argv: list[str]) -> list[str]:
    """A copy of *argv* with secret values masked (for the startup log line).

    Masks the value of ``config set <secret-key> <VALUE>`` and of any
    ``--token``/``--password``-style flag, then scrubs each token for good measure.
    The real ``sys.argv`` is never modified.
    """
    out: list[str] = []
    redact_next = False
    for i, arg in enumerate(argv):
        if redact_next:
            out.append(_REDACTED)
            redact_next = False
            continue
        low = arg.lower()
        if i >= 1 and argv[i - 1] == "set" and _is_secret_key(arg):
            out.append(arg)
            redact_next = True
        elif low in _SECRET_FLAGS:
            out.append(arg)
            redact_next = True
        elif "=" in arg and low.split("=", 1)[0] in _SECRET_FLAGS:
            out.append(f"{arg.split('=', 1)[0]}={_REDACTED}")
        else:
            out.append(_scrub(arg))
    return out


class _RedactionFilter(logging.Filter):
    """Scrub credentials from a record's message AND its traceback before a handler writes."""

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            message = record.getMessage()
        except Exception:  # pragma: no cover — defensive: never let logging crash the CLI
            message = str(record.msg)
        scrubbed = _scrub(message)
        if scrubbed != message:
            record.msg = scrubbed
            record.args = ()
        if record.exc_info or record.exc_text:
            if record.exc_text is None and record.exc_info:
                record.exc_text = logging.Formatter().formatException(record.exc_info)
            if record.exc_text:
                record.exc_text = _scrub(record.exc_text)
            # Drop exc_info so a handler can't re-format the raw (unscrubbed) traceback;
            # the formatter will append the scrubbed exc_text instead.
            record.exc_info = None
        return True


class _RunIdFilter(logging.Filter):
    """Stamp a per-run correlation id on every record (incl. ones from child loggers)."""

    def __init__(self, run_id: str) -> None:
        super().__init__()
        self.run_id = run_id

    def filter(self, record: logging.LogRecord) -> bool:
        if not hasattr(record, "run_id"):
            record.run_id = self.run_id
        return True


class _SecureRotatingFileHandler(logging.handlers.RotatingFileHandler):
    """RotatingFileHandler that creates every file 0o600 from the first byte (no TOCTOU)."""

    def _open(self):  # type: ignore[override]
        fd = os.open(self.baseFilename, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        return os.fdopen(fd, self.mode, encoding=self.encoding)


# --- path resolution ----------------------------------------------------------


def _cfg_safe(config_path: str | None) -> dict[str, Any]:
    """Load the resolved config, or ``{}`` if it's missing/broken (logging must not break)."""
    try:
        return config.load(config_path=config_path)
    except Exception:
        return {}


def log_dir(*, config_path: str | None = None) -> Path:
    """The directory holding the log file + its rotation backups.

    Precedence: ``$JIRA_HELPER_LOG_DIR`` → config ``log_dir`` → ``logs/`` beside the
    resolved config (mirrors how cache/stores sit beside the config).
    """
    env = os.environ.get("JIRA_HELPER_LOG_DIR")
    if env:
        return Path(env).expanduser()
    configured = _cfg_safe(config_path).get("log_dir")
    if configured:
        return Path(configured).expanduser()
    return config.config_dir(config_path) / LOG_SUBDIR


def path(*, config_path: str | None = None) -> Path:
    """Resolve the log FILE location (``<log_dir>/jira-helper.log``)."""
    return log_dir(config_path=config_path) / LOG_FILENAME


def ensure_log_dir(*, config_path: str | None = None) -> Path:
    """Resolve the log dir, create it (parents), best-effort tighten to 0o700, return it.

    The single owner of the log dir's existence + permission policy — :func:`configure`
    and ``sync.install`` both go through here. ``mkdir`` failures **propagate** (a caller
    that must degrade, like :func:`configure`, wraps the call); the 0o700 chmod is
    best-effort (a filesystem that can't chmod must not break logging or install).
    """
    directory = log_dir(config_path=config_path)
    directory.mkdir(parents=True, exist_ok=True)
    try:
        directory.chmod(0o700)
    except OSError:  # pragma: no cover — best-effort tightening
        pass
    return directory


# --- configure (the one call the CLI makes) -----------------------------------


def new_run_id() -> str:
    """A short, unique-enough correlation id for one CLI run."""
    return secrets.token_hex(4)


def get_logger(name: str = LOGGER_NAME) -> logging.Logger:
    """The package logger (or a child); all CLI logging flows through it."""
    return logging.getLogger(name)


def last_log_path() -> Path | None:
    """The log path resolved by the most recent :func:`configure` (``None`` if disabled)."""
    return _last_log_path


def verbose_enabled() -> bool:
    """Whether the global ``-v/--verbose`` was set this run (per the last :func:`configure`)."""
    return _verbose


def _enabled(cfg: dict[str, Any]) -> bool:
    env = os.environ.get("JIRA_HELPER_NO_LOG")
    if env and env.lower() in ("1", "true", "yes"):
        return False
    return cfg.get("log_enabled") is not False


def _make_handler(handler: logging.Handler, fmt: logging.Formatter, *filters: logging.Filter):
    handler.setFormatter(fmt)
    for f in filters:
        handler.addFilter(f)
    handler._jh_owned = True  # type: ignore[attr-defined]  # tag for idempotent teardown
    return handler


def configure(
    *,
    config_path: str | None = None,
    verbose: bool = False,
    quiet: bool = False,
    profile: str | None = None,
    cfg: dict[str, Any] | None = None,
) -> None:
    """Install the file (always) + stderr (``--verbose`` only) log handlers for this run.

    Idempotent: removes any handler this module previously installed before adding
    fresh ones, so the test runner can call it repeatedly without stacking. Never
    raises — an unwritable log dir/file degrades to no file logging (see
    :func:`last_log_path`). The resolved path is exposed via :func:`last_log_path`.
    """
    global _last_log_path, _verbose
    _verbose = bool(verbose)
    run_id = new_run_id()
    logger = logging.getLogger(LOGGER_NAME)
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    for owned in [h for h in logger.handlers if getattr(h, "_jh_owned", False)]:
        logger.removeHandler(owned)
        try:
            owned.close()
        except Exception:  # pragma: no cover — defensive
            pass

    if cfg is None:
        cfg = _cfg_safe(config_path)
    register_secret(cfg.get("api_token"))

    fmt = logging.Formatter(_FORMAT, datefmt=_DATEFMT)
    redaction = _RedactionFilter()
    runid = _RunIdFilter(run_id)

    log_path: Path | None = None
    if _enabled(cfg):
        try:
            directory = ensure_log_dir(config_path=config_path)
            # delay=False: open the file now, inside this try, so an open failure
            # (e.g. the log path is a directory) degrades here instead of escaping to
            # logging.handleError() at first emit and dumping a traceback to stderr.
            file_handler = _SecureRotatingFileHandler(
                str(directory / LOG_FILENAME),
                maxBytes=_MAX_BYTES,
                backupCount=_BACKUP_COUNT,
                encoding="utf-8",
                delay=False,
            )
            file_handler.setLevel(logging.DEBUG)
            logger.addHandler(_make_handler(file_handler, fmt, redaction, runid))
            log_path = directory / LOG_FILENAME
        except OSError:
            log_path = None

    if verbose and not quiet:
        console = logging.StreamHandler(sys.stderr)
        console.setLevel(logging.DEBUG)
        logger.addHandler(_make_handler(console, fmt, redaction, runid))

    _last_log_path = log_path
    logger.info(
        "start argv=%s version=%s config=%s profile=%s verbose=%s",
        " ".join(sanitize_argv(sys.argv)),
        _version(),
        config.path(config_path),
        profile,
        verbose,
    )


def _version() -> str:
    # Lazy: ``__version__`` is set on the package AFTER its submodules import (and this
    # module is one of them), so a top-level import would see it undefined.
    try:
        from . import __version__

        return __version__
    except Exception:  # pragma: no cover — defensive
        return "?"


# --- noun verbs (path/status/show/clear) --------------------------------------


def _parse_line(line: str) -> dict[str, str] | None:
    match = _LINE_RE.match(line)
    return match.groupdict() if match else None


def _first_timestamp(lines: list[str]) -> str | None:
    for line in lines:
        parsed = _parse_line(line)
        if parsed:
            return parsed["timestamp"]
    return None


def status(*, config_path: str | None = None) -> dict[str, Any]:
    """Log file path, size, line count, time span, rotation backups.

    Degrades gracefully (never raises) when the log file doesn't exist yet.
    """
    p = path(config_path=config_path)
    info: dict[str, Any] = {"path": str(p), "exists": p.exists()}
    if not p.exists():
        return info
    lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
    backups = sum(
        1 for i in range(1, _BACKUP_COUNT + 1) if p.with_name(f"{LOG_FILENAME}.{i}").exists()
    )
    info.update(
        size_bytes=p.stat().st_size,
        lines=len(lines),
        oldest=_first_timestamp(lines),
        newest=_first_timestamp([*reversed(lines)]),
        backups=backups,
    )
    return info


def show(
    *, lines: int = 50, level: str | None = None, config_path: str | None = None
) -> list[dict[str, str]]:
    """The last *lines* log records (most recent), optionally filtered by *level*.

    ``level`` (case-insensitive) is applied BEFORE the ``lines`` cap, so
    ``lines=20, level="ERROR"`` returns the last 20 errors. An unknown level raises
    ``NotFoundError`` (structured, exit 2). Reads the active file only (not backups).
    """
    selected = None
    if level is not None:
        selected = level.upper()
        if selected not in _LEVELS:
            raise NotFoundError(f"unknown log level {level!r} (choose from {', '.join(_LEVELS)})")
    p = path(config_path=config_path)
    if not p.exists():
        return []
    records: list[dict[str, str]] = []
    for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
        parsed = _parse_line(line)
        if selected is not None:
            if parsed is None or parsed["level"] != selected:
                continue
        records.append(parsed if parsed is not None else {"message": line})
    return records[-lines:] if lines and lines > 0 else records


def format_records(records: list[dict[str, str]]) -> str:
    """Human view for :func:`show`: one reconstructed log line per record."""
    out = []
    for r in records:
        if "timestamp" in r:
            out.append(
                f"{r['timestamp']} {r['level']} {r['logger']} [{r['run_id']}] {r['message']}"
            )
        else:
            out.append(r.get("message", ""))
    return "\n".join(out)


def clear(*, config_path: str | None = None) -> dict[str, int]:
    """Truncate the active log file to 0 bytes and unlink rotation backups.

    Truncates (rather than unlinking) the active file so a handler that already
    holds it open keeps writing. Returns the bytes reclaimed + backups removed.
    """
    p = path(config_path=config_path)
    reclaimed = 0
    if p.exists():
        reclaimed += p.stat().st_size
        with open(p, "w", encoding="utf-8"):
            pass
    backups_removed = 0
    for i in range(1, _BACKUP_COUNT + 1):
        backup = p.with_name(f"{LOG_FILENAME}.{i}")
        if backup.exists():
            reclaimed += backup.stat().st_size
            backup.unlink()
            backups_removed += 1
    return {"bytes_reclaimed": reclaimed, "backups_removed": backups_removed}
