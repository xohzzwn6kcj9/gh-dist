"""F006 — virtual-parent rules: a gitignored ``rules.yaml`` + a generic engine.

Conditional rules (first-match-wins) over the v1 matcher vocabulary
(``project`` / ``issue_type`` / ``linked_count``) with the ``linked`` parent
strategy, plus one-off ``manual_parents`` edges. The engine is generic; company
project keys live only in the user's local ``rules.yaml`` (never the repo).

Resolution precedence for an issue's *effective* parent (``effective_parent``):

1. a ``manual_parents`` edge for the key — an explicit one-off override, always wins;
2. the first conditional rule whose ``when`` matches AND that is applicable
   (``override: true`` OR the issue has no native parent) AND whose ``parent``
   strategy yields a key (first-match-wins);
3. the issue's native Jira parent;
4. otherwise none → the issue is a root.

The pure ``effective_parent`` core is shared with ``issue`` (roots / tree
traversal); ``resolve`` is its live, single-issue wrapper (``rule test``). Store
I/O mirrors the account / org YAML stores.
"""

from __future__ import annotations

import builtins
from pathlib import Path
from typing import Any

import yaml

from . import cache, config
from .errors import ConfigError

RULES_FILENAME = "rules.yaml"
_RULES_KEY = "virtual_parent_rules"
_MANUAL_KEY = "manual_parents"

# The fixed, tested v1 vocabulary (``validate`` flags anything outside it).
_WHEN_MATCHERS = frozenset({"project", "issue_type", "linked_count"})
_PARENT_STRATEGIES = frozenset({"linked"})

Rule = dict[str, Any]


def path(*, config_path: str | None = None) -> Path:
    """Resolve the rules.yaml location (beside the config)."""
    return config.config_dir(config_path) / RULES_FILENAME


# --- store I/O (edges) --------------------------------------------------------


def _read(config_path: str | None) -> tuple[list[Rule], list[dict[str, str]]]:
    """Load (conditional rules, manual edges) from rules.yaml (empties if absent)."""
    p = path(config_path=config_path)
    if not p.exists():
        return [], []
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    if not isinstance(data, dict):
        return [], []
    rules = data.get(_RULES_KEY) or []
    manual = data.get(_MANUAL_KEY) or []
    return (
        rules if isinstance(rules, builtins.list) else [],
        manual if isinstance(manual, builtins.list) else [],
    )


def _write(config_path: str | None, rules: list[Rule], manual: list[dict[str, str]]) -> Path:
    p = path(config_path=config_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    # sort_keys=False keeps authored rule order (first-match-wins is order-sensitive).
    p.write_text(
        yaml.safe_dump(
            {_RULES_KEY: rules, _MANUAL_KEY: manual}, sort_keys=False, allow_unicode=True
        ),
        encoding="utf-8",
    )
    return p


def _manual_index(manual: list[dict[str, str]]) -> dict[str, str]:
    """child → parent map from the manual edges.

    First edge for a child wins — matching ``add``'s first-match upsert and
    ``validate``'s "first is canonical, the rest are ``duplicate_child``" so the
    resolver, the writer, and the linter all agree on which edge governs.
    """
    index: dict[str, str] = {}
    for e in manual:
        child, parent = e.get("child"), e.get("parent")
        if child and parent:
            index.setdefault(child, parent)
    return index


def load(*, config_path: str | None = None) -> tuple[list[Rule], dict[str, str]]:
    """Parsed conditional rules + a child→parent manual-edge index (the engine inputs)."""
    rules, manual = _read(config_path)
    return rules, _manual_index(manual)


# --- pure resolution engine (no I/O) -----------------------------------------


def _matches(
    when: dict[str, Any], *, project: str | None, issue_type: str | None, linked_count: int
) -> bool:
    """True when every present v1 matcher equals the issue's attribute."""
    if "project" in when and when["project"] != project:
        return False
    if "issue_type" in when and when["issue_type"] != issue_type:
        return False
    if "linked_count" in when and when["linked_count"] != linked_count:
        return False
    return True


def _apply_strategy(strategy: Any, linked_keys: list[str]) -> str | None:
    """Virtual parent key for a strategy. ``linked`` = the sole link (else unresolved)."""
    if strategy == "linked":
        return linked_keys[0] if len(linked_keys) == 1 else None
    return None


def effective_parent(
    *,
    key: str,
    project: str | None,
    issue_type: str | None,
    native_parent: str | None,
    linked_keys: list[str] | None,
    rules: list[Rule],
    manual: dict[str, str],
) -> tuple[str | None, str | None]:
    """The effective parent of an issue + the source that set it.

    Returns ``(parent_key, source)`` where *source* is the firing rule's ``name``,
    ``"manual"``, ``"native"``, or ``None`` (a root). See the module docstring for
    the precedence. Pure — callers supply the issue's attributes + the rule set.
    """
    links = linked_keys or []
    # Every path self-guards (parent != key): a self-edge from a hand-edited store
    # is treated as "no parent" rather than declaring an issue its own parent.
    if manual.get(key) and manual[key] != key:
        return manual[key], "manual"
    for rule in rules:
        when = rule.get("when") or {}
        if not _matches(when, project=project, issue_type=issue_type, linked_count=len(links)):
            continue
        if native_parent and not rule.get("override", False):
            continue  # a non-override rule only fills an empty slot
        parent = _apply_strategy(rule.get("parent"), links)
        if parent and parent != key:
            return parent, rule.get("name") or "(unnamed rule)"
    if native_parent and native_parent != key:
        return native_parent, "native"
    return None, None


def effective_parent_of_node(
    node: dict[str, Any], rules: list[Rule], manual: dict[str, str]
) -> tuple[str | None, str | None]:
    """``effective_parent`` over an issue *node* dict (the shape ``issue``/cache emit).

    The single place the node-dict → engine-args mapping lives, shared by ``issue``
    traversal and ``resolve`` so the two never drift.
    """
    return effective_parent(
        key=node["key"],
        project=node.get("project"),
        issue_type=node.get("issue_type"),
        native_parent=node.get("parent"),
        linked_keys=node.get("linked_keys"),
        rules=rules,
        manual=manual,
    )


# --- public API ---------------------------------------------------------------


def list(*, config_path: str | None = None) -> dict[str, Any]:
    """F006: the parsed conditional rules + manual edges (as stored)."""
    rules, manual = _read(config_path)
    return {_RULES_KEY: rules, _MANUAL_KEY: manual}


def add(child: str, parent: str, *, config_path: str | None = None) -> dict[str, str]:
    """F006: append/update a manual parent edge (child → parent; upsert by child)."""
    if child == parent:
        raise ConfigError(f"a manual edge cannot point an issue at itself ({child})")
    rules, manual = _read(config_path)
    for edge in manual:
        if edge.get("child") == child:
            edge["parent"] = parent
            break
    else:
        manual.append({"child": child, "parent": parent})
    _write(config_path, rules, manual)
    return {"child": child, "parent": parent}


def remove(child: str, *, config_path: str | None = None) -> bool:
    """F006: drop the manual edge for *child*; return whether one was removed."""
    rules, manual = _read(config_path)
    kept = [e for e in manual if e.get("child") != child]
    if len(kept) == len(manual):
        return False
    _write(config_path, rules, kept)
    return True


def _node_from_cache(
    key: str, *, cache_path: str | None, config_path: str | None
) -> dict[str, Any] | None:
    """Reconstruct KEY's rule-engine node from cached columns + ``issue_link`` (None if
    not cached). ``linked_keys`` unions both link directions to match ``_linked_keys``."""
    if not cache.path(cache_path=cache_path, config_path=config_path).exists():
        return None
    conn = cache.connect(cache_path=cache_path, config_path=config_path)
    try:
        row = conn.execute(
            "SELECT project, issue_type, native_parent FROM issue WHERE key = ?", (key,)
        ).fetchone()
        if row is None:
            return None
        return cache.engine_node(
            conn,
            key=key,
            project=row["project"],
            issue_type=row["issue_type"],
            native_parent=row["native_parent"],
        )
    finally:
        conn.close()


def resolve(
    key: str,
    *,
    profile: str | None = None,
    config_path: str | None = None,
    cache_path: str | None = None,
    no_cache: bool = False,
) -> dict[str, Any]:
    """F006 (``rule test``): the effective parent for KEY + which rule fired.

    Reads KEY from the cache when populated (F010 cutover); otherwise fetches it live
    (also the fallback for a not-yet-synced KEY). ``--no-cache`` forces the live read.
    """
    rules, manual = load(config_path=config_path)
    node = None
    if not no_cache:
        node = _node_from_cache(key, cache_path=cache_path, config_path=config_path)
    if node is None:
        from . import issue  # local import: ``issue`` imports us at module load

        node = issue.fetch_node(key, profile=profile, config_path=config_path)
    parent, source = effective_parent_of_node(node, rules, manual)
    return {
        "key": node["key"],
        "native_parent": node.get("parent"),
        "effective_parent": parent,
        "source": source,
        "linked_keys": node.get("linked_keys") or [],
    }


def validate(*, config_path: str | None = None) -> list[dict[str, Any]]:
    """F006: schema + ambiguity + cycle checks ([] = clean). Mirrors ``org validate``."""
    rules, manual = _read(config_path)
    problems: list[dict[str, Any]] = []

    def report(level: str, code: str, where: str, message: str) -> None:
        problems.append({"level": level, "code": code, "rule": where, "message": message})

    seen_names: set[str] = set()
    for i, rule in enumerate(rules):
        name = rule.get("name") or f"#{i}"
        if not rule.get("name"):
            report("error", "missing_name", name, "rule has no name")
        if name in seen_names:
            report("error", "duplicate_name", name, f"duplicate rule name {name!r}")
        seen_names.add(name)
        when = rule.get("when")
        if not isinstance(when, dict) or not when:
            # A rule with no matchers is already broken; don't pile consequential
            # strategy/ambiguity noise on top — report once and move on.
            report("error", "bad_when", name, "rule has no 'when' matchers")
            continue
        for matcher in when:
            if matcher not in _WHEN_MATCHERS:
                report("error", "unknown_matcher", name, f"unknown 'when' matcher {matcher!r}")
        strategy = rule.get("parent")
        if strategy not in _PARENT_STRATEGIES:
            report("error", "unknown_strategy", name, f"unknown parent strategy {strategy!r}")
        if strategy == "linked" and when.get("linked_count") != 1:
            report(
                "warning",
                "ambiguous_linked",
                name,
                "parent: linked without 'linked_count: 1' only fires when exactly one link exists",
            )

    seen_children: set[str] = set()
    for edge in manual:
        child, parent = edge.get("child"), edge.get("parent")
        if not child or not parent:
            report("error", "bad_edge", str(edge), "manual edge needs both 'child' and 'parent'")
            continue
        if child == parent:
            report("error", "self_loop", child, f"manual edge {child!r} points at itself")
        if child in seen_children:
            report("error", "duplicate_child", child, f"duplicate manual edge for {child!r}")
        seen_children.add(child)

    # Exclude self-loops (already reported as `self_loop`) so they aren't
    # double-reported as a `cycle`.
    index = {c: p for c, p in _manual_index(manual).items() if c != p}
    for start in index:
        chain: set[str] = set()
        cur: str | None = start
        while cur is not None:
            if cur in chain:
                report("error", "cycle", start, f"manual parent chain cycles at {cur!r}")
                break
            chain.add(cur)
            cur = index.get(cur)
    return problems
