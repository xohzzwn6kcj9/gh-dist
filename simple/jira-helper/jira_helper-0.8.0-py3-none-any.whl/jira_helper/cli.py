"""jira-helper CLI — Typer app: global flags + noun groups + top-level commands.

A thin wrapper layer: parse args, stash the resolved global options on the Typer
context, dispatch to the library, render. No behavior lives here (the
library-first contract). Invocation grammar::

    jira-helper [GLOBAL FLAGS] <noun> <verb> [args] [flags]

Global flags are defined once on the root callback and therefore precede the
noun (e.g. ``jira-helper --json issue list --assignee alice``).
"""

import re
import stat
import sys
import textwrap
from pathlib import Path
from typing import Annotated, Any

import typer

from . import __version__, output
from . import cache as cache_lib
from . import config as config_lib
from . import logs as logs_lib
from .client import JiraClient
from .commands import _common, account, cache, config, issue, logs, org, page, rule, sync
from .errors import JiraHelperError

app = typer.Typer(
    name="jira-helper",
    no_args_is_help=True,
    add_completion=False,
    help="Admin toolkit for Atlassian Cloud (Jira now, Confluence later). "
    "Resolve people↔account-ids, manage the org hierarchy, query/cache tickets.",
)

app.add_typer(config.app, name="config")
app.add_typer(account.app, name="account")
app.add_typer(issue.app, name="issue")
app.add_typer(org.app, name="org")
app.add_typer(rule.app, name="rule")
app.add_typer(cache.app, name="cache")
app.add_typer(sync.app, name="sync")
app.add_typer(logs.app, name="logs")
app.add_typer(page.app, name="page")  # F012: Confluence — purely additive


@app.callback()
def main(
    ctx: typer.Context,
    json_out: Annotated[bool, typer.Option("--json", help="Machine-readable JSON output.")] = False,
    config_path: Annotated[
        Path | None, typer.Option("--config", help="Override config file location.")
    ] = None,
    profile: Annotated[
        str | None, typer.Option("--profile", help="Named credential profile / Atlassian site.")
    ] = None,
    cache_path: Annotated[
        Path | None, typer.Option("--cache", help="Override cache file location.")
    ] = None,
    no_cache: Annotated[
        bool, typer.Option("--no-cache", help="Bypass the cache; force a live API call.")
    ] = False,
    quiet: Annotated[bool, typer.Option("--quiet", "-q", help="Quieter logs.")] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="More verbose logs.")] = False,
    color: Annotated[
        bool | None,
        typer.Option("--color/--no-color", help="Colorize output (auto-off when piped)."),
    ] = None,
    yes: Annotated[
        bool, typer.Option("--yes", "-y", help="Skip confirmation prompts on destructive ops.")
    ] = False,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Show what would happen; don't apply.")
    ] = False,
) -> None:
    """Global flags shared by every command (stashed on the context)."""
    ctx.obj = _common.GlobalOptions(
        json=json_out,
        config=config_path,
        profile=profile,
        cache=cache_path,
        no_cache=no_cache,
        quiet=quiet,
        verbose=verbose,
        color=color,
        yes=yes,
        dry_run=dry_run,
    )
    # F013: start file logging for this run (errors → log even when uncaught). Never
    # raises; an unwritable log dir degrades to no file logging.
    logs_lib.configure(
        config_path=_common.as_str(config_path),
        verbose=verbose,
        quiet=quiet,
        profile=profile,
    )


@app.command()
def version(ctx: typer.Context) -> None:
    """Print version / build info.

    Example:
        jira-helper version
    Example output:
        0.7.0
    """
    if _common.get_opts(ctx).json:
        output.render({"name": "jira-helper", "version": __version__}, as_json=True)
    else:
        typer.echo(__version__)


@app.command()
def init(ctx: typer.Context) -> None:
    """First-run onboarding wizard (alias of 'config init'). Feature: F001.

    Example:
        jira-helper init
    Example output:
        ~/.config/jira-helper/config.yaml
    """
    config.run_init(ctx)


@app.command()
def doctor(ctx: typer.Context) -> None:
    """Read-only health check: config valid? creds ok? cache present? Feature: F001.

    Each probe degrades to an error string instead of raising; honors --json.

    Example:
        jira-helper --json doctor
    Example output (--json):
        {"config": "ok", "config_perms_ok": true, "creds": "ok (홍길동)", "cache_exists": true, ...}
    """
    opts = _common.get_opts(ctx)
    _common.run(
        ctx,
        lambda: _doctor_report(
            config_path=_common.as_str(opts.config),
            profile=opts.profile,
            cache_path=_common.as_str(opts.cache),
        ),
    )


def _doctor_report(
    *, config_path: str | None, profile: str | None, cache_path: str | None
) -> dict[str, Any]:
    """Aggregate a read-only health summary; each probe degrades, never raises."""
    report: dict[str, Any] = {}
    cfg_path = config_lib.path(config_path)
    report["config_path"] = str(cfg_path)
    report["config_exists"] = cfg_path.exists()

    try:
        data = config_lib.load(config_path=config_path)
    except JiraHelperError as exc:
        report["config"] = f"error: {exc}"
        data = {}
    else:
        missing = [k for k in config_lib.REQUIRED_KEYS if not data.get(k)]
        report["config"] = "ok" if not missing else f"missing: {', '.join(missing)}"

    if cfg_path.exists():
        mode = stat.S_IMODE(cfg_path.stat().st_mode)
        report["config_perms"] = format(mode, "04o")
        report["config_perms_ok"] = mode == 0o600

    if all(data.get(k) for k in config_lib.REQUIRED_KEYS):
        report["creds"] = _probe_creds(config_path=config_path, profile=profile)
    else:
        report["creds"] = "skipped (config incomplete)"

    db = cache_lib.path(cache_path=cache_path, config_path=config_path)
    report["cache_path"] = str(db)
    report["cache_exists"] = db.exists()
    return report


def _probe_creds(*, config_path: str | None, profile: str | None) -> str:
    """Live, read-only ``/myself`` ping (no chmod side effect, unlike `config verify`)."""
    try:
        with JiraClient.from_config(config_path=config_path, profile=profile) as client:
            me = client.get("/myself") or {}
    except JiraHelperError as exc:
        return f"error: {exc}"
    return f"ok ({me.get('displayName')})"


@app.command()
def spec(ctx: typer.Context) -> None:
    """Emit the entire command tree (commands, args, flags, types, examples) for LLM/MCP ingest.

    Feature: F011. Use '--json' for the full structured tree; without it, a
    compact list of command paths.

    Example:
        jira-helper --json spec
    Example output (--json):
        {"name": "jira-helper", "version": "0.7.0",
         "groups": [{"path": "issue", "help": "Query Jira issues (F004–F008)."}, ...],
         "commands": [{"path": "issue list", "example": "jira-helper issue list ...",
                       "example_output": "[{...}]", "params": [...]}, ...]}
    """
    opts = _common.get_opts(ctx)
    data = build_spec()
    if opts.json:
        output.render(data, as_json=True)
    else:
        typer.echo("\n".join(cmd["path"] for cmd in data["commands"]))


# --- spec introspection (F011) -------------------------------------------------


def build_spec(typer_app: typer.Typer | None = None) -> dict:
    """Introspect the (Typer-vendored) Click command tree into a structured dict.

    Duck-typed (``.commands`` / ``param_type_name``) so it stays robust across
    Typer versions, which vendor Click and do not expose it as a top-level import.
    """
    command = typer.main.get_command(typer_app or app)
    groups: list[dict] = []
    commands: list[dict] = []
    _walk(command, [], groups, commands)
    return {
        "name": "jira-helper",
        "version": __version__,
        "global_flags": [_describe_param(p) for p in command.params if _keep_param(p)],
        "groups": groups,
        "commands": commands,
    }


def _walk(command: Any, prefix: list[str], groups: list[dict], commands: list[dict]) -> None:
    """Recurse the Click tree, collecting noun groups and leaf commands in place."""
    subcommands = getattr(command, "commands", None)
    if subcommands:
        if prefix:  # the root app itself is not a noun group
            help_text = (command.help or command.short_help or "").strip()
            groups.append({"path": " ".join(prefix), "help": help_text})
        for name in sorted(subcommands):
            _walk(subcommands[name], [*prefix, name], groups, commands)
        return
    description, example, example_output = _split_example(
        (command.help or command.short_help or "").strip()
    )
    commands.append(
        {
            "path": " ".join(prefix),
            "help": description,
            "example": example,
            "example_output": example_output,
            "params": [_describe_param(p) for p in command.params if _keep_param(p)],
        }
    )


def _split_example(text: str) -> tuple[str, str | None, str | None]:
    """Split help into (description, example-invocation, example-output).

    Recognizes an ``Example:`` block (the invocation) and an optional
    ``Example output[ (--json)]:`` block. Each returned block has its label line
    and source indentation stripped, ready for verbatim LLM/MCP consumption.
    """
    text = (text or "").strip()
    out_pos = text.find("Example output")
    ex_pos = text.find("Example:")
    if ex_pos == -1 and out_pos == -1:
        return text, None, None
    first = min(p for p in (ex_pos, out_pos) if p != -1)
    description = text[:first].strip()
    example = None
    if ex_pos != -1:
        end = out_pos if (out_pos != -1 and out_pos > ex_pos) else len(text)
        example = _strip_block(text[ex_pos:end])
    example_output = _strip_block(text[out_pos:]) if out_pos != -1 else None
    return description, example, example_output


def _strip_block(block: str) -> str:
    """Drop an ``Example[ output ...]:`` label line and dedent the block body."""
    head, _, body = block.strip("\n").partition("\n")
    head = re.sub(r"^Example(?:\s+output[^:]*)?:\s*", "", head).strip()
    body = textwrap.dedent(body).strip()
    if head and body:
        return f"{head}\n{body}"
    return head or body


def _keep_param(param: Any) -> bool:
    return getattr(param, "name", None) not in (None, "help")


def _describe_param(param: Any) -> dict:
    default = param.default
    if callable(default):
        default = None
    nargs = getattr(param, "nargs", 1)
    return {
        "name": param.name,
        "kind": getattr(param, "param_type_name", "parameter"),
        # both halves of a toggle (--color / --no-color) so the spec is complete
        "opts": [*getattr(param, "opts", []), *getattr(param, "secondary_opts", [])],
        "type": getattr(param.type, "name", str(param.type)),
        "required": bool(param.required),
        # variadic positional args carry nargs == -1 (Click never sets .multiple on them)
        "multiple": bool(getattr(param, "multiple", False)) or nargs == -1,
        "nargs": nargs,
        "default": default,
        "help": getattr(param, "help", None),
    }


def main_entry() -> None:
    """Console-script entry point: run the Typer app, persisting any uncaught crash (F013).

    Expected errors are already rendered cleanly by ``_common.run``; this wrapper
    only catches a genuine bug that escaped the command layer — it logs the full
    (redacted) traceback to the log file, then shows a one-line pointer to the log
    instead of a raw traceback (re-raise the real traceback under ``-v``).
    """
    try:
        app()
    except (SystemExit, KeyboardInterrupt):
        raise  # normal exits / Ctrl-C / click.Abort(→SystemExit) pass through untouched
    except BaseException as exc:
        logs_lib.get_logger().error("uncaught exception", exc_info=exc)
        if "-v" in sys.argv or "--verbose" in sys.argv:
            raise
        typer.secho(
            f"internal error: {exc} (see log: {logs_lib.last_log_path()})",
            fg=typer.colors.RED,
            err=True,
        )
        # SystemExit (not typer.Exit): we're the process entry point, outside Click's
        # invocation, so nothing would translate a typer.Exit into a process exit.
        raise SystemExit(1) from exc
