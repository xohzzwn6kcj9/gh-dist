"""F004–F008 — issue queries (list / roots / tree / get).

``--json`` is a render concern owned by the CLI, not here. People filters accept
names or account-ids (names resolved via the account store, F003); unknown values
pass through as account-ids so raw ids work without a store entry.

F006 (``roots`` / ``tree`` / ``list --roots``) walks each issue's *effective*
parent — native Jira parent overlaid with the virtual-parent rules (``rule``
module). ``roots`` is sugar for ``list(..., roots=True)``: take a result set and
collapse it to the distinct roots its members live under. ``tree`` climbs to an
issue's effective root, then expands the subtree below it.

**Cache cutover (F010).** When the local cache is populated, the *traversal* reads
(``roots`` / ``list(roots=True)`` / ``tree``) run off a recursive CTE over the
stored ``effective_parent`` — one index scan instead of per-ancestor live GETs,
and conditional-rule virtual descendants become enumerable (``WHERE
effective_parent = X``). They fall back transparently to the live walk when the
cache is empty/missing, ``--no-cache`` is set, or a raw ``--jql`` is given (the
cache can't evaluate arbitrary JQL). Plain ``list`` (non-roots) and ``get`` stay
live.
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from typing import Any

from . import (
    account,
    cache,  # cache-backed traversal (F010 cutover); imports config only, no cycle
)
from . import org as org_lib  # aliased so the `org` *parameter* can't shadow the module
from . import rule as rule_lib  # pure effective_parent engine (rule.resolve imports us lazily)
from ._util import dedup
from .errors import JiraApiError, JiraHelperError

Issue = dict[str, Any]

# Fields requested from Jira and projected onto every Issue dict.
_FIELDS = ["summary", "status", "issuetype", "assignee", "project", "parent", "created", "updated"]
# Plus issue links when the virtual-parent engine needs them (roots / tree / rule test).
_LINK_FIELDS = [*_FIELDS, "issuelinks"]
_PAGE_SIZE = 100
# Safety cap against the known runaway-nextPageToken bug (~10k issues at this size).
_MAX_PAGES = 100
# Max account-ids per `assignee in (...)` clause; a whole-실 union is chunked + merged
# so a large org never blows past Jira's JQL/request-size limit (F007).
_ASSIGNEE_BATCH = 50
# Bound the native-subtree fetch in `tree` against a pathological hierarchy.
_TREE_MAX_NODES = 500


def _jql_quote(value: str) -> str:
    """Quote a value for safe inclusion in JQL (escape backslash + double-quote)."""
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _resolve_assignee(name_or_id: str, config_path: str | None) -> str:
    """Map a stored name to its account-id; pass an unknown value through unchanged."""
    entry = account.get(name_or_id, config_path=config_path)
    return entry["account_id"] if entry else name_or_id


def _resolve_ids(
    assignee: list[str] | None, org_units: list[str] | None, config_path: str | None
) -> list[str]:
    """Combined, de-duped account-ids from --assignee (names/ids) + --org subtree expansion."""
    ids: list[str] = [_resolve_assignee(a, config_path) for a in (assignee or [])]
    for unit in org_units or []:
        ids.extend(org_lib.member_ids(unit, config_path=config_path))
    return dedup(ids)


def _date_clauses(created_from: str | None, created_to: str | None) -> list[str]:
    clauses: list[str] = []
    if created_from:
        clauses.append(f"created >= {_jql_quote(created_from)}")
    if created_to:
        clauses.append(f"created <= {_jql_quote(created_to)}")
    return clauses


def _assigned_clause(ids: list[str], assigned_from: str | None, assigned_to: str | None) -> str:
    """A historical ``assignee WAS IN (...)`` clause — who *was* assigned in a window (F008).

    Unlike the ``assignee in (...)`` equality (the *current* assignee), this matches
    issues whose assignee equalled one of *ids* at some instant inside the range: Jira
    evaluates ``WAS`` against the change history, so it survives reassignment. ``DURING``
    for a closed range, ``AFTER`` / ``BEFORE`` for an open-ended one. Dates pass straight
    through (Jira validates); a bare ``YYYY-MM-DD`` means start-of-day in the querying
    account's timezone, so the ``--to`` day's tail is excluded — same boundary as
    ``--created-to`` (an inclusive-end normalization is a deliberate follow-up).
    Precondition: *ids* non-empty and at least one bound given (enforced by ``list``).
    """
    vals = ", ".join(_jql_quote(i) for i in ids)
    if assigned_from and assigned_to:
        window = f"DURING ({_jql_quote(assigned_from)}, {_jql_quote(assigned_to)})"
    elif assigned_from:
        window = f"AFTER {_jql_quote(assigned_from)}"
    else:
        window = f"BEFORE {_jql_quote(assigned_to)}"
    return f"assignee WAS IN ({vals}) {window}"


def _compose_jql(
    id_chunk: list[str], date_clauses: list[str], assignee_clause: str | None = None
) -> str:
    """One JQL string from an assignee clause + date clauses, newest-first.

    *assignee_clause* (the F008 ``assignee WAS IN ...`` historical clause) is appended
    verbatim *instead* of the default ``assignee in (...)`` equality when given;
    otherwise the equality is built from *id_chunk* as before.
    """
    clauses: list[str] = []
    if assignee_clause:
        clauses.append(assignee_clause)
    elif id_chunk:
        clauses.append(f"assignee in ({', '.join(_jql_quote(i) for i in id_chunk)})")
    clauses.extend(date_clauses)
    return " AND ".join(clauses) + " ORDER BY created DESC"


def _chunks(seq: list[str], size: int) -> list[list[str]]:
    return [seq[i : i + size] for i in range(0, len(seq), size)]


def _parse_issue(raw: dict[str, Any]) -> Issue:
    """Project a raw Jira issue onto the flat Issue shape (cache-schema aligned)."""
    f = raw.get("fields") or {}
    assignee = f.get("assignee") or {}
    return {
        "key": raw.get("key"),
        "summary": f.get("summary"),
        "status": (f.get("status") or {}).get("name"),
        "issue_type": (f.get("issuetype") or {}).get("name"),
        "assignee": assignee.get("displayName"),
        "assignee_id": assignee.get("accountId"),
        "project": (f.get("project") or {}).get("key"),
        "parent": (f.get("parent") or {}).get("key"),
        "created": f.get("created"),
        "updated": f.get("updated"),
    }


def _linked_keys(raw: dict[str, Any]) -> list[str]:
    """The keys of every issue linked to *raw* (both link directions, de-duped)."""
    links = (raw.get("fields") or {}).get("issuelinks") or []
    keys: list[str] = []
    for link in links:
        for side in ("inwardIssue", "outwardIssue"):
            key = (link.get(side) or {}).get("key")
            if key:
                keys.append(key)
    return dedup(keys)


def _link_rows(raw: dict[str, Any]) -> list[tuple[str, str, str]]:
    """``(src, dst, type)`` for every link of *raw* (both directions, de-duped).

    Unlike ``_linked_keys`` (which flattens to bare keys for the rule engine), this
    keeps the Jira link-type name so ``sync`` can populate ``issue_link`` for a
    future ``linked_by_type`` strategy (F006).
    """
    src = raw.get("key")
    links = (raw.get("fields") or {}).get("issuelinks") or []
    rows: list[tuple[str, str, str]] = []
    for link in links:
        ltype = (link.get("type") or {}).get("name") or "relates"
        for side in ("inwardIssue", "outwardIssue"):
            dst = (link.get(side) or {}).get("key")
            if src and dst:
                rows.append((src, dst, ltype))
    return [*dict.fromkeys(rows)]


def _node_from_raw(raw: dict[str, Any]) -> Issue:
    """A parsed issue plus its ``linked_keys`` — the unit the rule engine resolves."""
    return {**_parse_issue(raw), "linked_keys": _linked_keys(raw)}


def _public_issue(node: Issue) -> Issue:
    """Drop traversal-only fields so roots output matches the plain ``list`` shape."""
    return {k: v for k, v in node.items() if k != "linked_keys"}


def _search_raw(
    client: Any, jql: str, *, with_links: bool = False, max_pages: int = _MAX_PAGES
) -> Iterator[dict[str, Any]]:
    """Yield each *raw* Jira issue for a JQL search, following ``nextPageToken``.

    The raw-emitting core of ``_search``: ``sync`` consumes it to keep the full
    payload (the cache ``raw`` column + typed ``issue_link`` rows), and passes a
    higher ``max_pages`` than the live read default.
    """
    fields = _LINK_FIELDS if with_links else _FIELDS
    token: str | None = None
    for _ in range(max_pages):
        body: dict[str, Any] = {"jql": jql, "fields": fields, "maxResults": _PAGE_SIZE}
        if token:
            body["nextPageToken"] = token
        data = client.post("/search/jql", json=body) or {}  # tolerate an empty body
        yield from data.get("issues") or []
        token = data.get("nextPageToken")
        if data.get("isLast") or not token:
            break


def _search(
    client: Any, jql: str, *, with_links: bool = False, max_pages: int = _MAX_PAGES
) -> list[Issue]:
    """Run a JQL search, parsing each issue to the flat ``Issue`` shape (to last page)."""
    parse = _node_from_raw if with_links else _parse_issue
    return [
        parse(raw) for raw in _search_raw(client, jql, with_links=with_links, max_pages=max_pages)
    ]


def _fetch_node(client: Any, key: str) -> Issue:
    """GET one issue (with linked-issue keys) as a rule-engine node."""
    raw = client.get(f"/issue/{key}", fields=",".join(_LINK_FIELDS))
    return _node_from_raw(raw or {})


def _node_fetcher(client: Any) -> tuple[Any, dict[str, Issue]]:
    """A memoized node fetcher + its memo dict, shared by roots/tree traversal."""
    memo: dict[str, Issue] = {}

    def fetch(key: str) -> Issue:
        if key not in memo:
            memo[key] = _fetch_node(client, key)
        return memo[key]

    return fetch, memo


def _climb_to_root(
    fetch, start_key: str, rules: list[dict[str, Any]], manual: dict[str, str]
) -> tuple[Issue, dict[str, list[str]]]:
    """Climb effective parents from *start_key* to its root.

    Returns ``(root_node, climb_children)`` where ``climb_children`` maps each
    ancestor key → the child we climbed from. That lets ``tree`` splice a *virtual*
    (rule-derived) ancestor edge back into a native-only downward walk so the
    queried node never drops out of its own tree. A 404 on an ancestor (deleted or
    not-visible parent) stops the climb at the furthest *visible* node rather than
    aborting the whole traversal; other API errors still propagate.
    """
    node = fetch(start_key)
    seen: set[str] = set()
    climb_children: dict[str, list[str]] = {}
    while node["key"] not in seen:  # cycle-guard: stop if we revisit a key
        seen.add(node["key"])
        parent_key, _ = rule_lib.effective_parent_of_node(node, rules, manual)
        if not parent_key:
            break
        try:
            parent_node = fetch(parent_key)
        except JiraApiError as exc:
            if exc.status == 404:
                break  # parent gone / not visible → current node is the visible root
            raise
        climb_children.setdefault(parent_key, []).append(node["key"])
        node = parent_node
    return node, climb_children


def _collapse_to_roots(
    client: Any, seeds: list[Issue], rules: list[dict[str, Any]], manual: dict[str, str]
) -> list[Issue]:
    """Walk each seed's effective-parent chain to its root; return the distinct roots."""
    fetch, memo = _node_fetcher(client)
    memo.update({s["key"]: s for s in seeds})  # prime with seeds (they carry linked_keys)

    roots: dict[str, Issue] = {}
    for seed in seeds:
        root, _ = _climb_to_root(fetch, seed["key"], rules, manual)
        roots.setdefault(root["key"], root)
    return sorted(
        (_public_issue(r) for r in roots.values()),
        key=lambda i: i.get("created") or "",
        reverse=True,
    )


def _build_path_forest(
    nodes_by_key: dict[str, Issue], edges: dict[str, list[str]], seed_keys: set[str]
) -> list[dict[str, Any]]:
    """Assemble the root→…→seed forest from a parent→children edge map.

    *edges* maps each parent key to the children climbed from it (toward the seeds);
    a node that is never a child is a forest root. Each node carries its display
    fields, and a node in *seed_keys* (an assigned ticket the climb started at) is
    tagged ``assigned_to`` so the renderer can mark the leaf. Keys are sorted for a
    stable tree. The edge map is acyclic by construction (``effective_parent`` is a
    function), so the recursion terminates. Shared by the live + cache builders.
    """
    child_keys = {c for children in edges.values() for c in children}
    root_keys = sorted(k for k in nodes_by_key if k not in child_keys)

    def build(key: str) -> dict[str, Any]:
        info = nodes_by_key.get(key) or {"key": key}
        node: dict[str, Any] = {
            "key": key,
            "summary": info.get("summary"),
            "status": info.get("status"),
            "issue_type": info.get("issue_type"),
            "children": [build(c) for c in sorted(edges.get(key, []))],
        }
        if key in seed_keys and info.get("assignee"):
            node["assigned_to"] = info["assignee"]
        return node

    return [build(rk) for rk in root_keys]


def _collapse_to_root_paths(
    client: Any, seeds: list[Issue], rules: list[dict[str, Any]], manual: dict[str, str]
) -> list[dict[str, Any]]:
    """Climb each seed to its root keeping the *path* edges; return the root→…→seed
    forest — only the climbed chains, not the roots' full subtrees (the
    ``issue list --roots --verbose`` view, with each assigned leaf marked)."""
    fetch, memo = _node_fetcher(client)
    memo.update({s["key"]: s for s in seeds})
    seed_keys = {s["key"] for s in seeds}

    raw_edges: dict[str, list[str]] = {}
    for seed in seeds:
        _root, climb_children = _climb_to_root(fetch, seed["key"], rules, manual)
        for parent_key, children in climb_children.items():
            raw_edges.setdefault(parent_key, []).extend(children)
    edges = {parent: dedup(children) for parent, children in raw_edges.items()}
    return _build_path_forest(memo, edges, seed_keys)


# --- cache-backed traversal (F010 cutover; output mirrors the live shapes) -----


def _roots_from_cache(
    ids: list[str], *, cache_path: str | None, config_path: str | None
) -> list[Issue]:
    """Roots of the assignee *ids*' cached issues — re-parse each root's ``raw`` so the
    output is byte-identical to the live ``_collapse_to_roots`` shape."""
    conn = cache.connect(cache_path=cache_path, config_path=config_path)
    try:
        seed_keys = cache.keys_by_assignee(conn, ids)
        out: list[Issue] = []
        for root_key in cache.climb_roots(conn, seed_keys):
            row = conn.execute("SELECT raw FROM issue WHERE key = ?", (root_key,)).fetchone()
            if row and row["raw"]:
                out.append(_parse_issue(json.loads(row["raw"])))
    finally:
        conn.close()
    return sorted(out, key=lambda i: i.get("created") or "", reverse=True)


def _root_paths_from_cache(
    ids: list[str], *, cache_path: str | None, config_path: str | None
) -> list[dict[str, Any]]:
    """Cache-backed ``issue list --roots --verbose``: the root→…→seed paths via one
    upward ``cache.climb_edges`` CTE, assembled into the same forest the live walk
    builds. An ``effective_parent`` absent from the returned chain (a dangling /
    not-yet-synced ancestor) makes its child a root — the live 404-stop equivalent."""
    conn = cache.connect(cache_path=cache_path, config_path=config_path)
    try:
        seed_keys = set(cache.keys_by_assignee(conn, ids))
        rows = cache.climb_edges(conn, sorted(seed_keys))
    finally:
        conn.close()
    present = {r["key"] for r in rows}
    nodes_by_key: dict[str, Issue] = {}
    edges: dict[str, list[str]] = {}
    for r in rows:
        info: Issue = {
            "key": r["key"],
            "summary": r["summary"],
            "status": r["status"],
            "issue_type": r["issue_type"],
        }
        if r["key"] in seed_keys and r["raw"]:
            info["assignee"] = _parse_issue(json.loads(r["raw"]))["assignee"]
        nodes_by_key[r["key"]] = info
        parent = r["effective_parent"]
        if parent and parent in present:
            edges.setdefault(parent, []).append(r["key"])
    return _build_path_forest(nodes_by_key, edges, seed_keys)


def _tree_from_cache(
    key: str, *, cache_path: str | None, config_path: str | None
) -> dict[str, Any] | None:
    """Cache-backed ``tree`` (None → fall back to live: cache empty/missing or KEY absent).

    Climbs to KEY's effective root then nests every descendant by ``effective_parent``
    — virtual-aware because that column already folds native + rule + manual edges.
    """
    if not cache.path(cache_path=cache_path, config_path=config_path).exists():
        return None
    conn = cache.connect(cache_path=cache_path, config_path=config_path)
    try:
        if conn.execute("SELECT 1 FROM issue WHERE key = ? LIMIT 1", (key,)).fetchone() is None:
            return None
        root_keys = cache.climb_roots(conn, [key])
        rows = cache.subtree_rows(conn, root_keys[0]) if root_keys else []
    finally:
        conn.close()
    nodes = {
        r["key"]: {
            "key": r["key"],
            "summary": r["summary"],
            "status": r["status"],
            "issue_type": r["issue_type"],
            "effective_parent": r["effective_parent"],
            "source": r["source"],
            "children": [],
        }
        for r in rows
    }
    root_key = root_keys[0]
    for r in rows:
        parent = nodes.get(r["effective_parent"])
        if parent is not None and r["key"] != root_key:
            parent["children"].append(nodes[r["key"]])
    return nodes.get(root_key)


def list(
    *,
    assignee: list[str] | None = None,
    org: list[str] | None = None,
    jql: str | None = None,
    created_from: str | None = None,
    created_to: str | None = None,
    assigned_from: str | None = None,
    assigned_to: str | None = None,
    roots: bool = False,
    paths: bool = False,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> list[Issue]:
    """F004/F005/F007/F008: list issues by assignee(s) / org unit(s) / created-range / raw JQL.

    ``--org`` expands each unit's subtree to its members' account-ids (F007). The
    combined assignee-id set is chunked across multiple searches so a whole-실
    never exceeds Jira's JQL IN-clause limit. ``roots=True`` (F006) collapses the
    result to the distinct root issues its members live under (effective parents);
    add ``paths=True`` (only with ``roots``) to instead return the root→…→assigned
    *forest* — each root with just the climbed chains down to the assigned tickets
    (the leaves tagged ``assigned_to``), not the roots' whole subtrees. This is the
    ``issue list --roots --verbose`` view. ``--assigned-from/--to`` (F008) filters by
    *assignee history*: ``assignee WAS IN (...) DURING/AFTER/BEFORE`` matches issues
    the id-set held at some point in the window (survives reassignment), so it
    requires ``--assignee``/``--org`` and is mutually exclusive with raw ``--jql``;
    live-only (the cache stores current state).
    """
    has_range = bool(assigned_from or assigned_to)
    if has_range and jql:
        raise JiraHelperError(
            "--jql cannot be combined with --assigned-from/--assigned-to; "
            "the raw query owns the whole search"
        )

    # F010 cutover: cache-backed roots for the pure assignee/org case. The cache can't
    # evaluate raw JQL, a created-range, or an assigned-range — those fall through to live.
    cache_eligible = not no_cache and not jql and not (created_from or created_to) and not has_range
    if roots and cache_eligible:
        ids = _resolve_ids(assignee, org, config_path)
        if ids and cache.is_populated(cache_path=cache_path, config_path=config_path):
            if paths:
                return _root_paths_from_cache(ids, cache_path=cache_path, config_path=config_path)
            return _roots_from_cache(ids, cache_path=cache_path, config_path=config_path)

    from .client import JiraClient  # local import: keep module import-light / cycle-free

    with JiraClient.from_config(config_path=config_path, profile=profile) as client:
        if jql:
            seeds = _search(client, jql, with_links=roots)
        else:
            ids = _resolve_ids(assignee, org, config_path)
            date_clauses = _date_clauses(created_from, created_to)
            if has_range and not ids:
                raise JiraHelperError(
                    "issue list --assigned-from/--assigned-to needs --assignee or --org "
                    "(a value to match in the assignee change history)"
                )
            if not ids and not date_clauses:
                raise JiraHelperError(
                    "list needs a filter: --assignee, --org, --jql, or a --created-* range"
                )
            if not ids:
                seeds = _search(client, _compose_jql([], date_clauses), with_links=roots)
            else:
                # Chunk the assignee ids; merge by key and sort newest-first across batches.
                # With an assigned-range, each chunk becomes an `assignee WAS IN (...)`
                # historical clause replacing the current-assignee equality.
                merged: dict[str, Issue] = {}
                for batch in _chunks(ids, _ASSIGNEE_BATCH):
                    clause = (
                        _assigned_clause(batch, assigned_from, assigned_to) if has_range else None
                    )
                    for issue in _search(
                        client,
                        _compose_jql(batch, date_clauses, assignee_clause=clause),
                        with_links=roots,
                    ):
                        merged.setdefault(issue["key"], issue)
                seeds = sorted(merged.values(), key=lambda i: i.get("created") or "", reverse=True)
        if roots:
            rules, manual = rule_lib.load(config_path=config_path)
            if paths:
                return _collapse_to_root_paths(client, seeds, rules, manual)
            return _collapse_to_roots(client, seeds, rules, manual)
    return seeds


def roots(
    *,
    assignee: list[str] | None = None,
    org: list[str] | None = None,
    paths: bool = False,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> list[Issue]:
    """F006: the root issues of an assignee/org set — sugar for ``list(..., roots=True)``.

    ``paths=True`` returns the root→…→assigned forest instead of the flat roots (the
    ``--verbose`` view); see :func:`list`."""
    return list(
        assignee=assignee,
        org=org,
        roots=True,
        paths=paths,
        profile=profile,
        no_cache=no_cache,
        cache_path=cache_path,
        config_path=config_path,
    )


def tree(
    key: str,
    *,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> dict[str, Any]:
    """F006: the effective hierarchy around KEY (native parents + virtual rules).

    Climbs to KEY's effective root, then expands the subtree below it via **native**
    children (``parent = X``), explicit ``manual_parents`` edges, and the
    virtual-ancestor edges discovered on the way up (so KEY always appears in its
    own tree even when a conditional rule set its parent). Each node is annotated
    with its effective parent + the rule that set it. Conditional-rule virtual
    *descendants* of nodes off the climb path aren't enumerable on the live walk
    without a full index — so when the cache is populated this reads from it instead
    (recursive CTE over ``effective_parent``, which *is* that index). The live walk
    (below) is the fallback for an empty/missing cache, ``--no-cache``, or a KEY not
    yet synced: up-walk virtual-aware, down-walk native + manual + the climbed path.
    """
    if not no_cache:
        cached = _tree_from_cache(key, cache_path=cache_path, config_path=config_path)
        if cached is not None:
            return cached

    from .client import JiraClient

    rules, manual = rule_lib.load(config_path=config_path)
    manual_children: dict[str, list[str]] = {}
    for child, parent in manual.items():
        manual_children.setdefault(parent, []).append(child)

    with JiraClient.from_config(config_path=config_path, profile=profile) as client:
        fetch, memo = _node_fetcher(client)

        # 1. climb to the effective root (recording the virtual edges we traversed)
        root, climb_children = _climb_to_root(fetch, key, rules, manual)
        root_key = root["key"]

        # 2. expand down: native children + manual edges + climbed path (bounded, cycle-guarded)
        visited: set[str] = set()
        count = 1

        def build(k: str) -> dict[str, Any]:
            nonlocal count
            visited.add(k)
            n = fetch(k)
            parent, source = rule_lib.effective_parent_of_node(n, rules, manual)
            out: dict[str, Any] = {
                "key": n["key"],
                "summary": n.get("summary"),
                "status": n.get("status"),
                "issue_type": n.get("issue_type"),
                "effective_parent": parent,
                "source": source,
                "children": [],
            }
            child_keys: list[str] = []
            if count < _TREE_MAX_NODES:
                for c in _search(
                    client, f"parent = {_jql_quote(k)} ORDER BY created ASC", with_links=True
                ):
                    memo.setdefault(c["key"], c)
                    child_keys.append(c["key"])
                child_keys.extend(manual_children.get(k, []))
                child_keys.extend(climb_children.get(k, []))
            for ck in dedup(child_keys):
                if ck in visited or count >= _TREE_MAX_NODES:
                    continue
                count += 1
                out["children"].append(build(ck))
            return out

        return build(root_key)


def fetch_node(key: str, *, profile: str | None = None, config_path: str | None = None) -> Issue:
    """One issue with its linked-issue keys (the unit ``rule resolve`` resolves)."""
    from .client import JiraClient

    with JiraClient.from_config(config_path=config_path, profile=profile) as client:
        return _fetch_node(client, key)


def get(
    key: str,
    *,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> Issue:
    """F004: one issue's fields (live)."""
    from .client import JiraClient

    with JiraClient.from_config(config_path=config_path, profile=profile) as client:
        raw = client.get(f"/issue/{key}", fields=",".join(_FIELDS))
    return _parse_issue(raw or {})  # tolerate an empty body
