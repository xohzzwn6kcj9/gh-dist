"""`cache` commands — local SQLite store inspection (infra, F006)."""

from typing import Annotated

import typer

from .. import cache as cache_lib
from . import _common

app = typer.Typer(no_args_is_help=True, help="Inspect/manage the local SQLite cache.")

_CACHE = ("cache_path", "config_path")


@app.command()
def status(ctx: typer.Context) -> None:
    """Rows (per product), last sync, size, schema version.

    Example:
        jira-helper cache status
    """
    _common.run(ctx, lambda: cache_lib.status(**_common.opt_kwargs(ctx, _CACHE)))


@app.command()
def get(
    ctx: typer.Context,
    key: Annotated[str, typer.Argument(help="Cached record key, e.g. PROJA-123.")],
) -> None:
    """One cached record (table/JSON). Feature: F006.

    Example:
        jira-helper cache get PROJA-123
    """
    _common.run(ctx, lambda: cache_lib.get(key, **_common.opt_kwargs(ctx, _CACHE)))


@app.command()
def export(
    ctx: typer.Context,
    product: Annotated[str | None, typer.Option("--product", help="Limit to one product.")] = None,
) -> None:
    """Dump the whole cache as JSON for eyeballing / grep. Feature: F006.

    Example:
        jira-helper --json cache export
    """
    _common.run(ctx, lambda: cache_lib.export(product=product, **_common.opt_kwargs(ctx, _CACHE)))


@app.command()
def clear(
    ctx: typer.Context,
    product: Annotated[
        str | None, typer.Option("--product", help="Wipe only this product.")
    ] = None,
) -> None:
    """Wipe cache (optionally per-product; use -y to skip confirmation).

    Example:
        jira-helper -y cache clear --product jira
    """
    if not _common.get_opts(ctx).yes:
        scope = f"product {product!r}" if product else "ALL products"
        typer.confirm(f"Wipe the cache ({scope})? This cannot be undone.", abort=True)
    _common.run(ctx, lambda: cache_lib.clear(product=product, **_common.opt_kwargs(ctx, _CACHE)))


@app.command()
def path(ctx: typer.Context) -> None:
    """Print the cache file location (cache.db).

    Example:
        jira-helper cache path
    """
    _common.run(ctx, lambda: cache_lib.path(**_common.opt_kwargs(ctx, _CACHE)))
