"""Local SQLite cache (``cache.db``, beside the config; ``--cache`` overrides).

Stdlib ``sqlite3`` in WAL mode so a background ``sync`` can write while reads
run. Tree traversal (F006 root-finding / subtrees) uses ``WITH RECURSIVE`` over
``effective_parent``; incremental sync (F010) uses UPSERT. The schema, the
WAL/foreign-key connection, and ``init_db`` are wired here; the query/inspection
helpers are stubs. Inspect via ``cache get`` / ``cache export --json``.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

from . import config

SCHEMA_VERSION = 1

_SCHEMA = """
CREATE TABLE IF NOT EXISTS issue (
    key              TEXT PRIMARY KEY,
    product          TEXT NOT NULL DEFAULT 'jira',
    project          TEXT,
    issue_type       TEXT,
    summary          TEXT,
    status           TEXT,
    assignee_id      TEXT,
    native_parent    TEXT,
    effective_parent TEXT,
    created          TEXT,
    updated          TEXT,
    raw              TEXT,
    synced_at        TEXT
);
CREATE INDEX IF NOT EXISTS idx_assignee ON issue(assignee_id);
CREATE INDEX IF NOT EXISTS idx_parent   ON issue(effective_parent);
CREATE TABLE IF NOT EXISTS issue_link (
    src  TEXT NOT NULL,
    dst  TEXT NOT NULL,
    type TEXT NOT NULL,
    PRIMARY KEY (src, dst, type)
);
"""


def path(*, cache_path: str | None = None, config_path: str | None = None) -> Path:
    """Resolve the cache.db location (``--cache`` override → beside the config)."""
    if cache_path is not None:
        return Path(cache_path).expanduser()
    return config.config_dir(config_path) / "cache.db"


def connect(*, cache_path: str | None = None, config_path: str | None = None) -> sqlite3.Connection:
    """Open the cache in WAL mode (creating the parent dir if needed)."""
    db = path(cache_path=cache_path, config_path=config_path)
    db.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db(*, cache_path: str | None = None, config_path: str | None = None) -> Path:
    """Create the schema (idempotent) and stamp the schema version; return the db path."""
    db = path(cache_path=cache_path, config_path=config_path)
    conn = connect(cache_path=cache_path, config_path=config_path)
    try:
        conn.executescript(_SCHEMA)
        conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
        conn.commit()
    finally:
        conn.close()
    return db


def status(*, cache_path: str | None = None, config_path: str | None = None) -> dict[str, Any]:
    """Rows (per product), last sync, size, schema version."""
    raise NotImplementedError("jira_helper.cache.status: not yet implemented (scaffold)")


def get(
    key: str, *, cache_path: str | None = None, config_path: str | None = None
) -> dict[str, Any] | None:
    """One cached record by key."""
    raise NotImplementedError("jira_helper.cache.get: not yet implemented (scaffold)")


def export(
    *,
    product: str | None = None,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> list[dict[str, Any]]:
    """Dump the whole cache (optionally per-product) for eyeballing / grep."""
    raise NotImplementedError("jira_helper.cache.export: not yet implemented (scaffold)")


def clear(
    *,
    product: str | None = None,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> int:
    """Wipe the cache (optionally per-product); return rows removed."""
    raise NotImplementedError("jira_helper.cache.clear: not yet implemented (scaffold)")
