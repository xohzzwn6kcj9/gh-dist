"""`rule` commands — virtual-parent rules (F006)."""

from typing import Annotated

import typer

from .. import rule as rule_lib
from . import _common

app = typer.Typer(no_args_is_help=True, help="Virtual-parent rules (F006).")

_CFG = ("config_path",)


@app.command("list")
def list_(ctx: typer.Context) -> None:
    """Render parsed conditional rules + manual edges. Feature: F006.

    Example:
        jira-helper rule list
    """
    _common.run(ctx, lambda: rule_lib.list(**_common.opt_kwargs(ctx, _CFG)))


@app.command()
def edit(ctx: typer.Context) -> None:
    """Open rules.yaml in $EDITOR (author conditional rules). Feature: F006.

    Example:
        jira-helper rule edit
    """
    _common.run(ctx, lambda: _common.stub("rule edit"))


@app.command()
def add(
    ctx: typer.Context,
    child: Annotated[str, typer.Argument(help="Child issue key, e.g. PROJA-101.")],
    parent: Annotated[str, typer.Argument(help="Parent issue key, e.g. PROJA-50.")],
) -> None:
    """Append a one-off manual parent edge (child → parent). Feature: F006.

    Example:
        jira-helper rule add PROJA-101 PROJA-50
    """
    _common.run(ctx, lambda: rule_lib.add(child, parent, **_common.opt_kwargs(ctx, _CFG)))


@app.command()
def remove(
    ctx: typer.Context,
    child: Annotated[str, typer.Argument(help="Child key whose manual edge to drop.")],
) -> None:
    """Drop a manual edge. Feature: F006.

    Example:
        jira-helper rule remove PROJA-101
    """
    _common.run(ctx, lambda: rule_lib.remove(child, **_common.opt_kwargs(ctx, _CFG)))


@app.command()
def test(
    ctx: typer.Context,
    key: Annotated[str, typer.Argument(help="Issue key to resolve.")],
) -> None:
    """Dry-run: effective parent for KEY + which rule fired. Feature: F006.

    Example:
        jira-helper rule test PROJA-123
    """
    _common.run(
        ctx, lambda: rule_lib.resolve(key, **_common.opt_kwargs(ctx, ("config_path", "cache_path")))
    )


@app.command()
def validate(ctx: typer.Context) -> None:
    """Schema + cycle + ambiguity checks before traversal. Feature: F006.

    Example:
        jira-helper rule validate
    """
    _common.run(ctx, lambda: rule_lib.validate(**_common.opt_kwargs(ctx, _CFG)))


@app.command()
def path(ctx: typer.Context) -> None:
    """Print the rules file location. Feature: F006.

    Example:
        jira-helper rule path
    """
    _common.run(ctx, lambda: rule_lib.path(**_common.opt_kwargs(ctx, _CFG)))
