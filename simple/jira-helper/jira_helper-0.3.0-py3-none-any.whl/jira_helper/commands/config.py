"""`config` commands — first-run onboarding + config CRUD (F001)."""

from typing import Annotated

import typer

from .. import config as config_lib
from . import _common

app = typer.Typer(no_args_is_help=True, help="Onboarding + configuration CRUD (F001).")


def run_init(ctx: typer.Context) -> None:
    """Interactive onboarding: prompt for credentials, then write the config.

    Shared by ``config init`` and the top-level ``init`` alias. Prompting (a UI
    concern) lives here; the library ``config.init`` only validates + persists.
    """
    opts = _common.get_opts(ctx)
    base_url = typer.prompt("Jira base URL (e.g. https://your-domain.atlassian.net)")
    email = typer.prompt("Account email")
    api_token = typer.prompt("API token", hide_input=True)
    _common.run(
        ctx,
        lambda: config_lib.init(
            base_url=base_url,
            email=email,
            api_token=api_token,
            force=opts.yes,
            **_common.opt_kwargs(ctx, ("config_path",)),
        ),
    )


@app.command()
def init(ctx: typer.Context) -> None:
    """Interactive Q&A → write config, chmod 600. Feature: F001.

    Example:
        jira-helper config init
    """
    run_init(ctx)


@app.command()
def show(
    ctx: typer.Context,
    reveal: Annotated[bool, typer.Option("--reveal", help="Show masked secrets in full.")] = False,
) -> None:
    """Print the resolved config (token masked). Feature: F001.

    Example:
        jira-helper config show
    Example output:
        base_url: https://your-domain.atlassian.net
        email: you@example.com
        api_token: ****
    """
    _common.run(
        ctx, lambda: config_lib.show(reveal=reveal, **_common.opt_kwargs(ctx, ("config_path",)))
    )


@app.command()
def get(
    ctx: typer.Context,
    key: Annotated[str, typer.Argument(help="Config key to read, e.g. base_url.")],
    reveal: Annotated[bool, typer.Option("--reveal", help="Show masked values in full.")] = False,
) -> None:
    """Read one config field (masked unless --reveal). Feature: F001.

    Example:
        jira-helper config get base_url
    """
    _common.run(
        ctx,
        lambda: config_lib.get(key, reveal=reveal, **_common.opt_kwargs(ctx, ("config_path",))),
    )


@app.command("set")
def set_(
    ctx: typer.Context,
    key: Annotated[str, typer.Argument(help="Config key to set.")],
    value: Annotated[str, typer.Argument(help="New value.")],
) -> None:
    """Set one config field non-interactively (re-chmod 600). Feature: F001.

    Example:
        jira-helper config set email you@example.com
    """
    _common.run(
        ctx,
        lambda: config_lib.set(key, value, **_common.opt_kwargs(ctx, ("config_path",))),
    )


@app.command()
def edit(ctx: typer.Context) -> None:
    """Open the config in $EDITOR. Feature: F001.

    Example:
        jira-helper config edit
    """
    _common.run(ctx, lambda: _common.stub("config edit"))


@app.command()
def verify(ctx: typer.Context) -> None:
    """Live auth ping + re-assert chmod 600. Feature: F001.

    Example:
        jira-helper config verify
    """
    _common.run(
        ctx,
        lambda: config_lib.verify(**_common.opt_kwargs(ctx, ("config_path", "profile"))),
    )


@app.command()
def path(ctx: typer.Context) -> None:
    """Print the config file location. Feature: F001.

    Example:
        jira-helper config path
    """
    _common.run(ctx, lambda: config_lib.path(**_common.opt_kwargs(ctx, ("config_path",))))
