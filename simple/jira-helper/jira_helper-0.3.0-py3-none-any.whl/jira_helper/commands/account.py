"""`account` commands — name ↔ account-id store + live lookup (F002, F003)."""

from typing import Annotated

import typer

from .. import account as account_lib
from . import _common

app = typer.Typer(no_args_is_help=True, help="Resolve and store name↔account-id (F002, F003).")


@app.command("list")
def list_(ctx: typer.Context) -> None:
    """List all name↔account-id mappings. Feature: F003.

    Example:
        jira-helper account list
    """
    _common.run(ctx, lambda: account_lib.list(**_common.opt_kwargs(ctx, ("config_path",))))


@app.command()
def get(
    ctx: typer.Context,
    name_or_id: Annotated[str, typer.Argument(help="A name or an Atlassian account-id.")],
) -> None:
    """Resolve a name or account-id from the store (either direction). Feature: F002, F003.

    Example:
        jira-helper account get alice
    """
    _common.run(
        ctx, lambda: account_lib.get(name_or_id, **_common.opt_kwargs(ctx, ("config_path",)))
    )


@app.command()
def add(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Display name.")],
    account_id: Annotated[str, typer.Argument(help="Atlassian account-id.")],
) -> None:
    """Write/update a name→account-id mapping in the store. Feature: F003.

    Example:
        jira-helper account add alice 5b10ac8d82e05b22cc7d4ef5
    """
    _common.run(
        ctx, lambda: account_lib.add(name, account_id, **_common.opt_kwargs(ctx, ("config_path",)))
    )


@app.command()
def remove(
    ctx: typer.Context,
    name_or_id: Annotated[str, typer.Argument(help="A name or account-id to delete.")],
) -> None:
    """Delete a mapping from the store. Feature: F003.

    Example:
        jira-helper account remove alice
    """
    _common.run(
        ctx, lambda: account_lib.remove(name_or_id, **_common.opt_kwargs(ctx, ("config_path",)))
    )


@app.command()
def search(
    ctx: typer.Context,
    name: Annotated[str, typer.Argument(help="Name to look up live.")],
) -> None:
    """OUTPUT-ONLY live lookup → profile link + candidate id(s); writes nothing. Feature: F002.

    Example:
        jira-helper account search "Alice Kim"
    Example output:
        [{"displayName": "Alice Kim", "accountId": "5b10...", "profile": "https://..."}]
    """
    _common.run(
        ctx, lambda: account_lib.search(name, **_common.opt_kwargs(ctx, ("profile", "config_path")))
    )


@app.command()
def path(ctx: typer.Context) -> None:
    """Print the account-store file location. Feature: F003.

    Example:
        jira-helper account path
    """
    _common.run(ctx, lambda: account_lib.path(**_common.opt_kwargs(ctx, ("config_path",))))
