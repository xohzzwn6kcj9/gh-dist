"""`sync` commands — cron/launchd-friendly cache refresh (F010)."""

from typing import Annotated

import typer

from .. import sync as sync_lib
from . import _common

app = typer.Typer(no_args_is_help=True, help="Background cache refresh (F010).")


@app.command()
def run(
    ctx: typer.Context,
    product: Annotated[str, typer.Option("--product", help="Product to refresh.")] = "jira",
    full: Annotated[bool, typer.Option("--full", help="Full resync (ignore watermark).")] = False,
    since: Annotated[str | None, typer.Option("--since", help="Lower bound timestamp.")] = None,
) -> None:
    """Incremental, idempotent cache refresh. Feature: F010.

    Example:
        jira-helper sync run --product jira
    """
    _common.run(
        ctx,
        lambda: sync_lib.run(
            product=product,
            full=full,
            since=since,
            **_common.opt_kwargs(ctx, ("profile", "cache_path", "config_path")),
        ),
    )


@app.command()
def status(ctx: typer.Context) -> None:
    """Last run time, watermark, lock state, last error. Feature: F010.

    Example:
        jira-helper sync status
    """
    _common.run(
        ctx, lambda: sync_lib.status(**_common.opt_kwargs(ctx, ("cache_path", "config_path")))
    )


@app.command()
def install(
    ctx: typer.Context,
    cron: Annotated[bool, typer.Option("--cron", help="Install a cron unit.")] = False,
    launchd: Annotated[
        bool, typer.Option("--launchd", help="Install a launchd unit (default).")
    ] = False,
    schedule: Annotated[str | None, typer.Option("--schedule", help="Schedule expression.")] = None,
) -> None:
    """Emit/install the scheduler unit. Feature: F010.

    Example:
        jira-helper sync install --launchd
    """
    scheduler = "cron" if cron else "launchd"
    _common.run(
        ctx,
        lambda: sync_lib.install(
            scheduler=scheduler,
            schedule=schedule,
            **_common.opt_kwargs(ctx, ("config_path",)),
        ),
    )
