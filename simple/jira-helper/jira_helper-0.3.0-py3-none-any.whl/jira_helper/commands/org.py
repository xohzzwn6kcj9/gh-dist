"""`org` commands — hierarchical org units + member CRUD (F007, F009)."""

import os
import subprocess
from typing import Annotated

import typer

from .. import org as org_lib
from . import _common

app = typer.Typer(no_args_is_help=True, help="Manage the org hierarchy + members (F009).")

_CFG = ("config_path",)


# --- human renderers (non-JSON views the generic table can't express) --------


def _fmt_member(m: dict) -> str:
    label = f"{m['name']} ({m['account_id']})"
    return label if m.get("resolved") else f"{label} [미해소]"


def _format_tree(data: dict) -> str:
    lines: list[str] = []

    def walk(node: dict, depth: int) -> None:
        label = node["name"]
        if node.get("type"):
            label += f" ({node['type']})"
        if node.get("member_count"):
            label += f" — {node['member_count']}명"
        lines.append("  " * depth + label)
        for child in node.get("children", []):
            walk(child, depth + 1)

    roots = data["roots"] if "roots" in data else [data]
    for root in roots:
        walk(root, 0)
    return "\n".join(lines) or "(empty)"


def _format_show(d: dict) -> str:
    lines = [
        f"name: {d['name']}",
        f"type: {d.get('type')}",
        f"parent: {d.get('parent')}",
        f"children: {', '.join(d.get('children') or []) or '(none)'}",
        "members (direct):",
    ]
    lines += [f"  - {_fmt_member(m)}" for m in d.get("members", [])] or ["  (none)"]
    if "effective_members" in d:
        lines.append("members (effective):")
        lines += [f"  - {_fmt_member(m)}" for m in d["effective_members"]] or ["  (none)"]
    return "\n".join(lines)


# --- commands ----------------------------------------------------------------


@app.command("list")
def list_(
    ctx: typer.Context,
    type: Annotated[
        str | None, typer.Option("--type", help="Filter by unit type (그룹/부문/실/팀/파트).")
    ] = None,
) -> None:
    """List all org units (name, type, parent, member count). Feature: F009.

    Example:
        jira-helper org list --type 팀
    """
    _common.run(ctx, lambda: org_lib.list(type=type, **_common.opt_kwargs(ctx, _CFG)))


@app.command()
def show(
    ctx: typer.Context,
    unit: Annotated[str, typer.Argument(help="Org unit name.")],
    direct: Annotated[
        bool, typer.Option("--direct", help="Own members only (skip subtree union).")
    ] = False,
) -> None:
    """A unit's type/parent/children + direct & effective members. Feature: F009.

    Example:
        jira-helper org show 신규서비스개발실
    """
    _common.run(
        ctx,
        lambda: org_lib.show(unit, direct=direct, **_common.opt_kwargs(ctx, _CFG)),
        human=_format_show,
    )


@app.command()
def tree(
    ctx: typer.Context,
    unit: Annotated[str | None, typer.Argument(help="Root unit (omit = whole forest).")] = None,
) -> None:
    """Render the org as an indented hierarchy. Feature: F009.

    Example:
        jira-helper org tree 신규서비스개발실
    """
    _common.run(
        ctx,
        lambda: org_lib.tree(unit, **_common.opt_kwargs(ctx, _CFG)),
        human=_format_tree,
    )


@app.command()
def members(
    ctx: typer.Context,
    unit: Annotated[str, typer.Argument(help="Org unit name.")],
    direct: Annotated[
        bool, typer.Option("--direct", help="Own members only (skip subtree union).")
    ] = False,
) -> None:
    """Resolved member set a query will hit (name+id, unresolved flagged). Feature: F007.

    Example:
        jira-helper org members 신규서비스개발실
    """
    _common.run(ctx, lambda: org_lib.members(unit, direct=direct, **_common.opt_kwargs(ctx, _CFG)))


@app.command()
def create(
    ctx: typer.Context,
    unit: Annotated[str, typer.Argument(help="New unit name (unique).")],
    type: Annotated[
        str | None, typer.Option("--type", help="Free-form level label (그룹/부문/실/팀/파트).")
    ] = None,
    parent: Annotated[
        str | None, typer.Option("--parent", help="Parent unit name (omit = root).")
    ] = None,
    member: Annotated[
        list[str] | None, typer.Option("--member", help="Seed member name(s) or account-id(s).")
    ] = None,
) -> None:
    """Create an org unit (optional type/parent/members). Feature: F009.

    Example:
        jira-helper org create 서비스PM팀 --type 팀 --parent 신규서비스개발실 --member alice
    """
    _common.run(
        ctx,
        lambda: org_lib.create(
            unit, type=type, parent=parent, members=member, **_common.opt_kwargs(ctx, _CFG)
        ),
    )


@app.command()
def move(
    ctx: typer.Context,
    unit: Annotated[str, typer.Argument(help="Unit to re-parent.")],
    parent: Annotated[str | None, typer.Option("--parent", help="New parent unit name.")] = None,
    root: Annotated[bool, typer.Option("--root", help="Make the unit a root (no parent).")] = False,
) -> None:
    """Re-parent a unit's subtree (--parent <name> or --root). Feature: F009.

    Example:
        jira-helper org move 서비스PM팀 --parent 차세대개발실
    """
    if not root and parent is None:
        raise typer.BadParameter("specify --parent <name> or --root")
    _common.run(
        ctx,
        lambda: org_lib.move(unit, None if root else parent, **_common.opt_kwargs(ctx, _CFG)),
    )


@app.command()
def rename(
    ctx: typer.Context,
    old: Annotated[str, typer.Argument(help="Current unit name.")],
    new: Annotated[str, typer.Argument(help="New unit name.")],
) -> None:
    """Rename a unit (children's parent pointers follow). Feature: F009.

    Example:
        jira-helper org rename 신규서비스개발실 차세대개발실
    """
    _common.run(ctx, lambda: org_lib.rename(old, new, **_common.opt_kwargs(ctx, _CFG)))


@app.command("add-member")
def add_member(
    ctx: typer.Context,
    unit: Annotated[str, typer.Argument(help="Org unit name.")],
    member: Annotated[list[str], typer.Argument(help="Member name(s) or account-id(s).")],
) -> None:
    """Add member(s) to a unit's own list. Feature: F009.

    Example:
        jira-helper org add-member 서비스PM팀 alice bob
    """
    _common.run(ctx, lambda: org_lib.add_member(unit, member, **_common.opt_kwargs(ctx, _CFG)))


@app.command("remove-member")
def remove_member(
    ctx: typer.Context,
    unit: Annotated[str, typer.Argument(help="Org unit name.")],
    member: Annotated[list[str], typer.Argument(help="Member(s) to remove.")],
) -> None:
    """Remove member(s) from a unit's own list. Feature: F009.

    Example:
        jira-helper org remove-member 서비스PM팀 bob
    """
    _common.run(ctx, lambda: org_lib.remove_member(unit, member, **_common.opt_kwargs(ctx, _CFG)))


@app.command()
def delete(
    ctx: typer.Context,
    unit: Annotated[str, typer.Argument(help="Unit to delete.")],
    recursive: Annotated[
        bool, typer.Option("--recursive", help="Also delete all descendant units.")
    ] = False,
) -> None:
    """Delete a unit (refuses children unless --recursive). Feature: F009.

    Example:
        jira-helper org delete 서비스PM팀
    """
    _common.run(
        ctx, lambda: org_lib.delete(unit, recursive=recursive, **_common.opt_kwargs(ctx, _CFG))
    )


@app.command()
def validate(ctx: typer.Context) -> None:
    """Check the tree (dangling/cycle/dup/empty-leaf/unresolved members). Feature: F009.

    Example:
        jira-helper org validate
    """
    _common.run(ctx, lambda: org_lib.validate(**_common.opt_kwargs(ctx, _CFG)))


@app.command()
def edit(ctx: typer.Context) -> None:
    """Open org.yaml in $EDITOR (bulk authoring). Feature: F009.

    Example:
        jira-helper org edit
    """
    p = org_lib.path(**_common.opt_kwargs(ctx, _CFG))
    p.parent.mkdir(parents=True, exist_ok=True)
    if not p.exists():
        p.write_text("orgs: []\n", encoding="utf-8")
    editor = os.environ.get("EDITOR") or os.environ.get("VISUAL") or "vi"
    subprocess.call([editor, str(p)])
    typer.echo(str(p))


@app.command()
def path(ctx: typer.Context) -> None:
    """Print the org-store file location. Feature: F009.

    Example:
        jira-helper org path
    """
    _common.run(ctx, lambda: org_lib.path(**_common.opt_kwargs(ctx, _CFG)))
