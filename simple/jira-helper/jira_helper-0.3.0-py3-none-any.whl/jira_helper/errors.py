"""Expected, user-facing errors — rendered cleanly (no traceback), with an exit code.

The CLI glue (``commands/_common.run``) catches :class:`JiraHelperError` and
renders ``{"error": code, "message": ...}`` to stderr, exiting with the
exception's ``exit_code``. Anything else propagates as a real traceback (a bug).
Library callers can catch the same hierarchy. Stubs still raise the stdlib
``NotImplementedError`` (handled separately, exit 2).
"""

from __future__ import annotations


class JiraHelperError(Exception):
    """Base for expected errors shown to the user without a traceback."""

    code = "error"
    exit_code = 1


class ConfigError(JiraHelperError):
    """Configuration is missing, unreadable, or incomplete."""

    code = "config_error"


class NotFoundError(JiraHelperError):
    """A requested resource (config key, account, issue) does not exist."""

    code = "not_found"
    exit_code = 2


class JiraApiError(JiraHelperError):
    """The Jira REST API returned an error (auth, permissions, bad request, ...)."""

    code = "jira_api_error"

    def __init__(self, message: str, *, status: int | None = None) -> None:
        super().__init__(message)
        self.status = status
