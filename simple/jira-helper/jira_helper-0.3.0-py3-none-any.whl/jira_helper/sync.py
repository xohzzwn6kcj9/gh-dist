"""F010 — background auto-sync (cron / launchd friendly).

A CLI-invocable refresh that keeps the local SQLite cache current. Incremental
and idempotent (UPSERT + a sync watermark) so repeated runs are cheap and safe;
WAL lets a sync write while reads run. ``--product`` is honored from day one so
Confluence is purely additive. All bodies are stubs in this scaffold.
"""

from __future__ import annotations

from typing import Any


def run(
    *,
    product: str = "jira",
    full: bool = False,
    since: str | None = None,
    profile: str | None = None,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> dict[str, Any]:
    """F010: incremental, idempotent cache refresh (``--full`` for a complete resync)."""
    raise NotImplementedError("jira_helper.sync.run: not yet implemented (scaffold)")


def status(*, cache_path: str | None = None, config_path: str | None = None) -> dict[str, Any]:
    """F010: last run time, watermark, lock state, last error."""
    raise NotImplementedError("jira_helper.sync.status: not yet implemented (scaffold)")


def install(
    *,
    scheduler: str = "launchd",
    schedule: str | None = None,
    config_path: str | None = None,
) -> dict[str, Any]:
    """F010: emit/install a scheduler unit (``scheduler`` = ``cron`` | ``launchd``)."""
    raise NotImplementedError("jira_helper.sync.install: not yet implemented (scaffold)")
