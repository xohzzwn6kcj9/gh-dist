"""F006 — virtual-parent rules: a gitignored ``rules.yaml`` + a generic engine.

Conditional rules (first-match-wins) over the v1 matcher vocabulary
(``project`` / ``issue_type`` / ``linked_count``) with the ``linked`` parent
strategy, plus one-off ``manual_parents`` edges. The engine is generic; company
project keys live only in the user's local ``rules.yaml`` (never the repo).

Only ``path`` is wired in this scaffold; the rest are stubs.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from . import config

RULES_FILENAME = "rules.yaml"


def path(*, config_path: str | None = None) -> Path:
    """Resolve the rules.yaml location (beside the config)."""
    return config.config_dir(config_path) / RULES_FILENAME


def list(*, config_path: str | None = None) -> dict[str, Any]:
    """F006: render parsed conditional rules + manual edges."""
    raise NotImplementedError("jira_helper.rule.list: not yet implemented (scaffold)")


def add(child: str, parent: str, *, config_path: str | None = None) -> dict[str, str]:
    """F006: append a one-off manual parent edge (child → parent)."""
    raise NotImplementedError("jira_helper.rule.add: not yet implemented (scaffold)")


def remove(child: str, *, config_path: str | None = None) -> bool:
    """F006: drop a manual edge for *child*."""
    raise NotImplementedError("jira_helper.rule.remove: not yet implemented (scaffold)")


def resolve(
    key: str,
    *,
    config_path: str | None = None,
    cache_path: str | None = None,
) -> dict[str, Any]:
    """F006 (``rule test``): dry-run the effective parent for KEY + which rule fired."""
    raise NotImplementedError("jira_helper.rule.resolve: not yet implemented (scaffold)")


def validate(*, config_path: str | None = None) -> dict[str, Any]:
    """F006: schema + cycle + ambiguity checks before traversal."""
    raise NotImplementedError("jira_helper.rule.validate: not yet implemented (scaffold)")
