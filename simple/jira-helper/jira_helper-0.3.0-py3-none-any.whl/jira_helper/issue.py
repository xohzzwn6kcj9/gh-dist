"""F004–F008 — issue queries (list / roots / tree / get).

This first functional release queries the **live** Jira API (cache-backed reads
and ``--no-cache`` semantics arrive with sync, F010). ``--json`` is a render
concern owned by the CLI, not here. People filters accept names or account-ids
(names resolved via the account store, F003); unknown values pass through as
account-ids so raw ids work without a store entry.

Implemented: ``list`` (by assignee(s) / org unit(s) / raw JQL / created-range)
and ``get``. ``--org`` expands a unit's subtree to its members' account-ids
(F007). ``roots``/``tree`` (F006) stay stubbed.
"""

from __future__ import annotations

from typing import Any

from . import account
from . import org as org_lib  # aliased so the `org` *parameter* can't shadow the module
from ._util import dedup
from .errors import JiraHelperError

Issue = dict[str, Any]

# Fields requested from Jira and projected onto every Issue dict.
_FIELDS = ["summary", "status", "issuetype", "assignee", "project", "parent", "created", "updated"]
_PAGE_SIZE = 100
# Safety cap against the known runaway-nextPageToken bug (~10k issues at this size).
_MAX_PAGES = 100
# Max account-ids per `assignee in (...)` clause; a whole-실 union is chunked + merged
# so a large org never blows past Jira's JQL/request-size limit (F007).
_ASSIGNEE_BATCH = 50


def _jql_quote(value: str) -> str:
    """Quote a value for safe inclusion in JQL (escape backslash + double-quote)."""
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _resolve_assignee(name_or_id: str, config_path: str | None) -> str:
    """Map a stored name to its account-id; pass an unknown value through unchanged."""
    entry = account.get(name_or_id, config_path=config_path)
    return entry["account_id"] if entry else name_or_id


def _resolve_ids(
    assignee: list[str] | None, org_units: list[str] | None, config_path: str | None
) -> list[str]:
    """Combined, de-duped account-ids from --assignee (names/ids) + --org subtree expansion."""
    ids: list[str] = [_resolve_assignee(a, config_path) for a in (assignee or [])]
    for unit in org_units or []:
        ids.extend(org_lib.member_ids(unit, config_path=config_path))
    return dedup(ids)


def _date_clauses(created_from: str | None, created_to: str | None) -> list[str]:
    clauses: list[str] = []
    if created_from:
        clauses.append(f"created >= {_jql_quote(created_from)}")
    if created_to:
        clauses.append(f"created <= {_jql_quote(created_to)}")
    return clauses


def _compose_jql(id_chunk: list[str], date_clauses: list[str]) -> str:
    """One JQL string from an assignee-id chunk + date clauses, newest-first."""
    clauses: list[str] = []
    if id_chunk:
        clauses.append(f"assignee in ({', '.join(_jql_quote(i) for i in id_chunk)})")
    clauses.extend(date_clauses)
    return " AND ".join(clauses) + " ORDER BY created DESC"


def _chunks(seq: list[str], size: int) -> list[list[str]]:
    return [seq[i : i + size] for i in range(0, len(seq), size)]


def _parse_issue(raw: dict[str, Any]) -> Issue:
    """Project a raw Jira issue onto the flat Issue shape (cache-schema aligned)."""
    f = raw.get("fields") or {}
    assignee = f.get("assignee") or {}
    return {
        "key": raw.get("key"),
        "summary": f.get("summary"),
        "status": (f.get("status") or {}).get("name"),
        "issue_type": (f.get("issuetype") or {}).get("name"),
        "assignee": assignee.get("displayName"),
        "assignee_id": assignee.get("accountId"),
        "project": (f.get("project") or {}).get("key"),
        "parent": (f.get("parent") or {}).get("key"),
        "created": f.get("created"),
        "updated": f.get("updated"),
    }


def _search(client: Any, jql: str) -> list[Issue]:
    """Run a JQL search, following ``nextPageToken`` pagination to the last page."""
    issues: list[Issue] = []
    token: str | None = None
    for _ in range(_MAX_PAGES):
        body: dict[str, Any] = {"jql": jql, "fields": _FIELDS, "maxResults": _PAGE_SIZE}
        if token:
            body["nextPageToken"] = token
        data = client.post("/search/jql", json=body) or {}  # tolerate an empty body
        issues.extend(_parse_issue(i) for i in (data.get("issues") or []))
        token = data.get("nextPageToken")
        if data.get("isLast") or not token:
            break
    return issues


def list(
    *,
    assignee: list[str] | None = None,
    org: list[str] | None = None,
    jql: str | None = None,
    created_from: str | None = None,
    created_to: str | None = None,
    assigned_from: str | None = None,
    assigned_to: str | None = None,
    roots: bool = False,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> list[Issue]:
    """F004/F005/F007/F008: list issues by assignee(s) / org unit(s) / created-range / raw JQL.

    ``--org`` expands each unit's subtree to its members' account-ids (F007). The
    combined assignee-id set is chunked across multiple searches so a whole-실
    never exceeds Jira's JQL IN-clause limit. ``--assigned-from/--to`` (changelog)
    and ``roots`` (F006) are deferred and raise a clear "not implemented".
    """
    if assigned_from or assigned_to:
        raise NotImplementedError(
            "issue list --assigned-from/--assigned-to requires changelog history; deferred"
        )
    if roots:
        raise NotImplementedError("issue list --roots requires parent rules (F006); deferred")

    from .client import JiraClient  # local import: keep module import-light / cycle-free

    with JiraClient.from_config(config_path=config_path, profile=profile) as client:
        if jql:
            return _search(client, jql)
        ids = _resolve_ids(assignee, org, config_path)
        date_clauses = _date_clauses(created_from, created_to)
        if not ids and not date_clauses:
            raise JiraHelperError(
                "list needs a filter: --assignee, --org, --jql, or a --created-* range"
            )
        if not ids:
            return _search(client, _compose_jql([], date_clauses))  # date-only, one query
        # Chunk the assignee ids; merge by key and sort newest-first across batches.
        merged: dict[str, Issue] = {}
        for batch in _chunks(ids, _ASSIGNEE_BATCH):
            for issue in _search(client, _compose_jql(batch, date_clauses)):
                merged.setdefault(issue["key"], issue)
    return sorted(merged.values(), key=lambda i: i.get("created") or "", reverse=True)


def roots(
    *,
    assignee: list[str] | None = None,
    org: list[str] | None = None,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> list[Issue]:
    """F006: the root issues of an assignee/org set (walk effective parents to the top)."""
    raise NotImplementedError("jira_helper.issue.roots: not yet implemented (scaffold)")


def tree(
    key: str,
    *,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> dict[str, Any]:
    """F006: the parent→child hierarchy for KEY (native parents + virtual rules)."""
    raise NotImplementedError("jira_helper.issue.tree: not yet implemented (scaffold)")


def get(
    key: str,
    *,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> Issue:
    """F004: one issue's fields (live)."""
    from .client import JiraClient

    with JiraClient.from_config(config_path=config_path, profile=profile) as client:
        raw = client.get(f"/issue/{key}", fields=",".join(_FIELDS))
    return _parse_issue(raw or {})  # tolerate an empty body
