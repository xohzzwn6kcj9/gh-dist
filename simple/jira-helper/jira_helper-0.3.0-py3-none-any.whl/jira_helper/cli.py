"""jira-helper CLI — Typer app: global flags + noun groups + top-level commands.

A thin wrapper layer: parse args, stash the resolved global options on the Typer
context, dispatch to the library, render. No behavior lives here (the
library-first contract). Invocation grammar::

    jira-helper [GLOBAL FLAGS] <noun> <verb> [args] [flags]

Global flags are defined once on the root callback and therefore precede the
noun (e.g. ``jira-helper --json issue list --assignee alice``).
"""

import stat
from pathlib import Path
from typing import Annotated, Any

import typer

from . import __version__, output
from . import cache as cache_lib
from . import config as config_lib
from .client import JiraClient
from .commands import _common, account, cache, config, issue, org, rule, sync
from .errors import JiraHelperError

app = typer.Typer(
    name="jira-helper",
    no_args_is_help=True,
    add_completion=False,
    help="Admin toolkit for Atlassian Cloud (Jira now, Confluence later). "
    "Resolve people↔account-ids, manage the org hierarchy, query/cache tickets.",
)

app.add_typer(config.app, name="config")
app.add_typer(account.app, name="account")
app.add_typer(issue.app, name="issue")
app.add_typer(org.app, name="org")
app.add_typer(rule.app, name="rule")
app.add_typer(cache.app, name="cache")
app.add_typer(sync.app, name="sync")


@app.callback()
def main(
    ctx: typer.Context,
    json_out: Annotated[bool, typer.Option("--json", help="Machine-readable JSON output.")] = False,
    config_path: Annotated[
        Path | None, typer.Option("--config", help="Override config file location.")
    ] = None,
    profile: Annotated[
        str | None, typer.Option("--profile", help="Named credential profile / Atlassian site.")
    ] = None,
    cache_path: Annotated[
        Path | None, typer.Option("--cache", help="Override cache file location.")
    ] = None,
    no_cache: Annotated[
        bool, typer.Option("--no-cache", help="Bypass the cache; force a live API call.")
    ] = False,
    quiet: Annotated[bool, typer.Option("--quiet", "-q", help="Quieter logs.")] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="More verbose logs.")] = False,
    color: Annotated[
        bool | None,
        typer.Option("--color/--no-color", help="Colorize output (auto-off when piped)."),
    ] = None,
    yes: Annotated[
        bool, typer.Option("--yes", "-y", help="Skip confirmation prompts on destructive ops.")
    ] = False,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Show what would happen; don't apply.")
    ] = False,
) -> None:
    """Global flags shared by every command (stashed on the context)."""
    ctx.obj = _common.GlobalOptions(
        json=json_out,
        config=config_path,
        profile=profile,
        cache=cache_path,
        no_cache=no_cache,
        quiet=quiet,
        verbose=verbose,
        color=color,
        yes=yes,
        dry_run=dry_run,
    )


@app.command()
def version() -> None:
    """Print version / build info.

    Example:
        jira-helper version
    """
    typer.echo(__version__)


@app.command()
def init(ctx: typer.Context) -> None:
    """First-run onboarding wizard (alias of 'config init'). Feature: F001.

    Example:
        jira-helper init
    """
    config.run_init(ctx)


@app.command()
def doctor(ctx: typer.Context) -> None:
    """Read-only health check: config valid? creds ok? cache present? Feature: F001.

    Example:
        jira-helper doctor
    """
    opts = _common.get_opts(ctx)
    _common.run(
        ctx,
        lambda: _doctor_report(
            config_path=_common.as_str(opts.config),
            profile=opts.profile,
            cache_path=_common.as_str(opts.cache),
        ),
    )


def _doctor_report(
    *, config_path: str | None, profile: str | None, cache_path: str | None
) -> dict[str, Any]:
    """Aggregate a read-only health summary; each probe degrades, never raises."""
    report: dict[str, Any] = {}
    cfg_path = config_lib.path(config_path)
    report["config_path"] = str(cfg_path)
    report["config_exists"] = cfg_path.exists()

    try:
        data = config_lib.load(config_path=config_path)
    except JiraHelperError as exc:
        report["config"] = f"error: {exc}"
        data = {}
    else:
        missing = [k for k in config_lib.REQUIRED_KEYS if not data.get(k)]
        report["config"] = "ok" if not missing else f"missing: {', '.join(missing)}"

    if cfg_path.exists():
        mode = stat.S_IMODE(cfg_path.stat().st_mode)
        report["config_perms"] = format(mode, "04o")
        report["config_perms_ok"] = mode == 0o600

    if all(data.get(k) for k in config_lib.REQUIRED_KEYS):
        report["creds"] = _probe_creds(config_path=config_path, profile=profile)
    else:
        report["creds"] = "skipped (config incomplete)"

    db = cache_lib.path(cache_path=cache_path, config_path=config_path)
    report["cache_path"] = str(db)
    report["cache_exists"] = db.exists()
    return report


def _probe_creds(*, config_path: str | None, profile: str | None) -> str:
    """Live, read-only ``/myself`` ping (no chmod side effect, unlike `config verify`)."""
    try:
        with JiraClient.from_config(config_path=config_path, profile=profile) as client:
            me = client.get("/myself") or {}
    except JiraHelperError as exc:
        return f"error: {exc}"
    return f"ok ({me.get('displayName')})"


@app.command()
def spec(ctx: typer.Context) -> None:
    """Emit the entire command tree (commands, args, flags, types) for LLM/MCP ingest.

    Feature: F011. Use '--json' for the full structured tree; without it, a
    compact list of command paths.

    Example:
        jira-helper --json spec
    """
    opts = _common.get_opts(ctx)
    data = build_spec()
    if opts.json:
        output.render(data, as_json=True)
    else:
        typer.echo("\n".join(cmd["path"] for cmd in data["commands"]))


# --- spec introspection (F011) -------------------------------------------------


def build_spec(typer_app: typer.Typer | None = None) -> dict:
    """Introspect the (Typer-vendored) Click command tree into a structured dict.

    Duck-typed (``.commands`` / ``param_type_name``) so it stays robust across
    Typer versions, which vendor Click and do not expose it as a top-level import.
    """
    command = typer.main.get_command(typer_app or app)
    return {
        "name": "jira-helper",
        "version": __version__,
        "global_flags": [_describe_param(p) for p in command.params if _keep_param(p)],
        "commands": _walk(command, []),
    }


def _walk(command: Any, prefix: list[str]) -> list[dict]:
    subcommands = getattr(command, "commands", None)
    if subcommands:
        out: list[dict] = []
        for name in sorted(subcommands):
            out.extend(_walk(subcommands[name], [*prefix, name]))
        return out
    description, example = _split_example((command.help or command.short_help or "").strip())
    return [
        {
            "path": " ".join(prefix),
            "help": description,
            "example": example,
            "params": [_describe_param(p) for p in command.params if _keep_param(p)],
        }
    ]


def _split_example(text: str) -> tuple[str, str | None]:
    """Split a command's help into (description, first 'Example' block)."""
    marker = text.find("Example")
    if marker == -1:
        return text, None
    return text[:marker].strip(), text[marker:].strip()


def _keep_param(param: Any) -> bool:
    return getattr(param, "name", None) not in (None, "help")


def _describe_param(param: Any) -> dict:
    default = param.default
    if callable(default):
        default = None
    nargs = getattr(param, "nargs", 1)
    return {
        "name": param.name,
        "kind": getattr(param, "param_type_name", "parameter"),
        # both halves of a toggle (--color / --no-color) so the spec is complete
        "opts": [*getattr(param, "opts", []), *getattr(param, "secondary_opts", [])],
        "type": getattr(param.type, "name", str(param.type)),
        "required": bool(param.required),
        # variadic positional args carry nargs == -1 (Click never sets .multiple on them)
        "multiple": bool(getattr(param, "multiple", False)) or nargs == -1,
        "nargs": nargs,
        "default": default,
        "help": getattr(param, "help", None),
    }
