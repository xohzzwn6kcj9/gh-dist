"""Output rendering: human-readable by default, ``--json`` for scripting.

Pure and Typer-free so library callers can render without the CLI. The CLI
passes the resolved ``--json`` flag down as ``as_json``. Richer table rendering
lands with the features that need it; this is a minimal, dependable baseline.
"""

from __future__ import annotations

import json
from typing import Any


def to_json(data: Any) -> str:
    """Serialize *data* as pretty UTF-8 JSON (non-serializable values via ``str``)."""
    return json.dumps(data, indent=2, ensure_ascii=False, default=str)


def to_human(data: Any) -> str:
    """Render *data* as a plain, human-readable string."""
    if data is None:
        return ""
    if isinstance(data, str):
        return data
    if isinstance(data, dict):
        return "\n".join(f"{k}: {v}" for k, v in data.items())
    if isinstance(data, (list, tuple)):
        return _table(list(data))
    return str(data)


def _cell(value: Any) -> str:
    return "" if value is None else str(value)


def _table(rows: list) -> str:
    """Render a list of uniform dicts as an aligned table; else one item per line."""
    if not rows:
        return ""
    if not all(isinstance(r, dict) for r in rows):
        return "\n".join(_cell(r) for r in rows)
    columns = list(dict.fromkeys(key for row in rows for key in row))  # union, first-seen order
    widths = {c: max(len(c), *(len(_cell(r.get(c))) for r in rows)) for c in columns}
    lines = ["  ".join(c.ljust(widths[c]) for c in columns)]
    lines.append("  ".join("-" * widths[c] for c in columns))
    for row in rows:
        lines.append("  ".join(_cell(row.get(c)).ljust(widths[c]) for c in columns))
    return "\n".join(lines)


def render(data: Any, *, as_json: bool = False) -> None:
    """Print *data* to stdout as JSON (``as_json=True``) or a human view."""
    print(to_json(data) if as_json else to_human(data))
