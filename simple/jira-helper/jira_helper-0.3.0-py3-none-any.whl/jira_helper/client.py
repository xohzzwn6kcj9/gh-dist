"""Thin Jira Cloud REST v3 client (httpx, basic auth).

Auth is HTTP basic = ``base64(email:token)`` (the API token is NOT a password),
which httpx builds from the ``auth=(email, token)`` tuple. Requests return parsed
JSON; any 4xx/5xx (or a transport failure) becomes a :class:`JiraApiError`
carrying Jira's own error messages, so callers never see a raw traceback. A
``ConfluenceClient`` will join later (F012) sharing the same auth.
"""

from __future__ import annotations

from typing import Any

import httpx

from . import config
from .errors import ConfigError, JiraApiError

API_V3 = "/rest/api/3"


def _error_message(resp: httpx.Response) -> str:
    """Build a human message from a Jira error response (``errorMessages``/``errors``)."""
    try:
        body = resp.json()
    except ValueError:
        body = None
    if isinstance(body, dict):
        msgs = list(body.get("errorMessages") or [])
        errs = body.get("errors") or {}
        if isinstance(errs, dict):
            msgs += [f"{k}: {v}" for k, v in errs.items()]
        if msgs:
            return f"HTTP {resp.status_code}: {'; '.join(msgs)}"
    return f"HTTP {resp.status_code}: {resp.reason_phrase or 'request failed'}"


class JiraClient:
    """Minimal wrapper over the Jira Cloud REST API v3."""

    def __init__(
        self,
        base_url: str,
        email: str,
        api_token: str,
        *,
        timeout: float = 30.0,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.email = email
        self._auth = (email, api_token)
        self.timeout = timeout
        self._transport = transport  # injection seam for tests; None in production
        self._client: httpx.Client | None = None

    @classmethod
    def from_config(
        cls,
        *,
        config_path: str | None = None,
        profile: str | None = None,
    ) -> JiraClient:
        """Build a client from the resolved config (file + env), honoring ``profile``."""
        data = config.load(config_path=config_path)
        if profile is not None:
            profiles = data.get("profiles") or {}
            if profile not in profiles:
                raise ConfigError(f"config has no profile {profile!r}")
            data = {**data, **profiles[profile]}
        missing = [k for k in config.REQUIRED_KEYS if not data.get(k)]
        if missing:
            raise ConfigError(
                f"config missing required key(s): {', '.join(missing)} "
                "(run `jira-helper init` or set JIRA_* env vars)"
            )
        return cls(data["base_url"], data["email"], data["api_token"])

    @property
    def http(self) -> httpx.Client:
        """Lazily-constructed httpx client bound to ``{base_url}/rest/api/3``."""
        if self._client is None:
            self._client = httpx.Client(
                base_url=self.base_url + API_V3,
                auth=self._auth,
                timeout=self.timeout,
                transport=self._transport,
            )
        return self._client

    def _request(
        self, method: str, path: str, *, params: dict | None = None, json: Any = None
    ) -> Any:
        """Issue a request, raising :class:`JiraApiError` on any error; return parsed JSON."""
        try:
            resp = self.http.request(method, path, params=params or None, json=json)
        except httpx.HTTPError as exc:
            raise JiraApiError(f"request to Jira failed: {exc}") from exc
        if resp.status_code >= 400:
            raise JiraApiError(_error_message(resp), status=resp.status_code)
        if not resp.content:
            return None
        return resp.json()

    def get(self, path: str, **params: Any) -> Any:
        """GET a Jira REST v3 resource; query params come from ``**params``."""
        return self._request("GET", path, params=params)

    def post(self, path: str, *, json: Any = None) -> Any:
        """POST to a Jira REST v3 resource with a JSON body."""
        return self._request("POST", path, json=json)

    def close(self) -> None:
        """Close the underlying httpx client, if opened."""
        if self._client is not None:
            self._client.close()
            self._client = None

    def __enter__(self) -> JiraClient:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()
