"""`issue` commands — ticket queries (F004–F008)."""

from typing import Annotated

import typer

from .. import issue as issue_lib
from .. import output
from . import _common

app = typer.Typer(no_args_is_help=True, help="Query Jira issues (F004–F008).")

_READ = ("profile", "no_cache", "cache_path", "config_path")

# Shared sort flags (F046), reused across list / roots / tree.
_SortOpt = Annotated[
    str | None,
    typer.Option(
        "--sort",
        help="Sort field: created, updated, key, or status-category-changed (default created; "
        "status-category-changed is cache-only).",
    ),
]
_AscOpt = Annotated[
    bool, typer.Option("--asc", help="Sort ascending (overrides per-field default).")
]
_DescOpt = Annotated[
    bool, typer.Option("--desc", help="Sort descending (overrides per-field default).")
]

# Shared people + refinement filters, reused verbatim across `list` and `roots` (the latter is
# the verb form of `list --roots`, so it takes the identical filter surface — one source of truth
# here keeps their option/help text from drifting).
_AssigneeOpt = Annotated[
    list[str] | None, typer.Option("--assignee", help="Assignee name(s) or account-id(s).")
]
_OrgOpt = Annotated[
    list[str] | None,
    typer.Option("--org", help="Org unit name(s) — expands the subtree to its members."),
]
_JqlOpt = Annotated[str | None, typer.Option("--jql", help="Raw JQL passthrough (escape hatch).")]
_CreatedFromOpt = Annotated[
    str | None, typer.Option("--created-from", help="Created on/after (YYYY-MM-DD).")
]
_CreatedToOpt = Annotated[
    str | None, typer.Option("--created-to", help="Created on/before (inclusive; YYYY-MM-DD).")
]
_UpdatedFromOpt = Annotated[
    str | None,
    typer.Option("--updated-from", help="Updated on/after (YYYY-MM-DD or relative, e.g. -1w)."),
]
_UpdatedToOpt = Annotated[
    str | None,
    typer.Option("--updated-to", help="Updated on/before (inclusive; YYYY-MM-DD or relative)."),
]
_StatusCategoryChangedFromOpt = Annotated[
    str | None,
    typer.Option(
        "--status-category-changed-from",
        help="Status last changed on/after (YYYY-MM-DD or relative, e.g. -4w; cache-only).",
    ),
]
_StatusCategoryChangedToOpt = Annotated[
    str | None,
    typer.Option(
        "--status-category-changed-to",
        help="Status last changed on/before (inclusive; YYYY-MM-DD or relative; cache-only).",
    ),
]
_AssignedFromOpt = Annotated[
    str | None,
    typer.Option(
        "--assigned-from", help="Was assigned on/after (history; needs --assignee/--org)."
    ),
]
_AssignedToOpt = Annotated[
    str | None,
    typer.Option(
        "--assigned-to", help="Was assigned on/before (inclusive; needs --assignee/--org)."
    ),
]
_StatusCategoryOpt = Annotated[
    list[str] | None,
    typer.Option(
        "--status-category",
        help="Status category: To Do / In Progress / Done (aliases: todo, in-progress, done).",
    ),
]
_StatusOpt = Annotated[
    list[str] | None, typer.Option("--status", help="Keep only these exact status name(s).")
]
_ExcludeStatusOpt = Annotated[
    list[str] | None,
    typer.Option(
        "--exclude-status", help="Drop these status name(s), e.g. Cancelled (keeps completed work)."
    ),
]
_OpenOpt = Annotated[
    bool, typer.Option("--open", help="Open issues only (statusCategory != Done).")
]
_ProjectOpt = Annotated[
    list[str] | None, typer.Option("--project", help="Keep only these project key(s), e.g. PROJA.")
]
_ExcludeProjectOpt = Annotated[
    list[str] | None, typer.Option("--exclude-project", help="Drop these project key(s).")
]


@app.command("list")
def list_(
    ctx: typer.Context,
    assignee: _AssigneeOpt = None,
    org: _OrgOpt = None,
    jql: _JqlOpt = None,
    created_from: _CreatedFromOpt = None,
    created_to: _CreatedToOpt = None,
    updated_from: _UpdatedFromOpt = None,
    updated_to: _UpdatedToOpt = None,
    status_category_changed_from: _StatusCategoryChangedFromOpt = None,
    status_category_changed_to: _StatusCategoryChangedToOpt = None,
    assigned_from: _AssignedFromOpt = None,
    assigned_to: _AssignedToOpt = None,
    status_category: _StatusCategoryOpt = None,
    status: _StatusOpt = None,
    exclude_status: _ExcludeStatusOpt = None,
    open_: _OpenOpt = False,
    project: _ProjectOpt = None,
    exclude_project: _ExcludeProjectOpt = None,
    sort: _SortOpt = None,
    asc: _AscOpt = False,
    desc: _DescOpt = False,
    roots: Annotated[
        bool, typer.Option("--roots", help="Collapse the result to its root issues (F006).")
    ] = False,
    verbose: Annotated[
        bool,
        typer.Option(
            "--verbose",
            help="With --roots: show the path from each root epic down to the assigned tickets.",
        ),
    ] = False,
) -> None:
    """List issues by assignee/org/date/status/JQL, sorted. Feature: F004/F005/F007/F008/F045/F046.

    '--org' expands a unit's subtree (whole 실 or one 팀) to its members (F007).
    '--roots' collapses the result to its effective root issues (F006).
    '--created-from/--to' filters on the creation date; '--updated-from/--to' (F044) on
    last-modified — and since Jira stamps 'updated' on create, '--updated-from -1w' covers
    'created or modified in the last week' in one filter. Both accept an absolute date
    (2026-06-18) or a bare relative expression (-1w, startOfWeek()). Every '--*-to' bound
    is inclusive of the whole end day, to the minute, in the querying account's timezone
    (a bare end date becomes '<date> 23:59').
    '--status-category-changed-from/--to' (#79) filters by the last *status* transition — distinct
    from --updated-* (which advances on ANY edit, so link/comment housekeeping resurfaces a
    long-closed issue). It is CACHE-ONLY (run 'sync run' first; --no-cache/--jql/empty cache
    raise): the flat list also AND-combines --created/--updated-* against the cache, and
    --assignee/--org is optional (omitted = the whole synced product). Bounds take -4w/-30d
    or YYYY-MM-DD (day-granular, whole-day inclusive end).
    '--assigned-from/--assigned-to' (F008) filters by assignee *history* — issues the
    person held at some point in the window (assignee WAS IN ... DURING/AFTER/BEFORE);
    requires --assignee or --org, is mutually exclusive with --jql, and is live-only.
    Status filters (F045) refine an existing filter (they can't stand alone):
    '--open' = open issues only (statusCategory != Done); '--status-category' selects whole
    buckets (To Do / In Progress / Done; aliases todo/in-progress/done); '--status' keeps
    only the named status(es); '--exclude-status' drops them — '--exclude-status Cancelled'
    drops cancelled while KEEPING completed work (a category filter can't, since Cancelled
    sits in the Done bucket). '--open' and '--status-category' are the same axis (use one);
    any status filter is mutually exclusive with --jql and forces the live path.
    Project filters (F047) keep/drop by project, applied to the OUTPUT (the query stays
    full): '--project' keeps only the named project key(s) and '--exclude-project' drops
    them. For a plain list this is each ticket's own project; with '--roots' it is each
    result's effective ROOT — a (rule-derived) root in an excluded project is dropped even
    if the assigned ticket that climbed to it isn't. Both accept multiple keys, are
    refinements (can't stand alone), and are mutually exclusive with --jql.
    '--sort' (F046) orders by created / updated / key / status-category-changed with
    '--asc'/'--desc' (default created desc; key sorts naturally, PROJA-2 before PROJA-10;
    status-category-changed is cache-only, #79); it orders the flat list, the --roots set, and
    the --roots --verbose / tree siblings alike, and is exclusive with --jql.
    The default (non-JSON) view is one line per ticket (KEY — summary [status]);
    '--roots' collapses it to the distinct root epics, and '--roots --verbose' shows
    the path from each root epic down to the assigned tickets as a tree — only the
    relevant chain, not the root's whole subtree; assigned leaves are marked '← name'.
    '--json' returns the underlying structure (flat list, or the nested forest).

    Example:
        jira-helper issue list --assignee 홍길동 --open --sort updated
        jira-helper issue list --org 플랫폼개발실 --exclude-status 취소
        jira-helper issue list --status-category-changed-from -4w --sort status-category-changed
        jira-helper issue list --org 플랫폼개발실 --sort key --asc
    Example output:
        PROJA-12 — Fix login [In Progress]
        PROJA-15 — Add SSO [To Do]
    """
    _common.run(
        ctx,
        lambda: issue_lib.list(
            assignee=assignee,
            org=org,
            jql=jql,
            created_from=created_from,
            created_to=created_to,
            updated_from=updated_from,
            updated_to=updated_to,
            status_category_changed_from=status_category_changed_from,
            status_category_changed_to=status_category_changed_to,
            assigned_from=assigned_from,
            assigned_to=assigned_to,
            status_category=status_category,
            status=status,
            exclude_status=exclude_status,
            open_only=open_,
            project=project,
            exclude_project=exclude_project,
            sort=sort,
            asc=asc,
            desc=desc,
            roots=roots,
            paths=roots and verbose,
            **_common.opt_kwargs(ctx, _READ),
        ),
        human=lambda r: output.format_tree(r, **_common.color_kwargs(ctx)),
    )


@app.command()
def roots(
    ctx: typer.Context,
    assignee: _AssigneeOpt = None,
    org: _OrgOpt = None,
    jql: _JqlOpt = None,
    created_from: _CreatedFromOpt = None,
    created_to: _CreatedToOpt = None,
    updated_from: _UpdatedFromOpt = None,
    updated_to: _UpdatedToOpt = None,
    status_category_changed_from: _StatusCategoryChangedFromOpt = None,
    status_category_changed_to: _StatusCategoryChangedToOpt = None,
    assigned_from: _AssignedFromOpt = None,
    assigned_to: _AssignedToOpt = None,
    status_category: _StatusCategoryOpt = None,
    status: _StatusOpt = None,
    exclude_status: _ExcludeStatusOpt = None,
    open_: _OpenOpt = False,
    project: _ProjectOpt = None,
    exclude_project: _ExcludeProjectOpt = None,
    verbose: Annotated[
        bool,
        typer.Option("--verbose", help="Show the path down to each assigned ticket as a tree."),
    ] = False,
    sort: _SortOpt = None,
    asc: _AscOpt = False,
    desc: _DescOpt = False,
) -> None:
    """Root issues of an assignee/org set (walk effective parents). Feature: F006/F046.

    Sugar for 'issue list --roots' — takes the same refinement filters as 'issue list'
    (status/date/project/status-category-changed/--jql), forwarded unchanged. Reads the local cache
    (recursive CTE over effective_parent) when populated, else walks the live API. The
    default view lists each root epic on one line; add '--verbose' to show the paths down to
    the assigned tickets as a tree (assigned leaves marked '← name'). '--sort' (F046) orders
    by created / updated / key / status-category-changed with '--asc'/'--desc' (default
    created desc). '--json' returns the underlying structure. With '--roots', both the project
    filter and the cache-only '--status-category-changed-from/--to' (#79) key on each result's
    effective root (it needs --assignee/--org here, and can't combine with --created/--updated-*).

    Example:
        jira-helper issue roots --org 플랫폼개발실 --open --project PROJA
        jira-helper issue roots --assignee alice --updated-from -1w --verbose --sort key --asc
    Example output (--verbose):
        PROJA-50 — Epic: Auth revamp [In Progress]
          PROJA-12 — Fix login [In Progress]  ← 홍길동
    """
    _common.run(
        ctx,
        lambda: issue_lib.roots(
            assignee=assignee,
            org=org,
            jql=jql,
            created_from=created_from,
            created_to=created_to,
            updated_from=updated_from,
            updated_to=updated_to,
            status_category_changed_from=status_category_changed_from,
            status_category_changed_to=status_category_changed_to,
            assigned_from=assigned_from,
            assigned_to=assigned_to,
            status_category=status_category,
            status=status,
            exclude_status=exclude_status,
            open_only=open_,
            project=project,
            exclude_project=exclude_project,
            paths=verbose,
            sort=sort,
            asc=asc,
            desc=desc,
            **_common.opt_kwargs(ctx, _READ),
        ),
        human=lambda r: output.format_tree(r, **_common.color_kwargs(ctx)),
    )


@app.command()
def tree(
    ctx: typer.Context,
    key: Annotated[str, typer.Argument(help="Issue key, e.g. PROJA-123.")],
    sort: _SortOpt = None,
    asc: _AscOpt = False,
    desc: _DescOpt = False,
) -> None:
    """Parent→child hierarchy for KEY (native + virtual rules). Feature: F006/F046.

    Climbs to KEY's effective root, then expands the subtree; each node is
    annotated with the rule that set its effective parent. Cache-backed when
    populated, else a live walk. The default view is an indented tree; '--json'
    emits the nested dict. '--sort' (F046) orders siblings within each level by
    created / updated / key / status-category-changed with '--asc'/'--desc' (default created
    desc; --sort status-category-changed is cache-only, #79 — raises on --no-cache/unsynced KEY).

    Example:
        jira-helper issue tree PROJA-123 --sort key --asc
    Example output:
        PROJA-50 — Epic: Auth revamp [In Progress]
          PROJA-123 — Fix login [To Do]  (via epic-single-link)
        ...
    """
    _common.run(
        ctx,
        lambda: issue_lib.tree(
            key, sort=sort, asc=asc, desc=desc, **_common.opt_kwargs(ctx, _READ)
        ),
        human=lambda r: output.format_tree(r, **_common.color_kwargs(ctx)),
    )


@app.command()
def get(
    ctx: typer.Context,
    key: Annotated[str, typer.Argument(help="Issue key, e.g. PROJA-123.")],
) -> None:
    """One issue's fields (live). Feature: F004.

    Returns a single flat record (key, summary, status, issue_type, assignee,
    assignee_id, project, parent, created, updated).

    Example:
        jira-helper issue get PROJA-123
    Example output (--json):
        {"key": "PROJA-123", "summary": "Fix login", "status": "In Progress",
         "assignee": "홍길동", "assignee_id": "5b10a2...", ...}
    """
    _common.run(ctx, lambda: issue_lib.get(key, **_common.opt_kwargs(ctx, _READ)))
