"""`org` commands — hierarchical org units + member CRUD (F007, F009)."""

from typing import Annotated

import typer

from .. import org as org_lib
from . import _common

app = typer.Typer(no_args_is_help=True, help="Manage the org hierarchy + members (F009).")

_CFG = ("config_path",)


# --- human renderers (non-JSON views the generic table can't express) --------


def _fmt_member(m: dict) -> str:
    label = f"{m['name']} ({m['account_id']})"
    return label if m.get("resolved") else f"{label} [미해소]"


def _format_tree(data: dict) -> str:
    lines: list[str] = []

    def walk(node: dict, depth: int) -> None:
        label = node["name"]
        if node.get("type"):
            label += f" ({node['type']})"
        if node.get("member_count"):
            label += f" — {node['member_count']}명"
        lines.append("  " * depth + label)
        for child in node.get("children", []):
            walk(child, depth + 1)

    roots = data["roots"] if "roots" in data else [data]
    for root in roots:
        walk(root, 0)
    return "\n".join(lines) or "(empty)"


def _format_show(d: dict) -> str:
    lines = [
        f"name: {d['name']}",
        f"type: {d.get('type')}",
        f"parent: {d.get('parent')}",
        f"children: {', '.join(d.get('children') or []) or '(none)'}",
        "members (direct):",
    ]
    lines += [f"  - {_fmt_member(m)}" for m in d.get("members", [])] or ["  (none)"]
    if "effective_members" in d:
        lines.append("members (effective):")
        lines += [f"  - {_fmt_member(m)}" for m in d["effective_members"]] or ["  (none)"]
    return "\n".join(lines)


# --- commands ----------------------------------------------------------------


@app.command("list")
def list_(
    ctx: typer.Context,
    type: Annotated[
        str | None, typer.Option("--type", help="Filter by unit type (그룹/부문/실/팀/파트).")
    ] = None,
) -> None:
    """List all org units (name, type, parent, member count). Feature: F009.

    Example:
        jira-helper org list --type 팀
    Example output (--json):
        [{"name": "서비스개발팀", "type": "팀", "parent": "플랫폼개발실", "member_count": 4}, ...]
    """
    _common.run(ctx, lambda: org_lib.list(type=type, **_common.opt_kwargs(ctx, _CFG)))


@app.command()
def show(
    ctx: typer.Context,
    unit: Annotated[str, typer.Argument(help="Org unit name.")],
    direct: Annotated[
        bool, typer.Option("--direct", help="Own members only (skip subtree union).")
    ] = False,
) -> None:
    """A unit's type/parent/children + direct & effective members. Feature: F009.

    Example:
        jira-helper org show 플랫폼개발실
    Example output (--json):
        {"name": "플랫폼개발실", "type": "실", "parent": null, "children": ["서비스개발팀"],
         "members": [{"name": "홍길동", "account_id": "5b10a2...", "resolved": true}],
         "effective_members": [...]}
    """
    _common.run(
        ctx,
        lambda: org_lib.show(unit, direct=direct, **_common.opt_kwargs(ctx, _CFG)),
        human=_format_show,
    )


@app.command()
def tree(
    ctx: typer.Context,
    unit: Annotated[str | None, typer.Argument(help="Root unit (omit = whole forest).")] = None,
) -> None:
    """Render the org as an indented hierarchy. Feature: F009.

    Example:
        jira-helper org tree 플랫폼개발실
    Example output (--json):
        {"name": "플랫폼개발실", "type": "실", "member_count": 0,
         "children": [{"name": "서비스개발팀", ...}]}
    """
    _common.run(
        ctx,
        lambda: org_lib.tree(unit, **_common.opt_kwargs(ctx, _CFG)),
        human=_format_tree,
    )


@app.command()
def members(
    ctx: typer.Context,
    unit: Annotated[str, typer.Argument(help="Org unit name.")],
    direct: Annotated[
        bool, typer.Option("--direct", help="Own members only (skip subtree union).")
    ] = False,
) -> None:
    """Resolved member set a query will hit (name+id, unresolved flagged). Feature: F007.

    '--direct' restricts to the unit's own members (skips the subtree union).

    Example:
        jira-helper org members 플랫폼개발실
    Example output (--json):
        [{"name": "홍길동", "account_id": "5b10a2...", "resolved": true},
         {"name": "미등록", "account_id": "미등록", "resolved": false}]
    """
    _common.run(ctx, lambda: org_lib.members(unit, direct=direct, **_common.opt_kwargs(ctx, _CFG)))


@app.command()
def create(
    ctx: typer.Context,
    unit: Annotated[str, typer.Argument(help="New unit name (unique).")],
    type: Annotated[
        str | None, typer.Option("--type", help="Free-form level label (그룹/부문/실/팀/파트).")
    ] = None,
    parent: Annotated[
        str | None, typer.Option("--parent", help="Parent unit name (omit = root).")
    ] = None,
    member: Annotated[
        list[str] | None, typer.Option("--member", help="Seed member name(s) or account-id(s).")
    ] = None,
) -> None:
    """Create an org unit (optional type/parent/members). Feature: F009.

    Example:
        jira-helper org create 서비스개발팀 --type 팀 --parent 플랫폼개발실 --member 홍길동
    Example output (--json):
        {"name": "서비스개발팀", "type": "팀", "parent": "플랫폼개발실", "members": ["홍길동"]}
    """
    _common.run(
        ctx,
        lambda: org_lib.create(
            unit, type=type, parent=parent, members=member, **_common.opt_kwargs(ctx, _CFG)
        ),
    )


@app.command()
def move(
    ctx: typer.Context,
    unit: Annotated[str, typer.Argument(help="Unit to re-parent.")],
    parent: Annotated[str | None, typer.Option("--parent", help="New parent unit name.")] = None,
    root: Annotated[bool, typer.Option("--root", help="Make the unit a root (no parent).")] = False,
) -> None:
    """Re-parent a unit's subtree (--parent <name> or --root). Feature: F009.

    Example:
        jira-helper org move 서비스개발팀 --parent 차세대플랫폼실
    Example output (--json):
        {"name": "서비스개발팀", "type": "팀", "parent": "차세대플랫폼실", "members": [...]}
    """
    if not root and parent is None:
        raise typer.BadParameter("specify --parent <name> or --root")
    _common.run(
        ctx,
        lambda: org_lib.move(unit, None if root else parent, **_common.opt_kwargs(ctx, _CFG)),
    )


@app.command()
def rename(
    ctx: typer.Context,
    old: Annotated[str, typer.Argument(help="Current unit name.")],
    new: Annotated[str, typer.Argument(help="New unit name.")],
) -> None:
    """Rename a unit (children's parent pointers follow). Feature: F009.

    Example:
        jira-helper org rename 플랫폼개발실 차세대플랫폼실
    Example output (--json):
        {"name": "차세대플랫폼실", "type": "실", "members": [...]}
    """
    _common.run(ctx, lambda: org_lib.rename(old, new, **_common.opt_kwargs(ctx, _CFG)))


@app.command("add-member")
def add_member(
    ctx: typer.Context,
    unit: Annotated[str, typer.Argument(help="Org unit name.")],
    member: Annotated[list[str], typer.Argument(help="Member name(s) or account-id(s).")],
) -> None:
    """Add member(s) to a unit's own list. Feature: F009.

    Example:
        jira-helper org add-member 서비스개발팀 홍길동 김철수
    Example output (--json):
        {"name": "서비스개발팀", "type": "팀", "members": ["홍길동", "김철수"]}
    """
    _common.run(ctx, lambda: org_lib.add_member(unit, member, **_common.opt_kwargs(ctx, _CFG)))


@app.command("remove-member")
def remove_member(
    ctx: typer.Context,
    unit: Annotated[str, typer.Argument(help="Org unit name.")],
    member: Annotated[list[str], typer.Argument(help="Member(s) to remove.")],
) -> None:
    """Remove member(s) from a unit's own list. Feature: F009.

    Example:
        jira-helper org remove-member 서비스개발팀 김철수
    Example output (--json):
        {"name": "서비스개발팀", "type": "팀", "members": ["홍길동"]}
    """
    _common.run(ctx, lambda: org_lib.remove_member(unit, member, **_common.opt_kwargs(ctx, _CFG)))


@app.command()
def delete(
    ctx: typer.Context,
    unit: Annotated[str, typer.Argument(help="Unit to delete.")],
    recursive: Annotated[
        bool, typer.Option("--recursive", help="Also delete all descendant units.")
    ] = False,
) -> None:
    """Delete a unit (refuses children unless --recursive). Feature: F009.

    Example:
        jira-helper org delete 서비스개발팀
    Example output:
        True
    """
    _common.run(
        ctx, lambda: org_lib.delete(unit, recursive=recursive, **_common.opt_kwargs(ctx, _CFG))
    )


@app.command()
def validate(ctx: typer.Context) -> None:
    """Check the tree (dangling/cycle/dup/empty-leaf/unresolved members). Feature: F009.

    Prints nothing (empty list) when clean; otherwise one row per problem.

    Example:
        jira-helper org validate
    Example output (--json):
        [{"level": "warning", "code": "unresolved_member", "unit": "서비스개발팀",
          "message": "member '...' not in account store"}]
    """
    _common.run(ctx, lambda: org_lib.validate(**_common.opt_kwargs(ctx, _CFG)))


@app.command()
def edit(ctx: typer.Context) -> None:
    """Open org.yaml in $EDITOR (bulk authoring). Feature: F009.

    Seeds an empty org.yaml if absent, opens it in $EDITOR/$VISUAL (else vi),
    then prints the file path.

    Example:
        jira-helper org edit
    Example output:
        ~/.config/jira-helper/org.yaml
    """
    _common.run_path(
        ctx,
        lambda: _common.open_in_editor(
            org_lib.path(**_common.opt_kwargs(ctx, _CFG)), seed="orgs: []\n"
        ),
    )


@app.command()
def path(ctx: typer.Context) -> None:
    """Print the org-store file location. Feature: F009.

    Example:
        jira-helper org path
    Example output:
        ~/.config/jira-helper/org.yaml
    """
    _common.run_path(ctx, lambda: org_lib.path(**_common.opt_kwargs(ctx, _CFG)))
