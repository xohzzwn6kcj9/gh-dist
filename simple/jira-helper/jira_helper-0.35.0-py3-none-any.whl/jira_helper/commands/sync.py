"""`sync` commands — cron/launchd-friendly cache refresh (F010)."""

from typing import Annotated

import typer

from .. import sync as sync_lib
from . import _common

app = typer.Typer(no_args_is_help=True, help="Background cache refresh (F010).")


@app.command()
def run(
    ctx: typer.Context,
    product: Annotated[str, typer.Option("--product", help="Product to refresh.")] = "jira",
    full: Annotated[bool, typer.Option("--full", help="Full resync (ignore watermark).")] = False,
    since: Annotated[str | None, typer.Option("--since", help="Lower bound timestamp.")] = None,
) -> None:
    """Incremental, idempotent cache refresh. Feature: F010.

    --full forces a complete resync (wipe the product's rows, ignore the
    watermark); --since <ts> overrides the stored watermark lower bound.

    Example:
        jira-helper sync run --product jira
    Example output:
        product: jira
        synced: 42
        ancestors_added: 7
        recomputed: 0
        watermark: 2026-06-21T03:14:00.000+0000
        full: False
    """
    _common.run(
        ctx,
        lambda: sync_lib.run(
            product=product,
            full=full,
            since=since,
            **_common.opt_kwargs(ctx, ("profile", "cache_path", "config_path")),
        ),
    )


@app.command()
def status(ctx: typer.Context) -> None:
    """Last run time, watermark, lock state, last error. Feature: F010.

    Example:
        jira-helper sync status
    Example output:
        last_sync_at: 2026-06-21T03:14:05.123456+00:00
        watermark: 2026-06-21T03:14:00.000+0000
        locked: False
        last_error: None
    """
    _common.run(
        ctx, lambda: sync_lib.status(**_common.opt_kwargs(ctx, ("cache_path", "config_path")))
    )


@app.command()
def install(
    ctx: typer.Context,
    cron: Annotated[bool, typer.Option("--cron", help="Install a cron unit.")] = False,
    launchd: Annotated[
        bool, typer.Option("--launchd", help="Install a launchd unit (default).")
    ] = False,
    schedule: Annotated[str | None, typer.Option("--schedule", help="Schedule expression.")] = None,
) -> None:
    """Render the scheduler unit and write it beside the config. Feature: F010.

    --launchd (default) uses --schedule as interval seconds (default 3600);
    --cron uses --schedule as a crontab expression. The unit is only written —
    loading it (launchctl load / crontab) is the returned next_step, so the live
    scheduler is never touched.

    Example:
        jira-helper sync install --launchd
    Example output:
        scheduler: launchd
        path: ~/.config/jira-helper/com.jira-helper.sync.plist
        unit: <?xml version="1.0" encoding="UTF-8"?>...
        next_step: launchctl load ~/.config/jira-helper/com.jira-helper.sync.plist
    """
    scheduler = "cron" if cron else "launchd"
    _common.run(
        ctx,
        lambda: sync_lib.install(
            scheduler=scheduler,
            schedule=schedule,
            **_common.opt_kwargs(ctx, ("config_path",)),
        ),
    )
