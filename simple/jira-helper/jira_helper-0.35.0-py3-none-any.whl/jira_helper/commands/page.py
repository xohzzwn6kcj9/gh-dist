"""`page` commands — Confluence page queries (F012)."""

from typing import Annotated

import typer

from .. import page as page_lib
from . import _common

app = typer.Typer(no_args_is_help=True, help="Query Confluence pages (F012).")

_READ = ("profile", "no_cache", "cache_path", "config_path")


@app.command("list")
def list_(
    ctx: typer.Context,
    space: Annotated[str, typer.Option("--space", help="Confluence space key (required).")],
    folder: Annotated[
        str | None,
        typer.Option("--folder", help="Folder/parent content id — subtree via CQL ancestor."),
    ] = None,
    title_contains: Annotated[
        str | None,
        typer.Option("--title-contains", help="Keep pages whose title contains this keyword."),
    ] = None,
    direct: Annotated[
        bool,
        typer.Option("--direct", help="Direct children only (parent) instead of whole subtree."),
    ] = False,
) -> None:
    """List pages in a space, under a folder, whose title contains a keyword. Feature: F012.

    '--folder' accepts a folder content-type id OR a parent-page id (both match the
    whole subtree via CQL ancestor); '--direct' narrows to immediate children.
    '--title-contains' is a literal, case-insensitive substring filter.

    Example:
        jira-helper page list --space DOCS --folder 123456 --title-contains runbook
    Example output (--json):
        [{"id": "789", "title": "Service runbook", "space": "DOCS",
          "uri": "https://your-domain.atlassian.net/wiki/spaces/DOCS/pages/789/Service+runbook"}]
    """
    _common.run(
        ctx,
        lambda: page_lib.list(
            space=space,
            folder=folder,
            title_contains=title_contains,
            direct=direct,
            **_common.opt_kwargs(ctx, _READ),
        ),
    )


@app.command()
def get(
    ctx: typer.Context,
    page_id: Annotated[str, typer.Argument(help="Confluence page id, e.g. 123456.")],
) -> None:
    """One page's fields by id (live, v2 API). Feature: F012.

    Returns a single flat record (id, title, space, uri). A missing id surfaces as
    a structured 'not_found' (exit 2), not a silent null.

    Example:
        jira-helper page get 123456
    Example output (--json):
        {"id": "123456", "title": "Service runbook", "space": "789",
         "uri": "https://your-domain.atlassian.net/wiki/spaces/DOCS/pages/123456/Service+runbook"}
    """
    _common.run(
        ctx,
        lambda: _common.require(
            page_lib.get(page_id, **_common.opt_kwargs(ctx, _READ)),
            f"page {page_id!r} not found",
        ),
    )


@app.command()
def search(
    ctx: typer.Context,
    cql: Annotated[str, typer.Argument(help="Raw CQL, e.g. 'space = DOCS AND type = page'.")],
) -> None:
    """Raw CQL passthrough (escape hatch). Feature: F012.

    Mirrors 'issue list --jql': the CQL is sent verbatim, with no
    space/folder/title-contains composition. Returns the same flat shape as 'page list'.

    Example:
        jira-helper page search "space = DOCS AND title ~ 'runbook'"
    Example output (--json):
        [{"id": "789", "title": "Service runbook", "space": "DOCS",
          "uri": "https://your-domain.atlassian.net/wiki/spaces/DOCS/pages/789/Service+runbook"}]
    """
    _common.run(ctx, lambda: page_lib.search(cql, **_common.opt_kwargs(ctx, _READ)))
