"""Thin Typer sub-apps, one module per noun, mirroring the library API modules.

Each module exposes ``app`` (a ``typer.Typer``) wired onto the root app in
``jira_helper.cli``. Commands only parse arguments and forward to the matching
``jira_helper.<noun>.<verb>`` function — no behavior lives here.
"""
