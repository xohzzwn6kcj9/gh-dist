"""F001 — configuration: onboarding, load/save, and path resolution.

The config holds the Jira Cloud connection essentials (base URL, account email,
API token, ...). It lives at ``$JIRA_HELPER_CONFIG`` if set, otherwise under the
XDG config dir (``~/.config/jira-helper/``); the cache (``cache.db``) and the
account / team / rule stores sit beside it. Secrets are protected by file
permissions (``chmod 600``), not an OS keychain. Format is YAML (JSON accepted).

``load`` merges the file with ``JIRA_*`` environment variables (env overrides
file), so the tool works either after ``init`` or from a plain ``.env``-style
export. Writes (``save``/``set``/``init``) only ever touch the file.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml

from .errors import ConfigError, NotFoundError

APP_DIRNAME = "jira-helper"
CONFIG_FILENAME = "config.yaml"  # YAML preferred (F003); JSON is an accepted alternative.

REQUIRED_KEYS = ("base_url", "email", "api_token")
_SECRET_KEYS = frozenset({"api_token"})
# config key -> environment variable that overrides it (F001 / README contract).
_ENV_MAP = {"base_url": "JIRA_BASE_URL", "email": "JIRA_EMAIL", "api_token": "JIRA_API_TOKEN"}
_MASK = "****"


def _xdg_config_home() -> Path:
    """Return ``$XDG_CONFIG_HOME`` if set, otherwise ``~/.config``."""
    return Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config")


def path(config_path: str | os.PathLike[str] | None = None) -> Path:
    """Resolve the config file location.

    Precedence: explicit ``config_path`` (the ``--config`` flag) →
    ``$JIRA_HELPER_CONFIG`` → ``$XDG_CONFIG_HOME/jira-helper/config.yaml``.
    """
    if config_path is not None:
        return Path(config_path).expanduser()
    env = os.environ.get("JIRA_HELPER_CONFIG")
    if env:
        return Path(env).expanduser()
    return _xdg_config_home() / APP_DIRNAME / CONFIG_FILENAME


def config_dir(config_path: str | os.PathLike[str] | None = None) -> Path:
    """Directory holding the config file (and, beside it, cache + stores)."""
    return path(config_path).parent


def _read_file(config_path: str | os.PathLike[str] | None) -> dict[str, Any]:
    """Parse the config file into a dict (``{}`` if absent). YAML reads JSON too."""
    p = path(config_path)
    if not p.exists():
        return {}
    try:
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        raise ConfigError(f"config file is not valid YAML/JSON: {p} ({exc})") from exc
    if not isinstance(data, dict):
        raise ConfigError(f"config file must be a mapping, got {type(data).__name__}: {p}")
    return data


def _mask(key: str, value: Any) -> Any:
    """Replace a secret value with ``****`` (empty/missing values pass through)."""
    return _MASK if key in _SECRET_KEYS and value else value


def init(
    *,
    base_url: str,
    email: str,
    api_token: str,
    config_path: str | os.PathLike[str] | None = None,
    force: bool = False,
) -> Path:
    """F001: write the onboarding config (chmod 600); refuse to clobber unless ``force``.

    The CLI collects the values interactively; this function just validates and
    persists them so it stays unit-testable without a TTY.
    """
    p = path(config_path)
    if p.exists() and not force:
        raise ConfigError(f"config already exists: {p} (use --yes to overwrite)")
    return save(
        {"base_url": base_url.rstrip("/"), "email": email, "api_token": api_token},
        config_path=config_path,
    )


def load(*, config_path: str | os.PathLike[str] | None = None) -> dict[str, Any]:
    """Resolved config = file overlaid with ``JIRA_*`` env vars (env wins)."""
    data = _read_file(config_path)
    for key, env in _ENV_MAP.items():
        env_value = os.environ.get(env)
        if env_value:
            data[key] = env_value
    return data


def save(data: dict[str, Any], *, config_path: str | os.PathLike[str] | None = None) -> Path:
    """Persist *data* to the config file as 0o600 (no plaintext-token exposure window)."""
    p = path(config_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    text = yaml.safe_dump(data, sort_keys=True, allow_unicode=True)
    # Create with 0o600 from the first byte (O_CREAT mode), so a new token file is
    # never briefly world-readable between write and chmod (TOCTOU).
    fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        os.write(fd, text.encode("utf-8"))
    finally:
        os.close(fd)
    p.chmod(0o600)  # re-assert for a pre-existing file that had looser perms
    return p


def show(
    *, config_path: str | os.PathLike[str] | None = None, reveal: bool = False
) -> dict[str, Any]:
    """The resolved config with secrets masked (unless ``reveal``) — for display."""
    data = load(config_path=config_path)
    if reveal:
        return data
    return {key: _mask(key, value) for key, value in data.items()}


def get(
    key: str, *, config_path: str | os.PathLike[str] | None = None, reveal: bool = False
) -> Any:
    """Read one config field (token-like values masked unless ``reveal``)."""
    data = load(config_path=config_path)
    if key not in data:
        raise NotFoundError(f"config has no key {key!r}")
    return data[key] if reveal else _mask(key, data[key])


def set(key: str, value: Any, *, config_path: str | os.PathLike[str] | None = None) -> Path:
    """Set one config field non-interactively (re-chmod 600 on write).

    Writes to the file only (env overrides are a read-time concern).
    """
    data = _read_file(config_path)
    data[key] = value
    return save(data, config_path=config_path)


def verify(
    *,
    config_path: str | os.PathLike[str] | None = None,
    profile: str | None = None,
) -> dict[str, Any]:
    """Live auth ping (``/myself``) + re-assert chmod 600; return a health summary."""
    from .client import JiraClient  # local import: client imports config (avoid a cycle)

    data = load(config_path=config_path)
    missing = [k for k in REQUIRED_KEYS if not data.get(k)]
    if missing:
        raise ConfigError(f"config missing required key(s): {', '.join(missing)}")
    p = path(config_path)
    if p.exists():
        p.chmod(0o600)
    with JiraClient.from_config(config_path=config_path, profile=profile) as client:
        me = client.get("/myself")
    me = me or {}
    return {
        "ok": True,
        "base_url": data["base_url"],
        "account_id": me.get("accountId"),
        "display_name": me.get("displayName"),
        "email": me.get("emailAddress"),
    }
