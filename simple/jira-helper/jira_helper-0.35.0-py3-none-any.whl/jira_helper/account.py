"""F002/F003 — name ↔ Atlassian account-id store.

An external YAML file (beside the config) is the SOLE store; the CLI reads and
writes it via ``list`` / ``get`` / ``add`` / ``remove``. ``search`` is an
OUTPUT-ONLY live lookup (profile link + candidate ids) that writes nothing — the
caller reads its output, then uses ``add`` to record a choice.

All entry points are wired; ``search`` is the only one that hits the live API.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from . import config

STORE_FILENAME = "accounts.yaml"
_STORE_KEY = "accounts"


def path(*, config_path: str | None = None) -> Path:
    """Resolve the account-store file location (beside the config)."""
    return config.config_dir(config_path) / STORE_FILENAME


def _read(config_path: str | None) -> list[dict[str, str]]:
    """Load the store as a list of ``{name, account_id}`` (``[]`` if absent)."""
    p = path(config_path=config_path)
    if not p.exists():
        return []
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    return data.get(_STORE_KEY, []) if isinstance(data, dict) else []


def _write(config_path: str | None, accounts: list[dict[str, str]]) -> Path:
    p = path(config_path=config_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(
        yaml.safe_dump({_STORE_KEY: accounts}, sort_keys=True, allow_unicode=True),
        encoding="utf-8",
    )
    return p


def list(*, config_path: str | None = None) -> list[dict[str, str]]:
    """F003: list all name↔account-id mappings from the store."""
    return _read(config_path)


def get(name_or_id: str, *, config_path: str | None = None) -> dict[str, str] | None:
    """F002/F003: resolve a name or account-id from the store (either direction)."""
    for entry in _read(config_path):
        if entry.get("name") == name_or_id or entry.get("account_id") == name_or_id:
            return entry
    return None


def add(name: str, account_id: str, *, config_path: str | None = None) -> dict[str, str]:
    """F003: write/update a name→account-id mapping in the store (upsert by name)."""
    accounts = _read(config_path)
    for entry in accounts:
        if entry.get("name") == name:
            entry["account_id"] = account_id
            break
    else:
        accounts.append({"name": name, "account_id": account_id})
    _write(config_path, accounts)
    return {"name": name, "account_id": account_id}


def remove(name_or_id: str, *, config_path: str | None = None) -> bool:
    """F003: delete a mapping from the store; return whether anything was removed."""
    accounts = _read(config_path)
    kept = [
        e for e in accounts if e.get("name") != name_or_id and e.get("account_id") != name_or_id
    ]
    if len(kept) == len(accounts):
        return False
    _write(config_path, kept)
    return True


def search(
    name: str, *, profile: str | None = None, config_path: str | None = None
) -> list[dict[str, Any]]:
    """F002: OUTPUT-ONLY live user lookup → profile link + candidate ids. Writes nothing."""
    from .client import JiraClient  # local import keeps the offline store path dependency-free

    with JiraClient.from_config(config_path=config_path, profile=profile) as client:
        users = client.get("/user/search", query=name)
        base_url = client.base_url
    return [
        {
            "displayName": u.get("displayName"),
            "accountId": u.get("accountId"),
            "emailAddress": u.get("emailAddress"),
            "profile": f"{base_url}/jira/people/{u.get('accountId')}",
        }
        for u in (users or [])
    ]
