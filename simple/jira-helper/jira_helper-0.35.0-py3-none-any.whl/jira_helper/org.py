"""F007/F009 — hierarchical org units (group▸division▸office▸team▸part) + member CRUD.

An "org unit" is a user-defined node in a tree (NOT a Jira/Confluence Team). Each
record has a unique ``name``, an optional free-form ``type`` label (그룹/부문/실/팀/파트
— never validated, so levels may be skipped and 파트 is optional), an optional
``parent`` (another unit's name; omitted = root), and optional ``members``.

Members attach to ANY node; a unit's EFFECTIVE member set is the subtree union
(self + all descendants' own members), computed on read — there is no stored
rollup to drift. Member tokens are names (resolved via the F003 account store) or
raw account-ids. Units live in ``org.yaml`` beside the config.

Querying a unit's issues is ``issue list --org`` (F007); this module is org
metadata only. Pure tree logic (index / subtree / validate) is I/O-free; file and
account-store access live at the edges.
"""

from __future__ import annotations

import builtins
from pathlib import Path
from typing import Any

import yaml

from . import account, config
from ._util import dedup
from .errors import ConfigError, NotFoundError

STORE_FILENAME = "org.yaml"
_STORE_KEY = "orgs"

Unit = dict[str, Any]


def path(*, config_path: str | None = None) -> Path:
    """Resolve the org-store file location (beside the config)."""
    return config.config_dir(config_path) / STORE_FILENAME


# --- store I/O (edges) --------------------------------------------------------


def _read(config_path: str | None) -> list[Unit]:
    """Load the org units (``[]`` if absent)."""
    p = path(config_path=config_path)
    if not p.exists():
        return []
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    units = data.get(_STORE_KEY, []) if isinstance(data, dict) else []
    return units if isinstance(units, builtins.list) else []


def _write(config_path: str | None, units: list[Unit]) -> Path:
    p = path(config_path=config_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    # sort_keys=False keeps authored top-down order (parents before children).
    p.write_text(
        yaml.safe_dump({_STORE_KEY: units}, sort_keys=False, allow_unicode=True),
        encoding="utf-8",
    )
    return p


# --- pure tree helpers (no I/O) ----------------------------------------------


def _index(units: list[Unit]) -> tuple[dict[str, Unit], dict[str, list[str]]]:
    """Build (name → record) and (parent-name → [child names], authored order)."""
    by_name = {u["name"]: u for u in units}
    children: dict[str, list[str]] = {}
    for u in units:
        parent = u.get("parent")
        if parent:
            children.setdefault(parent, []).append(u["name"])
    return by_name, children


def _subtree_names(start: str, children: dict[str, list[str]]) -> list[str]:
    """Names in the subtree rooted at *start* (self + descendants), DFS, cycle-guarded."""
    order: list[str] = []
    seen: set[str] = set()

    def walk(name: str) -> None:
        if name in seen:
            return
        seen.add(name)
        order.append(name)
        for child in children.get(name, []):
            walk(child)

    walk(start)
    return order


def _public(u: Unit) -> Unit:
    """A clean, canonical record (drops empty optional fields except members)."""
    out: Unit = {"name": u["name"]}
    if u.get("type") is not None:
        out["type"] = u["type"]
    if u.get("parent") is not None:
        out["parent"] = u["parent"]
    out["members"] = [*(u.get("members") or [])]
    return out


def _require(by_name: dict[str, Unit], name: str) -> Unit:
    if name not in by_name:
        raise NotFoundError(f"no org unit named {name!r}")
    return by_name[name]


# --- member resolution (account store at the edge) ---------------------------


def _account_lookup(config_path: str | None) -> dict[str, dict[str, str]]:
    """One read of the account store → {name|account_id: entry} for fast resolution."""
    lookup: dict[str, dict[str, str]] = {}
    for entry in account.list(config_path=config_path):
        lookup[entry["name"]] = entry
        lookup[entry["account_id"]] = entry
    return lookup


def _resolve_token(token: str, lookup: dict[str, dict[str, str]]) -> dict[str, Any]:
    """A member token → {name, account_id, resolved}. Unknown → passthrough as id, flagged."""
    entry = lookup.get(token)
    if entry:
        return {"name": entry["name"], "account_id": entry["account_id"], "resolved": True}
    return {"name": token, "account_id": token, "resolved": False}


def _effective_tokens(
    by_name: dict[str, Unit], children: dict[str, list[str]], unit: str, *, direct: bool
) -> list[str]:
    """Member tokens for a unit: own list (direct) or subtree union (effective).

    Token-level dedup only shrinks the raw list; final per-person identity (a name
    and its raw account-id are the same person) is settled by id in ``_resolve``.
    """
    if direct:
        return dedup(by_name[unit].get("members") or [])
    tokens: list[str] = []
    for name in _subtree_names(unit, children):
        tokens.extend(by_name[name].get("members") or [])
    return dedup(tokens)


def _resolve(tokens: list[str], lookup: dict[str, dict[str, str]]) -> list[dict[str, Any]]:
    """Resolve tokens → records, de-duplicated by account-id (first-seen order)."""
    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    for token in tokens:
        record = _resolve_token(token, lookup)
        if record["account_id"] not in seen:
            seen.add(record["account_id"])
            out.append(record)
    return out


# --- public API ---------------------------------------------------------------


def list(*, type: str | None = None, config_path: str | None = None) -> list[Unit]:
    """F009: all units as rows {name, type, parent, member_count} (optional --type filter)."""
    rows = []
    for u in _read(config_path):
        if type is not None and u.get("type") != type:
            continue
        rows.append(
            {
                "name": u["name"],
                "type": u.get("type"),
                "parent": u.get("parent"),
                "member_count": len(u.get("members") or []),
            }
        )
    return rows


def show(unit: str, *, direct: bool = False, config_path: str | None = None) -> Unit:
    """F009: one unit's type/parent/children + direct (and effective) members resolved."""
    units = _read(config_path)
    by_name, children = _index(units)
    u = _require(by_name, unit)
    lookup = _account_lookup(config_path)
    result: Unit = {
        "name": u["name"],
        "type": u.get("type"),
        "parent": u.get("parent"),
        "children": children.get(unit, []),
        "members": _resolve(_effective_tokens(by_name, children, unit, direct=True), lookup),
    }
    if not direct:
        result["effective_members"] = _resolve(
            _effective_tokens(by_name, children, unit, direct=False), lookup
        )
    return result


def tree(unit: str | None = None, *, config_path: str | None = None) -> Unit:
    """F009: the org as a nested {name, type, member_count, children:[...]} structure."""
    units = _read(config_path)
    by_name, children = _index(units)

    def build(name: str) -> Unit:
        u = by_name[name]
        return {
            "name": name,
            "type": u.get("type"),
            "member_count": len(u.get("members") or []),
            "children": [build(c) for c in children.get(name, [])],
        }

    if unit is not None:
        _require(by_name, unit)
        return build(unit)
    return {"roots": [build(u["name"]) for u in units if not u.get("parent")]}


def members(
    unit: str, *, direct: bool = False, config_path: str | None = None
) -> list[dict[str, Any]]:
    """F007/F009: resolved member set (subtree union, or --direct); flags unresolved tokens."""
    units = _read(config_path)
    by_name, children = _index(units)
    _require(by_name, unit)
    tokens = _effective_tokens(by_name, children, unit, direct=direct)
    return _resolve(tokens, _account_lookup(config_path))


def member_ids(unit: str, *, config_path: str | None = None) -> list[str]:
    """Effective (subtree) member account-ids — the join point ``issue.list`` calls."""
    return [m["account_id"] for m in members(unit, direct=False, config_path=config_path)]


def create(
    unit: str,
    *,
    type: str | None = None,
    parent: str | None = None,
    members: list[str] | None = None,
    config_path: str | None = None,
) -> Unit:
    """F009: create a unit (optional type/parent/members). Parent must already exist."""
    units = _read(config_path)
    by_name, _ = _index(units)
    if unit in by_name:
        raise ConfigError(f"org unit {unit!r} already exists")
    if parent is not None and parent not in by_name:
        raise NotFoundError(f"parent org unit {parent!r} does not exist")
    record: Unit = {"name": unit}
    if type is not None:
        record["type"] = type
    if parent is not None:
        record["parent"] = parent
    if members:
        record["members"] = [*members]
    units.append(record)
    _write(config_path, units)
    return _public(record)


def move(unit: str, parent: str | None, *, config_path: str | None = None) -> Unit:
    """F009: re-parent a unit's subtree (parent=None makes it a root)."""
    units = _read(config_path)
    by_name, children = _index(units)
    u = _require(by_name, unit)
    if parent is not None:
        if parent not in by_name:
            raise NotFoundError(f"parent org unit {parent!r} does not exist")
        if parent in _subtree_names(unit, children):
            raise ConfigError(f"cannot move {unit!r} under its own descendant {parent!r}")
        u["parent"] = parent
    else:
        u.pop("parent", None)
    _write(config_path, units)
    return _public(u)


def rename(old: str, new: str, *, config_path: str | None = None) -> Unit:
    """F009: rename a unit, rewriting every child's parent pointer."""
    units = _read(config_path)
    by_name, _ = _index(units)
    u = _require(by_name, old)
    if new != old and new in by_name:
        raise ConfigError(f"org unit {new!r} already exists")
    u["name"] = new
    for other in units:
        if other.get("parent") == old:
            other["parent"] = new
    _write(config_path, units)
    return _public(u)


def add_member(unit: str, members: list[str], *, config_path: str | None = None) -> Unit:
    """F009: add member(s) to a unit's OWN list (never descendants)."""
    units = _read(config_path)
    by_name, _ = _index(units)
    u = _require(by_name, unit)
    u["members"] = dedup([*(u.get("members") or []), *members])
    _write(config_path, units)
    return _public(u)


def remove_member(unit: str, members: list[str], *, config_path: str | None = None) -> Unit:
    """F009: remove member(s) from a unit's OWN list."""
    units = _read(config_path)
    by_name, _ = _index(units)
    u = _require(by_name, unit)
    drop = set(members)
    u["members"] = [m for m in (u.get("members") or []) if m not in drop]
    _write(config_path, units)
    return _public(u)


def delete(unit: str, *, recursive: bool = False, config_path: str | None = None) -> bool:
    """F009: delete a unit; refuse to orphan children unless ``recursive``."""
    units = _read(config_path)
    by_name, children = _index(units)
    if unit not in by_name:
        return False
    kids = children.get(unit, [])
    if kids and not recursive:
        raise ConfigError(
            f"org unit {unit!r} has {len(kids)} child unit(s); use --recursive or move them first"
        )
    doomed = set(_subtree_names(unit, children)) if recursive else {unit}
    _write(config_path, [u for u in units if u["name"] not in doomed])
    return True


def validate(*, config_path: str | None = None) -> list[dict[str, Any]]:
    """F009: structural + membership checks ([] = clean). Mirrors ``rule validate``."""
    units = _read(config_path)
    by_name, children = _index(units)
    lookup = _account_lookup(config_path)
    problems: list[dict[str, Any]] = []

    def add(level: str, code: str, unit: str, message: str) -> None:
        problems.append({"level": level, "code": code, "unit": unit, "message": message})

    seen: set[str] = set()
    for u in units:
        name = u["name"]
        if name in seen:
            add("error", "duplicate_name", name, f"duplicate unit name {name!r}")
        seen.add(name)
        parent = u.get("parent")
        if parent and parent not in by_name:
            add("error", "dangling_parent", name, f"parent {parent!r} does not exist")
        if not (u.get("members") or []) and not children.get(name):
            add("warning", "empty_leaf", name, "leaf unit has no members")
        for m in u.get("members") or []:
            if m not in lookup:
                add("warning", "unresolved_member", name, f"member {m!r} not in account store")

    # cycle detection: walk each unit's parent chain
    for u in units:
        chain: set[str] = set()
        cur: str | None = u["name"]
        while cur is not None:
            if cur in chain:
                add("error", "cycle", u["name"], f"parent chain cycles at {cur!r}")
                break
            chain.add(cur)
            cur = by_name.get(cur, {}).get("parent")
    return problems
