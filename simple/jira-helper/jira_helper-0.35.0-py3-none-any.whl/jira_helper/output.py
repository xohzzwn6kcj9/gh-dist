"""Output rendering: human-readable by default, ``--json`` for scripting.

Pure and Typer-free so library callers can render without the CLI. The CLI
passes the resolved ``--json`` flag down as ``as_json``. Richer table rendering
lands with the features that need it; this is a minimal, dependable baseline.
"""

from __future__ import annotations

import json
from typing import Any

from . import color as colors


def to_json(data: Any) -> str:
    """Serialize *data* as pretty UTF-8 JSON (non-serializable values via ``str``)."""
    return json.dumps(data, indent=2, ensure_ascii=False, default=str)


def to_human(data: Any) -> str:
    """Render *data* as a plain, human-readable string."""
    if data is None:
        return ""
    if isinstance(data, str):
        return data
    if isinstance(data, dict):
        return "\n".join(f"{k}: {v}" for k, v in data.items())
    if isinstance(data, (list, tuple)):
        return _table(list(data))
    return str(data)


def _cell(value: Any) -> str:
    return "" if value is None else str(value)


def _table(rows: list) -> str:
    """Render a list of uniform dicts as an aligned table; else one item per line."""
    if not rows:
        return ""
    if not all(isinstance(r, dict) for r in rows):
        return "\n".join(_cell(r) for r in rows)
    columns = list(dict.fromkeys(key for row in rows for key in row))  # union, first-seen order
    widths = {c: max(len(c), *(len(_cell(r.get(c))) for r in rows)) for c in columns}
    lines = ["  ".join(c.ljust(widths[c]) for c in columns)]
    lines.append("  ".join("-" * widths[c] for c in columns))
    for row in rows:
        lines.append("  ".join(_cell(row.get(c)).ljust(widths[c]) for c in columns))
    return "\n".join(lines)


def _tree_label(node: dict, *, color: bool = False, depth: str = "truecolor") -> str:
    """One tree line: ``KEY — summary [status]`` plus optional annotations.

    Appends ``(via <rule>)`` when a virtual rule set the parent (``source``) and
    ``← <name>`` when the node is one of the *assigned* tickets a path tree was
    built from (``assigned_to``) — the latter marks the leaves the climb started at.

    With *color*, the KEY is tinted by issue type (Epic→pink, Story→green, …),
    ``[status]`` by status category (To Do grey / In Progress blue / Done green), and
    the dim ``(via …)`` / ``← name`` annotations grey (see :mod:`jira_helper.color`).
    A no-color render (``color=False``) is byte-identical to the plain label.
    """

    def tint(text: str, role: str | None) -> str:
        return colors.paint(text, role, enabled=color, depth=depth)

    label = tint(node.get("key") or "", colors.type_role(node.get("issue_type")) or "key")
    if node.get("summary"):
        label += f" — {node['summary']}"
    if node.get("status"):
        label += " " + tint(f"[{node['status']}]", colors.status_role(node.get("status_category")))
    source = node.get("source")
    if source and source != "native":
        label += "  " + tint(f"(via {source})", "meta")
    if node.get("assigned_to"):
        label += "  " + tint(f"← {node['assigned_to']}", "meta")
    return label


def format_tree(nodes: Any, *, color: bool = False, depth: str = "truecolor") -> str:
    """Render a nested node — or a forest of them — as an indented tree.

    Accepts either a single ``{"key", "summary", "status", "source"?, "children"?}``
    node (the ``issue tree`` shape) or a list of such nodes. A flat list of issues
    (no ``children``) renders as one ``KEY — summary [status]`` line each — the
    default ``issue list`` / ``issue roots`` view. Depth is two spaces per level; a
    malformed cycle is rendered once and not re-descended. *color*/*depth* are passed
    through to :func:`_tree_label` (off → plain, byte-identical output).
    """
    roots = nodes if isinstance(nodes, list) else [nodes]
    lines: list[str] = []
    rendered: set[int] = set()

    def walk(node: dict, indent: int) -> None:
        if id(node) in rendered:  # guard against a malformed cycle in the input
            return
        rendered.add(id(node))
        lines.append("  " * indent + _tree_label(node, color=color, depth=depth))
        for child in node.get("children", []):
            walk(child, indent + 1)

    for root in roots:
        walk(root, 0)
    return "\n".join(lines)


def _md_cell(value: Any) -> str:
    """Escape a value for a single Markdown table cell.

    Collapses any whitespace run (incl. embedded newlines) to one space and escapes
    ``|`` as ``\\|`` so a help string like the ``--color`` ``always|never|auto`` flag
    cannot break the surrounding table. ``None`` → empty cell.
    """
    if value is None:
        return ""
    return " ".join(str(value).split()).replace("|", "\\|")


def _is_variadic(param: dict) -> bool:
    """Whether a param accepts many values: a repeatable option or a variadic arg."""
    return bool(param.get("multiple")) or param.get("nargs") == -1


def _synopsis(command: dict) -> str:
    """One-line usage for a command: ``jira-helper <path> <args...> [flags]``.

    Positional arguments render as ``<name>`` (required), ``[<name>]`` (optional), or
    ``<name...>`` (variadic); a trailing ``[flags]`` is added when the command takes
    any options.
    """
    parts = ["jira-helper", command["path"]]
    for param in command.get("params", []):
        if param.get("kind") != "argument":
            continue
        name = param.get("name", "")
        if _is_variadic(param):
            parts.append(f"<{name}...>")
        elif param.get("required"):
            parts.append(f"<{name}>")
        else:
            parts.append(f"[<{name}>]")
    if any(p.get("kind") == "option" for p in command.get("params", [])):
        parts.append("[flags]")
    return " ".join(parts)


def _params_table(params: list[dict]) -> list[str]:
    """Render parameters as a Markdown table (one row per arg/flag); ``[]`` if none."""
    if not params:
        return []
    rows = [
        "| name | type | required | repeatable | default | description |",
        "| --- | --- | --- | --- | --- | --- |",
    ]
    for param in params:
        opts = param.get("opts") or [param.get("name", "")]
        name = " / ".join(f"`{opt}`" for opt in opts)
        required = "yes" if param.get("required") else "no"
        repeatable = "yes" if _is_variadic(param) else "no"
        default = param.get("default")
        # bare false/none defaults are noise; surface a real default (e.g. 'jira', 50)
        default_cell = "" if default in (None, False) else f"`{_md_cell(default)}`"
        rows.append(
            "| "
            + " | ".join(
                [
                    name,
                    _md_cell(param.get("type")),
                    required,
                    repeatable,
                    default_cell,
                    _md_cell(param.get("help")),
                ]
            )
            + " |"
        )
    return rows


def _command_section(command: dict) -> list[str]:
    """Render one leaf command: synopsis heading, help paragraphs, params table, examples."""
    out = [f"### `{_synopsis(command)}`", ""]
    help_text = (command.get("help") or "").strip()
    for para in help_text.split("\n\n"):
        flowed = " ".join(line.strip() for line in para.splitlines()).strip()
        if flowed:
            out.extend([flowed, ""])
    table = _params_table(command.get("params", []))
    if table:
        out.extend([*table, ""])
    if command.get("example"):
        out.extend(["**Example**", "", "```bash", command["example"].rstrip("\n"), "```", ""])
    if command.get("example_output"):
        out.extend(
            ["**Example output**", "", "```text", command["example_output"].rstrip("\n"), "```", ""]
        )
    return out


def to_markdown(spec: dict) -> str:
    """Render a ``spec`` dict (see :func:`jira_helper.cli.build_spec`) as a Markdown
    command reference — the public docs auto-published to gh-dist on each release via
    ``jira-helper spec --markdown``.

    Pure (plain dict in, string out) and deterministic for a given spec: the header
    carries the version only (no timestamp/host), so a same-version regeneration is
    byte-identical and the release pipeline's no-diff guard skips a redundant commit.
    Every table cell is escaped (see :func:`_md_cell`); examples are rendered in fenced
    blocks so newlines and non-ASCII (Korean) survive verbatim.
    """
    groups = spec.get("groups", [])
    commands = spec.get("commands", [])
    group_paths = [g["path"] for g in groups]
    group_path_set = set(group_paths)

    lines = [
        "# jira-helper command reference",
        "",
        f"Version {spec.get('version', '')} · generated from `jira-helper spec` — "
        "do not hand-edit (regenerated on each release).",
        "",
        "Full machine-readable form: `jira-helper --json spec`. "
        "Live per-command help: `jira-helper <command> --help`.",
        "",
    ]

    global_flags = spec.get("global_flags", [])
    if global_flags:
        lines.extend(
            [
                "## Global flags",
                "",
                "Defined once on the root command; inherited by every subcommand.",
                "",
            ]
        )
        lines.extend(_params_table(global_flags))
        lines.append("")

    by_group: dict[str, list[dict]] = {path: [] for path in group_paths}
    top_level: list[dict] = []
    for command in commands:
        head = command["path"].split(" ", 1)[0]
        (by_group[head] if head in group_path_set else top_level).append(command)

    if top_level:
        lines.extend(["## Top-level commands", ""])
        for command in top_level:
            lines.extend(_command_section(command))

    for group in groups:
        heading = f"## `{group['path']}`"
        if group.get("help"):
            heading += f" — {group['help']}"
        lines.extend([heading, ""])
        for command in by_group[group["path"]]:
            lines.extend(_command_section(command))

    return "\n".join(lines).rstrip("\n") + "\n"


def render(data: Any, *, as_json: bool = False) -> None:
    """Print *data* to stdout as JSON (``as_json=True``) or a human view."""
    print(to_json(data) if as_json else to_human(data))
