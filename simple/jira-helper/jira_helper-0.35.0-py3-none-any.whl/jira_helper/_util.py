"""Tiny internal helpers shared across modules (pure, dependency-free)."""

from __future__ import annotations

from typing import TypeVar

T = TypeVar("T")


def dedup(seq: list[T]) -> list[T]:
    """First-seen-order de-duplication of hashable items."""
    return list(dict.fromkeys(seq))
