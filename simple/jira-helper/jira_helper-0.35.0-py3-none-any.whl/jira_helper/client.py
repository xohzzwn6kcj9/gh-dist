"""Thin Atlassian Cloud REST clients (httpx, basic auth).

Auth is HTTP basic = ``base64(email:token)`` (the API token is NOT a password),
which httpx builds from the ``auth=(email, token)`` tuple. Requests return parsed
JSON; any 4xx/5xx (or a transport failure) becomes a :class:`JiraApiError` /
:class:`ConfluenceApiError` carrying Atlassian's own error messages, so callers
never see a raw traceback. :class:`JiraClient` (REST v3) and
:class:`ConfluenceClient` (F012: ``/wiki`` v1 CQL + v2 by-id) share the same site
host + credentials — only the path namespace differs.
"""

from __future__ import annotations

import logging
import os
import threading
import time
from typing import Any

import httpx

from . import config
from .errors import ConfigError, ConfluenceApiError, JiraApiError

API_V3 = "/rest/api/3"
API_WIKI = "/wiki/rest/api"  # Confluence Cloud v1 (CQL search — F012)
API_WIKI_V2 = "/wiki/api/v2"  # Confluence Cloud v2 (clean by-id surface — F012)

# F013: request-level debug trail. The Authorization header lives only on the httpx
# client (auth=self._auth) and is never in a logged string; the redaction filter on
# the log handlers is the backstop. Bodies are deliberately not logged.
_log = logging.getLogger("jira_helper.client")


def _error_message(resp: httpx.Response) -> str:
    """Build a human message from a Jira error response (``errorMessages``/``errors``)."""
    try:
        body = resp.json()
    except ValueError:
        body = None
    if isinstance(body, dict):
        msgs = list(body.get("errorMessages") or [])
        errs = body.get("errors") or {}
        if isinstance(errs, dict):
            msgs += [f"{k}: {v}" for k, v in errs.items()]
        if msgs:
            return f"HTTP {resp.status_code}: {'; '.join(msgs)}"
    return f"HTTP {resp.status_code}: {resp.reason_phrase or 'request failed'}"


def _with_hint(resp: httpx.Response) -> str:
    """Atlassian's error message + a remediation hint for the common auth failures."""
    message = _error_message(resp)
    if resp.status_code in (401, 403):
        message += (
            " — check credentials: run `jira-helper config verify` or regenerate the API token"
        )
    return message


def _resolve_config(
    config_path: str | os.PathLike[str] | None, profile: str | None
) -> dict[str, Any]:
    """Resolved creds (file + env, profile-merged) validated for ``REQUIRED_KEYS``.

    Shared by both clients' ``from_config`` — Atlassian account-ids and the API
    token are the same across Jira and Confluence, so one resolver serves both.
    """
    data = config.load(config_path=config_path)
    if profile is not None:
        profiles = data.get("profiles") or {}
        if profile not in profiles:
            raise ConfigError(f"config has no profile {profile!r}")
        data = {**data, **profiles[profile]}
    missing = [k for k in config.REQUIRED_KEYS if not data.get(k)]
    if missing:
        raise ConfigError(
            f"config missing required key(s): {', '.join(missing)} "
            "(run `jira-helper init` or set JIRA_* env vars)"
        )
    return data


def _send(
    client: httpx.Client,
    method: str,
    path: str,
    *,
    params: dict | None = None,
    json: Any = None,
    error_cls: type[JiraApiError | ConfluenceApiError],
    service: str,
) -> Any:
    """Issue a request on *client*, raising *error_cls* on any failure; return parsed JSON.

    Shared timing / debug-trail / error-mapping for both clients — they differ
    only in the bound path namespace (which *client*) and the *error_cls* /
    *service* label the failure carries. Bodies are deliberately not logged.
    """
    t0 = time.perf_counter()
    try:
        resp = client.request(method, path, params=params or None, json=json)
    except httpx.HTTPError as exc:
        _log.warning("http %s %s failed: %s", method, path, exc)
        raise error_cls(
            f"request to {service} failed: {exc} "
            "— check the network/proxy and that JIRA_BASE_URL is reachable"
        ) from exc
    ms = int((time.perf_counter() - t0) * 1000)
    if resp.status_code >= 400:
        _log.warning("http %s %s -> %s (%dms)", method, path, resp.status_code, ms)
        raise error_cls(_with_hint(resp), status=resp.status_code)
    _log.debug("http %s %s -> %s %dms %dB", method, path, resp.status_code, ms, len(resp.content))
    if not resp.content:
        return None
    return resp.json()


class JiraClient:
    """Minimal wrapper over the Jira Cloud REST API v3."""

    def __init__(
        self,
        base_url: str,
        email: str,
        api_token: str,
        *,
        timeout: float = 30.0,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.email = email
        self._auth = (email, api_token)
        self.timeout = timeout
        self._transport = transport  # injection seam for tests; None in production
        self._client: httpx.Client | None = None
        self._client_lock = threading.Lock()  # guards the lazy build (#65: parallel readers)

    @classmethod
    def from_config(
        cls,
        *,
        config_path: str | os.PathLike[str] | None = None,
        profile: str | None = None,
    ) -> JiraClient:
        """Build a client from the resolved config (file + env), honoring ``profile``."""
        data = _resolve_config(config_path, profile)
        return cls(data["base_url"], data["email"], data["api_token"])

    @property
    def http(self) -> httpx.Client:
        """Lazily-constructed httpx client bound to ``{base_url}/rest/api/3``.

        Double-checked locking so concurrent first-callers (#65's worker threads)
        can't each build a separate client and leak all but the last one. The GIL
        prevents store reordering, so no memory barrier beyond the lock is needed.
        """
        if self._client is None:
            with self._client_lock:
                if self._client is None:
                    self._client = httpx.Client(
                        base_url=self.base_url + API_V3,
                        auth=self._auth,
                        timeout=self.timeout,
                        transport=self._transport,
                    )
        return self._client

    def _request(
        self, method: str, path: str, *, params: dict | None = None, json: Any = None
    ) -> Any:
        """Issue a request, raising :class:`JiraApiError` on any error; return parsed JSON."""
        return _send(
            self.http,
            method,
            path,
            params=params,
            json=json,
            error_cls=JiraApiError,
            service="Jira",
        )

    def get(self, path: str, **params: Any) -> Any:
        """GET a Jira REST v3 resource; query params come from ``**params``."""
        return self._request("GET", path, params=params)

    def post(self, path: str, *, json: Any = None) -> Any:
        """POST to a Jira REST v3 resource with a JSON body."""
        return self._request("POST", path, json=json)

    def close(self) -> None:
        """Close the underlying httpx client, if opened."""
        if self._client is not None:
            self._client.close()
            self._client = None

    def __enter__(self) -> JiraClient:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()


class ConfluenceClient:
    """Minimal wrapper over the Confluence Cloud REST API (F012).

    Shares the Jira site host + basic auth (``email:api_token``) — Atlassian
    credentials are common across products. Only the path namespace differs:
    v1 ``/wiki/rest/api`` (``get``/``post`` — the CQL ``/search`` surface) and v2
    ``/wiki/api/v2`` (``get_v2`` — the clean by-id surface for ``page get``). The
    stored ``base_url`` stays the bare site root; each namespace gets its own
    lazily-built httpx client. Errors become a :class:`ConfluenceApiError`.
    """

    def __init__(
        self,
        base_url: str,
        email: str,
        api_token: str,
        *,
        timeout: float = 30.0,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.email = email
        self._auth = (email, api_token)
        self.timeout = timeout
        self._transport = transport  # injection seam for tests; None in production
        self._client: httpx.Client | None = None
        self._client_v2: httpx.Client | None = None
        self._client_lock = threading.Lock()  # guards both lazy builds (#65: parallel readers)

    @classmethod
    def from_config(
        cls,
        *,
        config_path: str | os.PathLike[str] | None = None,
        profile: str | None = None,
    ) -> ConfluenceClient:
        """Build a client from the resolved config (file + env), honoring ``profile``."""
        data = _resolve_config(config_path, profile)
        return cls(data["base_url"], data["email"], data["api_token"])

    def _build(self, api_path: str) -> httpx.Client:
        return httpx.Client(
            base_url=self.base_url + api_path,
            auth=self._auth,
            timeout=self.timeout,
            transport=self._transport,
        )

    @property
    def http(self) -> httpx.Client:
        """Lazily-built v1 client bound to ``{base_url}/wiki/rest/api`` (CQL search).

        Double-checked locking (see :meth:`JiraClient.http`) so concurrent first-callers
        can't each build and leak a client."""
        if self._client is None:
            with self._client_lock:
                if self._client is None:
                    self._client = self._build(API_WIKI)
        return self._client

    @property
    def http_v2(self) -> httpx.Client:
        """Lazily-built v2 client bound to ``{base_url}/wiki/api/v2`` (by-id surface)."""
        if self._client_v2 is None:
            with self._client_lock:
                if self._client_v2 is None:
                    self._client_v2 = self._build(API_WIKI_V2)
        return self._client_v2

    def get(self, path: str, **params: Any) -> Any:
        """GET a Confluence v1 resource (e.g. ``/search``); params from ``**params``."""
        return _send(
            self.http,
            "GET",
            path,
            params=params,
            error_cls=ConfluenceApiError,
            service="Confluence",
        )

    def get_v2(self, path: str, **params: Any) -> Any:
        """GET a Confluence v2 resource (e.g. ``/pages/{id}``) on the v2 namespace."""
        return _send(
            self.http_v2,
            "GET",
            path,
            params=params,
            error_cls=ConfluenceApiError,
            service="Confluence",
        )

    def post(self, path: str, *, json: Any = None) -> Any:
        """POST to a Confluence v1 resource with a JSON body."""
        return _send(
            self.http, "POST", path, json=json, error_cls=ConfluenceApiError, service="Confluence"
        )

    def close(self) -> None:
        """Close both (v1 + v2) underlying httpx clients, if opened."""
        for attr in ("_client", "_client_v2"):
            client = getattr(self, attr)
            if client is not None:
                client.close()
                setattr(self, attr, None)

    def __enter__(self) -> ConfluenceClient:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()
