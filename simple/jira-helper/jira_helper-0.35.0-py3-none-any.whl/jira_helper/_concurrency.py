"""Bounded, order-preserving parallel dispatch for the I/O edge (#65).

The live Jira read paths issue many *independent* HTTP searches/climbs strictly
serially, so a slow corporate-proxy round-trip multiplies by the call count. This
module is the single place that touches :mod:`concurrent.futures`; callers in the
pure/​parsing core stay thread-agnostic and fold results single-threaded.

Contract (relied on by the determinism + error semantics of ``issue.list``):

* **Input-ordered** — :func:`parallel_map` returns results in the SAME order as
  *items*, regardless of which task finishes first (it consumes ``submit()``
  futures in submission order, never ``as_completed``). So a caller folding the
  results sees the exact order the serial loop did, and a trailing stable sort
  stays byte-identical to serial.
* **First-exception-in-input-order** — the lowest-index task's exception is the
  one re-raised (mirrors the serial "first failure aborts"); remaining unstarted
  tasks are cancelled (``cancel_futures``) so a single auth/rate failure can't fan
  out into N retries.
* **Overhead-free small case** — empty → ``[]`` and a single item runs inline with
  no thread, so the common single-batch query is byte-identical and pays nothing.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable
from concurrent.futures import ThreadPoolExecutor
from typing import TypeVar

T = TypeVar("T")
R = TypeVar("R")

# Worker cap (#65): also the explicit rate-limit guard — at most this many Jira
# round-trips are ever in flight, and it bounds the error-path fan-out.
MAX_WORKERS = 8


def parallel_map(
    fn: Callable[[T], R], items: Iterable[T], *, max_workers: int = MAX_WORKERS
) -> list[R]:
    """Apply *fn* to each of *items* concurrently, returning results in input order.

    Threads (not async) because the work is HTTP-bound and httpx releases the GIL on
    socket I/O, so worker threads overlap real round-trips. The pool is created per
    call and scoped to a ``with`` block (joined before return), so no worker outlives
    it. See the module docstring for the ordering + error contract.
    """
    items = [*items]
    if not items:
        return []
    if len(items) == 1:  # inline: no thread for the common single-batch case
        return [fn(items[0])]
    executor = ThreadPoolExecutor(
        max_workers=min(max_workers, len(items)), thread_name_prefix="jh-io"
    )
    try:
        futures = [executor.submit(fn, item) for item in items]
        # Consume in submission order: re-raises the lowest-index failure first.
        return [future.result() for future in futures]
    finally:
        # wait=True joins running workers; cancel_futures drops unstarted ones so a
        # failure (or a normal return) never leaves a task fanning out behind us.
        executor.shutdown(wait=True, cancel_futures=True)
