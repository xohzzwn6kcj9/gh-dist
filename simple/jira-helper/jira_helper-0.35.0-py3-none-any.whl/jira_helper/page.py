"""F012 — Confluence page queries (list / get / search).

The first Confluence feature, added purely additively (no Jira command moves).
``list`` finds pages **in a space, under a folder/subtree, whose title contains a
keyword**, returning each match's title + web URI. Mirrors ``issue``: a pure core
(builds CQL, paginates, parses) with I/O pushed to the edge (``ConfluenceClient``).

**Dual ``--folder`` semantics.** ``--folder`` is treated as an opaque Confluence
content-node id. The CQL ``ancestor``/``parent`` fields are *content-type-agnostic*
— they match descendants of a **folder content-type** id and a **parent-page** id
alike — so F012's "folder content-type vs page-subtree ancestor" question is
resolved at zero request cost: default ``ancestor = <id>`` (whole subtree),
``parent = <id>`` under ``direct=True`` (immediate children only).

**API.** v1 CQL search (``GET /wiki/rest/api/search``) is the only single call that
expresses all three filters (space + folder-subtree + title-contains) server-side;
``get`` uses the v2 by-id surface. ``title ~`` is Confluence token/word-contains, so
``list`` additionally applies a client-side literal-substring post-filter.

**Live-only (F012, v0.8.0).** Like plain ``issue list``/``get``, page reads hit the
live API; the reserved ``--product confluence`` cache/sync path is deferred. The
``no_cache``/``cache_path`` kwargs are accepted for signature uniformity and ignored.
"""

from __future__ import annotations

import logging
from collections.abc import Iterator
from typing import Any
from urllib.parse import parse_qs, urlsplit

from .errors import ConfluenceApiError, JiraHelperError

_log = logging.getLogger("jira_helper.page")

Page = dict[str, Any]

# Confluence CQL search caps a page at 25 results; follow the cursor for the rest.
_PAGE_SIZE = 25
# Safety cap against a runaway search cursor (25 * 100 = 2500 pages).
_MAX_PAGES = 100


def _cql_quote(value: str) -> str:
    """Quote a value for safe inclusion in CQL (escape backslash + double-quote)."""
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _resolve_folder_clause(folder: str | None, direct: bool) -> str | None:
    """The CQL container clause for ``--folder`` (content-type-agnostic), or None.

    ``ancestor`` matches the whole subtree below a content node; ``parent`` matches
    only its direct children. Both accept a folder content-type id *or* a parent-page
    id, so a single opaque ``--folder`` id works regardless of the container's kind.

    A Confluence content id is numeric, so the id goes into CQL *unquoted* (a quoted
    string wouldn't match ``ancestor``/``parent``). We enforce that it is all-digits
    first — both as a guard against a malformed id and to close the CQL-injection
    hole a quoted clause would otherwise have (a bare ``f"{field} = {folder}"`` would
    interpolate arbitrary CQL via the library ``page.list(folder=...)`` path).
    """
    if not folder:
        return None
    if not folder.isdigit():
        raise JiraHelperError(f"--folder must be a numeric Confluence content id, got {folder!r}")
    field = "parent" if direct else "ancestor"
    return f"{field} = {folder}"


def _build_cql(space: str, folder: str | None, title_contains: str | None, direct: bool) -> str:
    """Compose the CQL for ``list``: space + (ancestor|parent) + type=page + title.

    Clauses absent for an unset option are omitted. ``space``/``title_contains`` are
    quoted (CQL-injection defense); the numeric folder id is not.
    """
    clauses = [f"space = {_cql_quote(space)}"]
    folder_clause = _resolve_folder_clause(folder, direct)
    if folder_clause:
        clauses.append(folder_clause)
    clauses.append("type = page")
    if title_contains:
        clauses.append(f"title ~ {_cql_quote(title_contains)}")
    return " AND ".join(clauses)


def _title_contains(title: str, keyword: str) -> bool:
    """Literal case-insensitive substring test (tighter than CQL's ``title ~`` tokens)."""
    return keyword.lower() in title.lower()


def _next_cursor(links: dict[str, Any]) -> str | None:
    """Extract the opaque pagination cursor from a search response's ``_links.next``.

    Pulling just the ``cursor`` query param and re-issuing ``/search`` sidesteps the
    ``_links.next`` path-prefix ambiguity (it may or may not carry the ``/wiki``
    base), which would otherwise double up against the client's bound base_url.
    """
    nxt = links.get("next")
    if not nxt:
        return None
    cursor = parse_qs(urlsplit(nxt).query).get("cursor")
    return cursor[0] if cursor else None


def _parse_page(raw: dict[str, Any], base: str) -> Page:
    """Project a CQL-search result onto the flat Page shape ``{id, title, space, uri}``.

    A search hit wraps the matched content under ``content`` and carries the relative
    webui path at top-level ``url``; the absolute URI is ``base + url`` (``base`` =
    the response's ``_links.base``). None-safe: a missing piece yields ``None``.
    """
    content = raw.get("content") or {}
    url = raw.get("url") or ""
    return {
        "id": content.get("id"),
        "title": content.get("title") or raw.get("title"),
        "space": (content.get("space") or {}).get("key"),
        "uri": (base + url) if url else None,
    }


def _parse_page_v2(raw: dict[str, Any]) -> Page:
    """Project a v2 ``/pages/{id}`` object onto the flat Page shape.

    v2 exposes ``spaceId`` (numeric) rather than a space key, and a relative
    ``_links.webui`` resolved against ``_links.base``. None-safe.
    """
    links = raw.get("_links") or {}
    webui = links.get("webui") or ""
    base = links.get("base") or ""
    return {
        "id": raw.get("id"),
        "title": raw.get("title"),
        "space": raw.get("spaceId"),
        "uri": (base + webui) if webui else None,
    }


def _search_raw(
    client: Any, cql: str, *, max_pages: int = _MAX_PAGES
) -> Iterator[tuple[dict, str]]:
    """Yield ``(raw_result, base_url)`` for a CQL search, following the ``_links.next`` cursor."""
    cursor: str | None = None
    for _ in range(max_pages):
        params: dict[str, Any] = {"cql": cql, "limit": _PAGE_SIZE, "expand": "content.space"}
        if cursor:
            params["cursor"] = cursor
        data = client.get("/search", **params) or {}  # tolerate an empty body
        links = data.get("_links") or {}
        base = links.get("base") or ""
        for result in data.get("results") or []:
            yield result, base
        cursor = _next_cursor(links)
        if not cursor:
            return  # fully drained
    # Exhausted max_pages with a cursor still pending → results are truncated. Don't
    # return a silent partial set: warn (always to the log file; to stderr under -v).
    _log.warning(
        "page search truncated at %d pages (~%d results); narrow the query "
        "(--folder / --title-contains)",
        max_pages,
        max_pages * _PAGE_SIZE,
    )


def _search(client: Any, cql: str, *, max_pages: int = _MAX_PAGES) -> list[Page]:
    """Run a CQL search, parsing each hit to the flat Page shape (to the last page)."""
    return [_parse_page(raw, base) for raw, base in _search_raw(client, cql, max_pages=max_pages)]


def list(
    *,
    space: str | None = None,
    folder: str | None = None,
    title_contains: str | None = None,
    direct: bool = False,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> list[Page]:
    """F012: pages in a space, under a folder/subtree, whose title contains a keyword.

    ``--folder`` accepts a folder content-type id OR a parent-page id (both via CQL
    ``ancestor``); ``direct=True`` narrows to immediate children (``parent``).
    ``title_contains`` maps to CQL ``title ~`` *and* a client-side literal-substring
    post-filter. Returns ``[{id, title, space, uri}]``, newest match order preserved.
    """
    if not space:
        raise JiraHelperError("page list needs --space (the Confluence space key)")

    from .client import ConfluenceClient  # local import: keep module import-light / cycle-free

    cql = _build_cql(space, folder, title_contains, direct)
    with ConfluenceClient.from_config(config_path=config_path, profile=profile) as client:
        pages = _search(client, cql)
    if title_contains:
        pages = [p for p in pages if _title_contains(p.get("title") or "", title_contains)]
    return pages


def get(
    page_id: str,
    *,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> Page | None:
    """F012: one page's ``{id, title, space, uri}`` via the v2 by-id surface.

    Returns ``None`` on a 404 (the CLI wrapper renders that as a structured
    ``not_found``); other API errors propagate as ``ConfluenceApiError``.
    """
    from .client import ConfluenceClient

    with ConfluenceClient.from_config(config_path=config_path, profile=profile) as client:
        try:
            raw = client.get_v2(f"/pages/{page_id}")
        except ConfluenceApiError as exc:
            if exc.status == 404:
                return None
            raise
    return _parse_page_v2(raw) if raw else None


def search(
    cql: str,
    *,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> list[Page]:
    """F012: raw CQL passthrough (escape hatch, mirrors ``issue list --jql``).

    The CQL is sent verbatim — no ``--space``/``--folder``/``--title-contains``
    composition and no client-side title post-filter.
    """
    from .client import ConfluenceClient

    with ConfluenceClient.from_config(config_path=config_path, profile=profile) as client:
        return _search(client, cql)
