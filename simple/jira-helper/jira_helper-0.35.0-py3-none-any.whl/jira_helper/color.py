"""Terminal color for human-readable output (the ``--color`` global flag).

Pure and dependency-free (stdlib only) so the renderer stays unit-testable and
``output.py`` keeps its "Typer-free" contract. Two independent axes, both resolved
once at startup and then threaded explicitly (no hidden global state):

* **on/off** — :func:`resolve` (``--json`` off · explicit flag · ``NO_COLOR`` ·
  config ``color: always|never|auto`` · auto = TTY).
* **depth** — :func:`color_depth` picks ``truecolor`` (24-bit, e.g. iTerm2) /
  ``256`` / ``16`` from ``COLORTERM`` / ``TERM``.

Hex is the source of truth and tracks the Atlassian / Jira Cloud palette; tweak a
hex in :data:`_PALETTE` to retune. Truecolor emits the exact hex, ``256`` down-
samples it to the xterm 6×6×6 cube, ``16`` falls back to the per-role ANSI name
(theme-aware). The KEY is colored by issue type, ``[status]`` by status category.
"""

from __future__ import annotations

# role -> (hex, ansi16 SGR code). hex drives truecolor + the 256 down-sample;
# ansi16 is the portable per-role fallback. Colors follow Jira Cloud's palette.
_PALETTE: dict[str, tuple[str, str]] = {
    "status:todo": ("8993A4", "90"),  # To Do (statusCategory new) — neutral grey
    "status:inprogress": ("2684FF", "34"),  # In Progress (indeterminate) — blue
    "status:done": ("36B37E", "32"),  # Done (done) — green
    "type:epic": ("CD519D", "35"),  # Epic — pink/magenta
    "type:story": ("36B37E", "32"),  # Story — green
    "type:task": ("4C9AFF", "34"),  # Task — blue
    "type:bug": ("FF5630", "31"),  # Bug — red
    "type:subtask": ("4BADE8", "36"),  # Sub-task — cyan
    "key": ("4BADE8", "36"),  # default issue-key / identifier — cyan
    "meta": ("6B778C", "90;2"),  # dim annotations: (via rule), ← name
}

_RESET = "\x1b[0m"

# Jira statusCategory.key (language-independent) -> palette role.
_STATUS_ROLE = {
    "new": "status:todo",
    "indeterminate": "status:inprogress",
    "done": "status:done",
}

# issue-type display name (lowercased) -> palette role; English + common Korean.
_TYPE_ROLE = {
    "epic": "type:epic",
    "에픽": "type:epic",
    "story": "type:story",
    "스토리": "type:story",
    "task": "type:task",
    "작업": "type:task",
    "태스크": "type:task",
    "bug": "type:bug",
    "버그": "type:bug",
    "결함": "type:bug",
    "sub-task": "type:subtask",
    "subtask": "type:subtask",
    "하위 작업": "type:subtask",
    "하위작업": "type:subtask",
    "서브태스크": "type:subtask",
}


def status_role(category_key: str | None) -> str | None:
    """Palette role for a Jira ``statusCategory.key`` (``new``/``indeterminate``/``done``)."""
    if not category_key:
        return None
    return _STATUS_ROLE.get(category_key.strip().lower())


def type_role(issue_type: str | None) -> str | None:
    """Palette role for an issue-type name (English or Korean); ``None`` if unknown."""
    if not issue_type:
        return None
    return _TYPE_ROLE.get(issue_type.strip().lower())


def color_depth(*, colorterm: str | None, term: str | None) -> str:
    """Pick the emission tier from env strings: ``truecolor`` / ``256`` / ``16``."""
    if (colorterm or "").strip().lower() in ("truecolor", "24bit"):
        return "truecolor"
    if "256color" in (term or "").lower():
        return "256"
    return "16"


def resolve(
    flag: bool | None,
    *,
    as_json: bool,
    config_default: str | None,
    isatty: bool,
    no_color: bool,
) -> bool:
    """Resolve the on/off decision (first decisive wins).

    ``--json`` → off (color would corrupt machine output); else an explicit
    ``--color``/``--no-color`` (*flag*) wins; else ``NO_COLOR`` forces off; else the
    config default (``always``/``never``/``auto``); else auto = *isatty*.
    """
    if as_json:
        return False
    if flag is not None:
        return flag
    if no_color:
        return False
    default = (config_default or "auto").strip().lower()
    if default == "always":
        return True
    if default == "never":
        return False
    return bool(isatty)  # "auto" (or anything unrecognized)


def _hex_rgb(hexstr: str) -> tuple[int, int, int]:
    """Parse a ``RRGGBB`` hex string into ``(r, g, b)`` 0–255 channels."""
    r, g, b = (int(hexstr[i : i + 2], 16) for i in (0, 2, 4))
    return r, g, b


def _hex_to_256(hexstr: str) -> int:
    """Down-sample a ``RRGGBB`` hex to the nearest xterm-256 6×6×6 color-cube index."""
    r, g, b = _hex_rgb(hexstr)

    def q(v: int) -> int:  # map a channel to one of the cube's 6 levels
        return 0 if v < 48 else 1 if v < 115 else (v - 35) // 40

    return 16 + 36 * q(r) + 6 * q(g) + q(b)


def _sgr(role: str, depth: str) -> str | None:
    """The SGR parameter string for *role* at *depth*, or ``None`` if role is unknown."""
    spec = _PALETTE.get(role)
    if spec is None:
        return None
    hexstr, ansi16 = spec
    if depth == "truecolor":
        r, g, b = _hex_rgb(hexstr)
        return f"38;2;{r};{g};{b}"
    if depth == "256":
        return f"38;5;{_hex_to_256(hexstr)}"
    return ansi16


def paint(text: str, role: str | None, *, enabled: bool, depth: str = "truecolor") -> str:
    """Wrap *text* in *role*'s color when *enabled*; return it unchanged otherwise.

    A falsy *text*, a ``None``/unknown *role*, or ``enabled=False`` all pass the
    text through verbatim — so a no-color render is byte-identical to the plain one.
    """
    if not enabled or not text or role is None:
        return text
    sgr = _sgr(role, depth)
    if sgr is None:
        return text
    return f"\x1b[{sgr}m{text}{_RESET}"
