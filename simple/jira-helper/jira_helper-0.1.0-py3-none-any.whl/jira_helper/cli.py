"""jira-helper CLI — Typer app: global flags + noun groups + top-level commands.

A thin wrapper layer: parse args, stash the resolved global options on the Typer
context, dispatch to the library, render. No behavior lives here (the
library-first contract). Invocation grammar::

    jira-helper [GLOBAL FLAGS] <noun> <verb> [args] [flags]

Global flags are defined once on the root callback and therefore precede the
noun (e.g. ``jira-helper --json issue list --assignee alice``).
"""

from pathlib import Path
from typing import Annotated, Any

import typer

from . import __version__, output
from . import config as config_lib
from .commands import _common, account, cache, config, issue, rule, sync, team

app = typer.Typer(
    name="jira-helper",
    no_args_is_help=True,
    add_completion=False,
    help="Admin toolkit for Atlassian Cloud (Jira now, Confluence later). "
    "Resolve people↔account-ids, manage virtual teams, query/cache tickets.",
)

app.add_typer(config.app, name="config")
app.add_typer(account.app, name="account")
app.add_typer(issue.app, name="issue")
app.add_typer(team.app, name="team")
app.add_typer(rule.app, name="rule")
app.add_typer(cache.app, name="cache")
app.add_typer(sync.app, name="sync")


@app.callback()
def main(
    ctx: typer.Context,
    json_out: Annotated[bool, typer.Option("--json", help="Machine-readable JSON output.")] = False,
    config_path: Annotated[
        Path | None, typer.Option("--config", help="Override config file location.")
    ] = None,
    profile: Annotated[
        str | None, typer.Option("--profile", help="Named credential profile / Atlassian site.")
    ] = None,
    cache_path: Annotated[
        Path | None, typer.Option("--cache", help="Override cache file location.")
    ] = None,
    no_cache: Annotated[
        bool, typer.Option("--no-cache", help="Bypass the cache; force a live API call.")
    ] = False,
    quiet: Annotated[bool, typer.Option("--quiet", "-q", help="Quieter logs.")] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v", help="More verbose logs.")] = False,
    color: Annotated[
        bool | None,
        typer.Option("--color/--no-color", help="Colorize output (auto-off when piped)."),
    ] = None,
    yes: Annotated[
        bool, typer.Option("--yes", "-y", help="Skip confirmation prompts on destructive ops.")
    ] = False,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Show what would happen; don't apply.")
    ] = False,
) -> None:
    """Global flags shared by every command (stashed on the context)."""
    ctx.obj = _common.GlobalOptions(
        json=json_out,
        config=config_path,
        profile=profile,
        cache=cache_path,
        no_cache=no_cache,
        quiet=quiet,
        verbose=verbose,
        color=color,
        yes=yes,
        dry_run=dry_run,
    )


@app.command()
def version() -> None:
    """Print version / build info.

    Example:
        jira-helper version
    """
    typer.echo(__version__)


@app.command()
def init(ctx: typer.Context) -> None:
    """First-run onboarding wizard (alias of 'config init'). Feature: F001.

    Example:
        jira-helper init
    """
    _common.run(ctx, lambda: config_lib.init(**_common.opt_kwargs(ctx, ("config_path",))))


@app.command()
def doctor(ctx: typer.Context) -> None:
    """Read-only health check: config valid? creds ok? cache fresh? Feature: F001.

    Example:
        jira-helper doctor
    """
    _common.run(ctx, lambda: _common.stub("doctor"))


@app.command()
def spec(ctx: typer.Context) -> None:
    """Emit the entire command tree (commands, args, flags, types) for LLM/MCP ingest.

    Feature: F011. Use '--json' for the full structured tree; without it, a
    compact list of command paths.

    Example:
        jira-helper --json spec
    """
    opts = _common.get_opts(ctx)
    data = build_spec()
    if opts.json:
        output.render(data, as_json=True)
    else:
        typer.echo("\n".join(cmd["path"] for cmd in data["commands"]))


# --- spec introspection (F011) -------------------------------------------------


def build_spec(typer_app: typer.Typer | None = None) -> dict:
    """Introspect the (Typer-vendored) Click command tree into a structured dict.

    Duck-typed (``.commands`` / ``param_type_name``) so it stays robust across
    Typer versions, which vendor Click and do not expose it as a top-level import.
    """
    command = typer.main.get_command(typer_app or app)
    return {
        "name": "jira-helper",
        "version": __version__,
        "global_flags": [_describe_param(p) for p in command.params if _keep_param(p)],
        "commands": _walk(command, []),
    }


def _walk(command: Any, prefix: list[str]) -> list[dict]:
    subcommands = getattr(command, "commands", None)
    if subcommands:
        out: list[dict] = []
        for name in sorted(subcommands):
            out.extend(_walk(subcommands[name], [*prefix, name]))
        return out
    description, example = _split_example((command.help or command.short_help or "").strip())
    return [
        {
            "path": " ".join(prefix),
            "help": description,
            "example": example,
            "params": [_describe_param(p) for p in command.params if _keep_param(p)],
        }
    ]


def _split_example(text: str) -> tuple[str, str | None]:
    """Split a command's help into (description, first 'Example' block)."""
    marker = text.find("Example")
    if marker == -1:
        return text, None
    return text[:marker].strip(), text[marker:].strip()


def _keep_param(param: Any) -> bool:
    return getattr(param, "name", None) not in (None, "help")


def _describe_param(param: Any) -> dict:
    default = param.default
    if callable(default):
        default = None
    nargs = getattr(param, "nargs", 1)
    return {
        "name": param.name,
        "kind": getattr(param, "param_type_name", "parameter"),
        # both halves of a toggle (--color / --no-color) so the spec is complete
        "opts": [*getattr(param, "opts", []), *getattr(param, "secondary_opts", [])],
        "type": getattr(param.type, "name", str(param.type)),
        "required": bool(param.required),
        # variadic positional args carry nargs == -1 (Click never sets .multiple on them)
        "multiple": bool(getattr(param, "multiple", False)) or nargs == -1,
        "nargs": nargs,
        "default": default,
        "help": getattr(param, "help", None),
    }
