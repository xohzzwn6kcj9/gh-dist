"""F002/F003 — name ↔ Atlassian account-id store.

An external YAML file (beside the config) is the SOLE store; the CLI reads and
writes it via ``list`` / ``get`` / ``add`` / ``remove``. ``search`` is an
OUTPUT-ONLY live lookup (profile link + candidate ids) that writes nothing — the
caller reads its output, then uses ``add`` to record a choice.

Only ``path`` is wired in this scaffold; the rest are stubs.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from . import config

STORE_FILENAME = "accounts.yaml"


def path(*, config_path: str | None = None) -> Path:
    """Resolve the account-store file location (beside the config)."""
    return config.config_dir(config_path) / STORE_FILENAME


def list(*, config_path: str | None = None) -> list[dict[str, str]]:
    """F003: list all name↔account-id mappings from the store."""
    raise NotImplementedError("jira_helper.account.list: not yet implemented (scaffold)")


def get(name_or_id: str, *, config_path: str | None = None) -> dict[str, str] | None:
    """F002/F003: resolve a name or account-id from the store (either direction)."""
    raise NotImplementedError("jira_helper.account.get: not yet implemented (scaffold)")


def add(name: str, account_id: str, *, config_path: str | None = None) -> dict[str, str]:
    """F003: write/update a name→account-id mapping in the store."""
    raise NotImplementedError("jira_helper.account.add: not yet implemented (scaffold)")


def remove(name_or_id: str, *, config_path: str | None = None) -> bool:
    """F003: delete a mapping from the store."""
    raise NotImplementedError("jira_helper.account.remove: not yet implemented (scaffold)")


def search(
    name: str, *, profile: str | None = None, config_path: str | None = None
) -> list[dict[str, Any]]:
    """F002: OUTPUT-ONLY live user lookup → profile link + candidate ids. Writes nothing."""
    raise NotImplementedError("jira_helper.account.search: not yet implemented (scaffold)")
