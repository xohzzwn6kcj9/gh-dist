"""Output rendering: human-readable by default, ``--json`` for scripting.

Pure and Typer-free so library callers can render without the CLI. The CLI
passes the resolved ``--json`` flag down as ``as_json``. Richer table rendering
lands with the features that need it; this is a minimal, dependable baseline.
"""

from __future__ import annotations

import json
from typing import Any


def to_json(data: Any) -> str:
    """Serialize *data* as pretty UTF-8 JSON (non-serializable values via ``str``)."""
    return json.dumps(data, indent=2, ensure_ascii=False, default=str)


def to_human(data: Any) -> str:
    """Render *data* as a plain, human-readable string."""
    if data is None:
        return ""
    if isinstance(data, str):
        return data
    if isinstance(data, dict):
        return "\n".join(f"{k}: {v}" for k, v in data.items())
    if isinstance(data, (list, tuple)):
        return "\n".join(_row(item) for item in data)
    return str(data)


def _row(item: Any) -> str:
    if isinstance(item, dict):
        return "  ".join(f"{k}={v}" for k, v in item.items())
    return str(item)


def render(data: Any, *, as_json: bool = False) -> None:
    """Print *data* to stdout as JSON (``as_json=True``) or a human view."""
    print(to_json(data) if as_json else to_human(data))
