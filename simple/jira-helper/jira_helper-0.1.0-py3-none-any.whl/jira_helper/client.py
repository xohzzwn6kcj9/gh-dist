"""Thin Jira Cloud REST v3 client (httpx, basic auth).

Auth is HTTP basic = ``base64(email:token)`` (the API token is NOT a password),
which httpx builds from the ``auth=(email, token)`` tuple. Only construction and
auth wiring exist in this scaffold; request methods are stubs. A
``ConfluenceClient`` will join later (F012) sharing the same auth.
"""

from __future__ import annotations

from typing import Any

import httpx

API_V3 = "/rest/api/3"


class JiraClient:
    """Minimal wrapper over the Jira Cloud REST API v3."""

    def __init__(
        self,
        base_url: str,
        email: str,
        api_token: str,
        *,
        timeout: float = 30.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.email = email
        self._auth = (email, api_token)
        self.timeout = timeout
        self._client: httpx.Client | None = None

    @classmethod
    def from_config(
        cls,
        *,
        config_path: str | None = None,
        profile: str | None = None,
    ) -> JiraClient:
        """Build a client from the stored/loaded config (stub)."""
        raise NotImplementedError(
            "jira_helper.client.JiraClient.from_config: not yet implemented (scaffold)"
        )

    @property
    def http(self) -> httpx.Client:
        """Lazily-constructed httpx client bound to ``{base_url}/rest/api/3``."""
        if self._client is None:
            self._client = httpx.Client(
                base_url=self.base_url + API_V3,
                auth=self._auth,
                timeout=self.timeout,
            )
        return self._client

    def get(self, path: str, **params: Any) -> Any:
        """GET a Jira REST v3 resource (stub)."""
        raise NotImplementedError(
            "jira_helper.client.JiraClient.get: not yet implemented (scaffold)"
        )

    def close(self) -> None:
        """Close the underlying httpx client, if opened."""
        if self._client is not None:
            self._client.close()
            self._client = None
