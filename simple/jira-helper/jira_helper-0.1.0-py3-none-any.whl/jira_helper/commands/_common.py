"""Shared CLI glue: global options + the stub runner + kwarg plumbing.

Lives in the commands package (not ``cli.py``) so the root app and every noun
command module can import it without an import cycle.
"""

import json as _json
from dataclasses import dataclass
from pathlib import Path

import typer

from .. import output


@dataclass
class GlobalOptions:
    """Resolved global flags, stashed on the Typer context (``ctx.obj``)."""

    json: bool = False
    config: Path | None = None
    profile: str | None = None
    cache: Path | None = None
    no_cache: bool = False
    quiet: bool = False
    verbose: bool = False
    color: bool | None = None
    yes: bool = False
    dry_run: bool = False


def get_opts(ctx: typer.Context) -> GlobalOptions:
    """Return the GlobalOptions on *ctx* (defaults if the callback didn't run)."""
    return ctx.obj if isinstance(ctx.obj, GlobalOptions) else GlobalOptions()


def as_str(value: Path | None) -> str | None:
    """Path → str for passing override paths down to the library layer."""
    return str(value) if value is not None else None


def opt_kwargs(ctx: typer.Context, names: tuple[str, ...]) -> dict:
    """Select global options to forward to a library call as explicit kwargs.

    Globals never become hidden state: each maps to a named keyword argument, and
    a command forwards only the names its library function actually accepts.
    """
    o = get_opts(ctx)
    available = {
        "profile": o.profile,
        "no_cache": o.no_cache,
        "cache_path": as_str(o.cache),
        "config_path": as_str(o.config),
    }
    return {name: available[name] for name in names}


def stub(name: str):
    """Raise the standard scaffold 'not implemented' error for *name*."""
    raise NotImplementedError(f"jira_helper {name}: not yet implemented (scaffold)")


def run(ctx: typer.Context, call) -> None:
    """Invoke a library thunk and render its result, or a structured stub error.

    Until features land, library calls raise NotImplementedError; we render that
    as an actionable 'not implemented' error (F011) and exit 2 — never a traceback.
    """
    opts = get_opts(ctx)
    try:
        result = call()
    except NotImplementedError as exc:
        message = str(exc) or "not implemented"
        # errors always go to stderr regardless of --json (render-only contract):
        # stdout stays reserved for successful machine output.
        if opts.json:
            typer.echo(_json.dumps({"error": "not_implemented", "message": message}), err=True)
        else:
            typer.secho(f"not implemented: {message}", fg=typer.colors.YELLOW, err=True)
        raise typer.Exit(code=2) from exc
    output.render(result, as_json=opts.json)
