"""F004–F008 — issue queries (list / roots / tree / get).

Reads go through the local SQLite cache by default; ``no_cache=True`` forces a
live API call. ``--json`` is a render concern owned by the CLI, not here. People
filters accept names or account-ids (names resolved via the account store, F003).
All bodies are stubs in this scaffold.
"""

from __future__ import annotations

from typing import Any

Issue = dict[str, Any]


def list(
    *,
    assignee: list[str] | None = None,
    team: list[str] | None = None,
    jql: str | None = None,
    created_from: str | None = None,
    created_to: str | None = None,
    assigned_from: str | None = None,
    assigned_to: str | None = None,
    roots: bool = False,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> list[Issue]:
    """F004/F005/F007/F008: list issues by assignee(s) / team(s) / date-range / raw JQL.

    ``roots=True`` collapses the result set to its root issues (F006 modifier).
    """
    raise NotImplementedError("jira_helper.issue.list: not yet implemented (scaffold)")


def roots(
    *,
    assignee: list[str] | None = None,
    team: list[str] | None = None,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> list[Issue]:
    """F006: the root issues of an assignee/team set (walk effective parents to the top)."""
    raise NotImplementedError("jira_helper.issue.roots: not yet implemented (scaffold)")


def tree(
    key: str,
    *,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> dict[str, Any]:
    """F006: the parent→child hierarchy for KEY (native parents + virtual rules)."""
    raise NotImplementedError("jira_helper.issue.tree: not yet implemented (scaffold)")


def get(
    key: str,
    *,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> Issue:
    """F004: one issue's fields."""
    raise NotImplementedError("jira_helper.issue.get: not yet implemented (scaffold)")
