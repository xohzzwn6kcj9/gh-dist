"""F001 — configuration: onboarding, load/save, and path resolution.

The config holds the Jira Cloud connection essentials (base URL, account email,
API token, ...). It lives at ``$JIRA_HELPER_CONFIG`` if set, otherwise under the
XDG config dir (``~/.config/jira-helper/``); the cache (``cache.db``) and the
account / team / rule stores sit beside it. Secrets are protected by file
permissions (``chmod 600``), not an OS keychain. Format is YAML (JSON accepted).

Only path resolution is wired in this scaffold; everything else is a stub.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

APP_DIRNAME = "jira-helper"
CONFIG_FILENAME = "config.yaml"  # YAML preferred (F003); JSON is an accepted alternative.


def _xdg_config_home() -> Path:
    return Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config")


def path(config_path: str | os.PathLike[str] | None = None) -> Path:
    """Resolve the config file location.

    Precedence: explicit ``config_path`` (the ``--config`` flag) →
    ``$JIRA_HELPER_CONFIG`` → ``$XDG_CONFIG_HOME/jira-helper/config.yaml``.
    """
    if config_path is not None:
        return Path(config_path).expanduser()
    env = os.environ.get("JIRA_HELPER_CONFIG")
    if env:
        return Path(env).expanduser()
    return _xdg_config_home() / APP_DIRNAME / CONFIG_FILENAME


def config_dir(config_path: str | os.PathLike[str] | None = None) -> Path:
    """Directory holding the config file (and, beside it, cache + stores)."""
    return path(config_path).parent


def init(*, config_path: str | os.PathLike[str] | None = None, force: bool = False) -> Path:
    """F001: interactive first-run onboarding → write config, chmod 600."""
    raise NotImplementedError("jira_helper.config.init: not yet implemented (scaffold)")


def load(*, config_path: str | os.PathLike[str] | None = None) -> dict[str, Any]:
    """Load and return the resolved config as a dict."""
    raise NotImplementedError("jira_helper.config.load: not yet implemented (scaffold)")


def save(data: dict[str, Any], *, config_path: str | os.PathLike[str] | None = None) -> Path:
    """Persist *data* to the config file and re-assert chmod 600."""
    raise NotImplementedError("jira_helper.config.save: not yet implemented (scaffold)")


def get(
    key: str, *, config_path: str | os.PathLike[str] | None = None, reveal: bool = False
) -> Any:
    """Read one config field (token-like values masked unless ``reveal``)."""
    raise NotImplementedError("jira_helper.config.get: not yet implemented (scaffold)")


def set(key: str, value: Any, *, config_path: str | os.PathLike[str] | None = None) -> Path:
    """Set one config field non-interactively (re-chmod 600 on write)."""
    raise NotImplementedError("jira_helper.config.set: not yet implemented (scaffold)")


def verify(
    *,
    config_path: str | os.PathLike[str] | None = None,
    profile: str | None = None,
) -> dict[str, Any]:
    """Live auth ping + re-assert chmod 600; return a health summary."""
    raise NotImplementedError("jira_helper.config.verify: not yet implemented (scaffold)")
