"""Local SQLite cache (``cache.db``, beside the config; ``--cache`` overrides).

Stdlib ``sqlite3`` in WAL mode so a background ``sync`` can write while reads
run. Tree traversal (F006 root-finding / subtrees) uses ``WITH RECURSIVE`` over
``effective_parent``; incremental sync (F010) uses UPSERT. The schema, the
WAL/foreign-key connection, ``init_db`` (with a forward-only migration ladder),
and the inspection verbs (``status``/``get``/``export``/``clear`` +
``is_populated`` cutover gate) live here. Inspect via ``cache get`` /
``cache export --json``.
"""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

from . import config

# v1: issue + issue_link. v2 (F010): + `source` column (effective-parent provenance,
# so cache-backed `tree` matches live output) + `meta` table (per-product sync state).
SCHEMA_VERSION = 2

_SCHEMA = """
CREATE TABLE IF NOT EXISTS issue (
    key              TEXT PRIMARY KEY,
    product          TEXT NOT NULL DEFAULT 'jira',
    project          TEXT,
    issue_type       TEXT,
    summary          TEXT,
    status           TEXT,
    assignee_id      TEXT,
    native_parent    TEXT,
    effective_parent TEXT,
    source           TEXT,
    created          TEXT,
    updated          TEXT,
    raw              TEXT,
    synced_at        TEXT
);
CREATE INDEX IF NOT EXISTS idx_assignee ON issue(assignee_id);
CREATE INDEX IF NOT EXISTS idx_parent   ON issue(effective_parent);
CREATE TABLE IF NOT EXISTS issue_link (
    src  TEXT NOT NULL,
    dst  TEXT NOT NULL,
    type TEXT NOT NULL,
    PRIMARY KEY (src, dst, type)
);
CREATE TABLE IF NOT EXISTS meta (
    product           TEXT PRIMARY KEY,
    last_sync_at      TEXT,
    watermark         TEXT,
    last_error        TEXT,
    rules_fingerprint TEXT
);
"""


def path(*, cache_path: str | None = None, config_path: str | None = None) -> Path:
    """Resolve the cache.db location (``--cache`` override → beside the config)."""
    if cache_path is not None:
        return Path(cache_path).expanduser()
    return config.config_dir(config_path) / "cache.db"


def connect(*, cache_path: str | None = None, config_path: str | None = None) -> sqlite3.Connection:
    """Open the cache in WAL mode (creating the parent dir if needed)."""
    db = path(cache_path=cache_path, config_path=config_path)
    db.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def _migrate(conn: sqlite3.Connection, from_version: int) -> None:
    """Forward-only schema migration ladder (each step idempotent on its own).

    ``_SCHEMA`` (all ``IF NOT EXISTS``) has already run, so fresh tables carry the
    latest shape and ``meta`` exists. The ladder only repairs *pre-existing* tables
    that the create-if-not-exists left untouched.
    """
    if from_version < 2:
        # v1's `issue` table predates the `source` column; CREATE IF NOT EXISTS won't
        # add it, so backfill it here (SQLite has no ADD COLUMN IF NOT EXISTS).
        cols = {row[1] for row in conn.execute("PRAGMA table_info(issue)")}
        if "source" not in cols:
            conn.execute("ALTER TABLE issue ADD COLUMN source TEXT")


def init_db(*, cache_path: str | None = None, config_path: str | None = None) -> Path:
    """Create/upgrade the schema (idempotent) and stamp the version; return the db path."""
    db = path(cache_path=cache_path, config_path=config_path)
    conn = connect(cache_path=cache_path, config_path=config_path)
    try:
        current = conn.execute("PRAGMA user_version").fetchone()[0]
        conn.executescript(_SCHEMA)
        _migrate(conn, current)
        conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
        conn.commit()
    finally:
        conn.close()
    return db


def read_meta(conn: sqlite3.Connection, product: str) -> dict[str, Any]:
    """The per-product sync-state row as a dict (``{}`` if none yet). Shared with ``sync``."""
    row = conn.execute("SELECT * FROM meta WHERE product = ?", (product,)).fetchone()
    return dict(row) if row else {}


def is_populated(
    *, product: str = "jira", cache_path: str | None = None, config_path: str | None = None
) -> bool:
    """True once at least one issue row exists for *product* (the cutover gate).

    Keyed on issue rows, not the ``meta`` row, so a never-synced cache (and every
    live-mock test) transparently falls back to the live read path.
    """
    db = path(cache_path=cache_path, config_path=config_path)
    if not db.exists():
        return False
    conn = connect(cache_path=cache_path, config_path=config_path)
    try:
        row = conn.execute("SELECT 1 FROM issue WHERE product = ? LIMIT 1", (product,)).fetchone()
    finally:
        conn.close()
    return row is not None


# --- traversal primitives (recursive CTE over effective_parent; F006 cutover) --
#
# At sync time ``effective_parent`` already folds manual edges + conditional rules
# + native parent into one edge, so these walks follow that single column — no rule
# engine needed at read time. Each guards cycles with a path string + a depth cap.


def keys_by_assignee(
    conn: sqlite3.Connection, ids: list[str], *, product: str = "jira"
) -> list[str]:
    """Cached issue keys assigned to any of *ids* (the seed set for cache-backed roots)."""
    if not ids:
        return []
    rows = conn.execute(
        "SELECT key FROM issue WHERE product = ? "
        "AND assignee_id IN (SELECT value FROM json_each(?))",
        (product, json.dumps(ids)),
    )
    return [r[0] for r in rows]


def climb_roots(conn: sqlite3.Connection, seed_keys: list[str]) -> list[str]:
    """Distinct effective roots of *seed_keys* (climb to the furthest *present* node).

    A dangling ``effective_parent`` (parent not cached) stops the climb at the last
    present node — the live ``_climb_to_root`` 404-stops-here equivalent.
    """
    if not seed_keys:
        return []
    rows = conn.execute(
        """
        WITH RECURSIVE climb(seed, cur, depth, path) AS (
            SELECT key, key, 0, '/' || key || '/'
              FROM issue
             WHERE key IN (SELECT value FROM json_each(?))
          UNION ALL
            SELECT c.seed, parent.key, c.depth + 1, c.path || parent.key || '/'
              FROM climb c
              JOIN issue child  ON child.key = c.cur
              JOIN issue parent ON parent.key = child.effective_parent
             WHERE child.effective_parent IS NOT NULL
               AND instr(c.path, '/' || parent.key || '/') = 0
               AND c.depth < 1000
        )
        SELECT DISTINCT c.cur
          FROM climb c
         WHERE c.depth = (SELECT MAX(c2.depth) FROM climb c2 WHERE c2.seed = c.seed)
        """,
        (json.dumps(seed_keys),),
    )
    return [r[0] for r in rows]


def climb_edges(conn: sqlite3.Connection, seed_keys: list[str]) -> list[sqlite3.Row]:
    """Every node on any *seed_keys* → root climb path (seeds + ancestors), de-duped.

    The inverse of :func:`subtree_rows`: it walks *up* via ``effective_parent`` and
    keeps the whole chain, so a caller can rebuild the root→…→seed paths (the
    ``issue list --roots --verbose`` tree) rather than a root's full subtree. A node
    shared by several seeds' chains appears once; each row carries ``effective_parent``
    so the caller wires parent→child and treats a node whose parent is null/absent as
    a root. A dangling parent simply stops that chain (404-stops-here equivalent).
    """
    if not seed_keys:
        return []
    return conn.execute(
        """
        WITH RECURSIVE climb(cur, depth, path) AS (
            SELECT key, 0, '/' || key || '/'
              FROM issue
             WHERE key IN (SELECT value FROM json_each(?))
          UNION ALL
            SELECT parent.key, c.depth + 1, c.path || parent.key || '/'
              FROM climb c
              JOIN issue child  ON child.key = c.cur
              JOIN issue parent ON parent.key = child.effective_parent
             WHERE child.effective_parent IS NOT NULL
               AND instr(c.path, '/' || parent.key || '/') = 0
               AND c.depth < 1000
        )
        SELECT i.key, i.effective_parent, i.summary, i.status, i.issue_type, i.raw
          FROM issue i
         WHERE i.key IN (SELECT DISTINCT cur FROM climb)
        """,
        (json.dumps(seed_keys),),
    ).fetchall()


def subtree_rows(conn: sqlite3.Connection, root_key: str) -> list[sqlite3.Row]:
    """Every descendant of *root_key* (inclusive) via ``effective_parent``, depth-ordered."""
    return conn.execute(
        """
        WITH RECURSIVE descend(key, depth, path) AS (
            SELECT key, 0, '/' || key || '/' FROM issue WHERE key = ?
          UNION ALL
            SELECT i.key, d.depth + 1, d.path || i.key || '/'
              FROM descend d
              JOIN issue i ON i.effective_parent = d.key
             WHERE instr(d.path, '/' || i.key || '/') = 0
               AND d.depth < 1000
        )
        SELECT i.key, i.summary, i.status, i.issue_type, i.effective_parent, i.source, d.depth
          FROM descend d JOIN issue i ON i.key = d.key
         ORDER BY d.depth, i.created
        """,
        (root_key,),
    ).fetchall()


def engine_node(
    conn: sqlite3.Connection, *, key: str, project: Any, issue_type: Any, native_parent: Any
) -> dict[str, Any]:
    """Assemble a rule-engine node from cached columns + ``issue_link``.

    ``linked_keys`` unions both link directions (matching the live ``_linked_keys``).
    The single source for the cache→engine node shape, shared by ``rule.resolve`` and
    ``sync``'s rules-fingerprint recompute so the two never drift.
    """
    linked = [r[0] for r in conn.execute("SELECT dst FROM issue_link WHERE src = ?", (key,))]
    linked += [r[0] for r in conn.execute("SELECT src FROM issue_link WHERE dst = ?", (key,))]
    return {
        "key": key,
        "project": project,
        "issue_type": issue_type,
        "parent": native_parent,
        "linked_keys": [*dict.fromkeys(linked)],
    }


def status(*, cache_path: str | None = None, config_path: str | None = None) -> dict[str, Any]:
    """Rows (per product), last sync, on-disk size, schema version."""
    db = path(cache_path=cache_path, config_path=config_path)
    init_db(cache_path=cache_path, config_path=config_path)
    conn = connect(cache_path=cache_path, config_path=config_path)
    try:
        per_product = {
            r["product"]: r["n"]
            for r in conn.execute("SELECT product, COUNT(*) AS n FROM issue GROUP BY product")
        }
        meta = {
            r["product"]: {"last_sync_at": r["last_sync_at"], "watermark": r["watermark"]}
            for r in conn.execute("SELECT product, last_sync_at, watermark FROM meta")
        }
        version = conn.execute("PRAGMA user_version").fetchone()[0]
    finally:
        conn.close()
    size = sum(
        sib.stat().st_size
        for sib in (db, db.with_name(db.name + "-wal"), db.with_name(db.name + "-shm"))
        if sib.exists()
    )
    return {
        "path": str(db),
        "schema_version": version,
        "rows": sum(per_product.values()),
        "per_product": per_product,
        "meta": meta,
        "size_bytes": size,
    }


def get(
    key: str, *, cache_path: str | None = None, config_path: str | None = None
) -> dict[str, Any] | None:
    """One cached record by key (the flat row, ``raw`` left as its JSON string)."""
    init_db(cache_path=cache_path, config_path=config_path)
    conn = connect(cache_path=cache_path, config_path=config_path)
    try:
        row = conn.execute("SELECT * FROM issue WHERE key = ?", (key,)).fetchone()
    finally:
        conn.close()
    return dict(row) if row else None


def export(
    *,
    product: str | None = None,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> list[dict[str, Any]]:
    """Dump the whole cache (optionally per-product) for eyeballing / grep."""
    init_db(cache_path=cache_path, config_path=config_path)
    conn = connect(cache_path=cache_path, config_path=config_path)
    try:
        if product:
            cur = conn.execute("SELECT * FROM issue WHERE product = ? ORDER BY key", (product,))
        else:
            cur = conn.execute("SELECT * FROM issue ORDER BY key")
        return [dict(r) for r in cur]
    finally:
        conn.close()


def clear(
    *,
    product: str | None = None,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> int:
    """Wipe the cache (optionally per-product); return issue rows removed."""
    init_db(cache_path=cache_path, config_path=config_path)
    conn = connect(cache_path=cache_path, config_path=config_path)
    try:
        with conn:
            if product:
                conn.execute(
                    "DELETE FROM issue_link WHERE src IN (SELECT key FROM issue WHERE product = ?)",
                    (product,),
                )
                removed = conn.execute("DELETE FROM issue WHERE product = ?", (product,)).rowcount
                conn.execute("DELETE FROM meta WHERE product = ?", (product,))
            else:
                conn.execute("DELETE FROM issue_link")
                removed = conn.execute("DELETE FROM issue").rowcount
                conn.execute("DELETE FROM meta")
        return removed
    finally:
        conn.close()
