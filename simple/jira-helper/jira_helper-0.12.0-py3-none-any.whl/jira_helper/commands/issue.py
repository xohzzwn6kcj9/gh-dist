"""`issue` commands — ticket queries (F004–F008)."""

from typing import Annotated

import typer

from .. import issue as issue_lib
from .. import output
from . import _common

app = typer.Typer(no_args_is_help=True, help="Query Jira issues (F004–F008).")

_READ = ("profile", "no_cache", "cache_path", "config_path")


@app.command("list")
def list_(
    ctx: typer.Context,
    assignee: Annotated[
        list[str] | None, typer.Option("--assignee", help="Assignee name(s) or account-id(s).")
    ] = None,
    org: Annotated[
        list[str] | None,
        typer.Option("--org", help="Org unit name(s) — expands the subtree to its members."),
    ] = None,
    jql: Annotated[
        str | None, typer.Option("--jql", help="Raw JQL passthrough (escape hatch).")
    ] = None,
    created_from: Annotated[
        str | None, typer.Option("--created-from", help="Created on/after (YYYY-MM-DD).")
    ] = None,
    created_to: Annotated[
        str | None, typer.Option("--created-to", help="Created on/before (YYYY-MM-DD).")
    ] = None,
    updated_from: Annotated[
        str | None,
        typer.Option("--updated-from", help="Updated on/after (YYYY-MM-DD or relative, e.g. -1w)."),
    ] = None,
    updated_to: Annotated[
        str | None,
        typer.Option("--updated-to", help="Updated on/before (YYYY-MM-DD or relative, e.g. -1d)."),
    ] = None,
    assigned_from: Annotated[
        str | None,
        typer.Option(
            "--assigned-from", help="Was assigned on/after (history; needs --assignee/--org)."
        ),
    ] = None,
    assigned_to: Annotated[
        str | None,
        typer.Option(
            "--assigned-to", help="Was assigned on/before (history; needs --assignee/--org)."
        ),
    ] = None,
    roots: Annotated[
        bool, typer.Option("--roots", help="Collapse the result to its root issues (F006).")
    ] = False,
    verbose: Annotated[
        bool,
        typer.Option(
            "--verbose",
            help="With --roots: show the path from each root epic down to the assigned tickets.",
        ),
    ] = False,
) -> None:
    """List issues by assignee(s), org unit(s), date range, or JQL. Feature: F004/F005/F007/F008.

    '--org' expands a unit's subtree (whole 실 or one 팀) to its members (F007).
    '--roots' collapses the result to its effective root issues (F006).
    '--created-from/--to' filters on the creation date; '--updated-from/--to' (F044) on
    last-modified — and since Jira stamps 'updated' on create, '--updated-from -1w' covers
    'created or modified in the last week' in one filter. Both accept an absolute date
    (2026-06-18) or a bare relative expression (-1w, startOfWeek()).
    '--assigned-from/--assigned-to' (F008) filters by assignee *history* — issues the
    person held at some point in the window (assignee WAS IN ... DURING/AFTER/BEFORE);
    requires --assignee or --org, is mutually exclusive with --jql, and is live-only.
    The default (non-JSON) view is one line per ticket (KEY — summary [status]);
    '--roots' collapses it to the distinct root epics, and '--roots --verbose' shows
    the path from each root epic down to the assigned tickets as a tree — only the
    relevant chain, not the root's whole subtree; assigned leaves are marked '← name'.
    '--json' returns the underlying structure (flat list, or the nested forest).

    Example:
        jira-helper issue list --assignee 홍길동
        jira-helper issue list --org 플랫폼개발실 --updated-from -1w
        jira-helper issue list --org 플랫폼개발실 --roots --verbose
    Example output (--roots --verbose):
        PROJA-50 — Epic: Auth revamp [In Progress]
          PROJA-12 — Fix login [In Progress]  ← 홍길동
    """
    _common.run(
        ctx,
        lambda: issue_lib.list(
            assignee=assignee,
            org=org,
            jql=jql,
            created_from=created_from,
            created_to=created_to,
            updated_from=updated_from,
            updated_to=updated_to,
            assigned_from=assigned_from,
            assigned_to=assigned_to,
            roots=roots,
            paths=roots and verbose,
            **_common.opt_kwargs(ctx, _READ),
        ),
        human=output.format_tree,
    )


@app.command()
def roots(
    ctx: typer.Context,
    assignee: Annotated[
        list[str] | None, typer.Option("--assignee", help="Assignee name(s)/id(s).")
    ] = None,
    org: Annotated[list[str] | None, typer.Option("--org", help="Org unit name(s).")] = None,
    verbose: Annotated[
        bool,
        typer.Option("--verbose", help="Show the path down to each assigned ticket as a tree."),
    ] = False,
) -> None:
    """Root issues of an assignee/org set (walk effective parents). Feature: F006.

    Sugar for 'issue list --roots'. Reads the local cache (recursive CTE over
    effective_parent) when populated, else walks the live API. The default view
    lists each root epic on one line; add '--verbose' to show the paths down to the
    assigned tickets as a tree (assigned leaves marked '← name'). '--json' returns
    the underlying structure.

    Example:
        jira-helper issue roots --org 플랫폼개발실
        jira-helper issue roots --org 플랫폼개발실 --verbose
    Example output (--verbose):
        PROJA-50 — Epic: Auth revamp [In Progress]
          PROJA-12 — Fix login [In Progress]  ← 홍길동
    """
    _common.run(
        ctx,
        lambda: issue_lib.roots(
            assignee=assignee,
            org=org,
            paths=verbose,
            **_common.opt_kwargs(ctx, _READ),
        ),
        human=output.format_tree,
    )


@app.command()
def tree(
    ctx: typer.Context,
    key: Annotated[str, typer.Argument(help="Issue key, e.g. PROJA-123.")],
) -> None:
    """Parent→child hierarchy for KEY (native + virtual rules). Feature: F006.

    Climbs to KEY's effective root, then expands the subtree; each node is
    annotated with the rule that set its effective parent. Cache-backed when
    populated, else a live walk. The default view is an indented tree; '--json'
    emits the nested dict.

    Example:
        jira-helper issue tree PROJA-123
    Example output:
        PROJA-50 — Epic: Auth revamp [In Progress]
          PROJA-123 — Fix login [To Do]  (via epic-single-link)
        ...
    """
    _common.run(
        ctx, lambda: issue_lib.tree(key, **_common.opt_kwargs(ctx, _READ)), human=output.format_tree
    )


@app.command()
def get(
    ctx: typer.Context,
    key: Annotated[str, typer.Argument(help="Issue key, e.g. PROJA-123.")],
) -> None:
    """One issue's fields (live). Feature: F004.

    Returns a single flat record (key, summary, status, issue_type, assignee,
    assignee_id, project, parent, created, updated).

    Example:
        jira-helper issue get PROJA-123
    Example output (--json):
        {"key": "PROJA-123", "summary": "Fix login", "status": "In Progress",
         "assignee": "홍길동", "assignee_id": "5b10a2...", ...}
    """
    _common.run(ctx, lambda: issue_lib.get(key, **_common.opt_kwargs(ctx, _READ)))
