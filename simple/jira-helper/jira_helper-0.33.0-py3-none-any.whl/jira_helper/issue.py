"""F004–F008 — issue queries (list / roots / tree / get).

``--json`` is a render concern owned by the CLI, not here. People filters accept
names or account-ids (names resolved via the account store, F003); unknown values
pass through as account-ids so raw ids work without a store entry.

F006 (``roots`` / ``tree`` / ``list --roots``) walks each issue's *effective*
parent — native Jira parent overlaid with the virtual-parent rules (``rule``
module). ``roots`` is sugar for ``list(..., roots=True)``: take a result set and
collapse it to the distinct roots its members live under. ``tree`` climbs to an
issue's effective root, then expands the subtree below it.

**Cache cutover (F010).** When the local cache is populated, the *traversal* reads
(``roots`` / ``list(roots=True)`` / ``tree``) run off a recursive CTE over the
stored ``effective_parent`` — one index scan instead of per-ancestor live GETs,
and conditional-rule virtual descendants become enumerable (``WHERE
effective_parent = X``). They fall back transparently to the live walk when the
cache is empty/missing, ``--no-cache`` is set, or a raw ``--jql`` is given (the
cache can't evaluate arbitrary JQL). Plain ``list`` (non-roots) and ``get`` stay
live.
"""

from __future__ import annotations

import json
import re
from collections.abc import Iterator
from datetime import date, datetime, timedelta
from typing import Any

from . import (
    account,
    cache,  # cache-backed traversal (F010 cutover); imports config only, no cycle
)
from . import org as org_lib  # aliased so the `org` *parameter* can't shadow the module
from . import rule as rule_lib  # pure effective_parent engine (rule.resolve imports us lazily)
from ._concurrency import parallel_map  # bounded, input-ordered I/O fan-out (#65)
from ._util import dedup
from .errors import JiraApiError, JiraHelperError

Issue = dict[str, Any]

# Fields requested from Jira and projected onto every Issue dict. `statuscategorychangedate`
# (#79) — the last status-CATEGORY transition — rides back on every search; sync reads it off
# the raw for the cache `status_category_changed_at` column (no per-issue changelog GET). It is NOT
# projected by `_parse_issue` (the live Issue shape is unchanged); only the cache sources it.
_FIELDS = [
    "summary",
    "status",
    "issuetype",
    "assignee",
    "project",
    "parent",
    "created",
    "updated",
    "statuscategorychangedate",
]
# Plus issue links when the virtual-parent engine needs them (roots / tree / rule test).
_LINK_FIELDS = [*_FIELDS, "issuelinks"]
_PAGE_SIZE = 100
# Safety cap against the known runaway-nextPageToken bug (~10k issues at this size).
_MAX_PAGES = 100
# Max account-ids per `assignee in (...)` clause; a whole-실 union is chunked + merged
# so a large org never blows past Jira's JQL/request-size limit (F007).
_ASSIGNEE_BATCH = 50
# Bound the native-subtree fetch in `tree` against a pathological hierarchy.
_TREE_MAX_NODES = 500


def _jql_quote(value: str) -> str:
    """Quote a value for safe inclusion in JQL (escape backslash + double-quote)."""
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


# A Jira relative-date *offset*: optional sign, digits, then a w/d/h/m unit (e.g. -1w, +3d).
_RELATIVE_OFFSET = re.compile(r"^[+-]?\d+[wdhm]$", re.IGNORECASE)
# A Jira date *function* call: an identifier then a single (...) with no nested parens
# (now() / startOfWeek() / startOfDay(-1)). Anchored + paren-free body so a typo'd or
# structure-mutating bound (`2024-01-(1)`, `x() OR y()`) fails to match → gets quoted →
# Jira rejects it cleanly, rather than slipping into the clause unquoted.
_DATE_FUNCTION = re.compile(r"^[A-Za-z]+\([^()]*\)$")
# A bare absolute date with NO time component (e.g. 2026-06-18) — a shape gate (not a
# calendar validator) for the inclusive-end suffix: only a date-only ``--*-to`` bound
# gets a " 23:59" appended; a datetime the operator typed (2026-06-18 14:30) or a
# relative form falls through and is left verbatim.
_DATE_ONLY = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def _is_relative_date(value: str) -> bool:
    """True for a Jira relative-date expression that must NOT be quoted.

    Two shapes Jira accepts only **bare** in a date comparison: an offset like
    ``-1w`` / ``+3d`` (``±N`` + a w/d/h/m unit) and a date function like
    ``startOfWeek()`` / ``now()`` / ``startOfDay(-1)``. An absolute date
    (``2026-06-18`` or a quoted timestamp) returns False and stays quoted — Jira
    reads ``updated >= "-1w"`` as a literal string and rejects it, so the relative
    forms have to pass through without quotes.
    """
    v = value.strip()
    return bool(_RELATIVE_OFFSET.match(v)) or bool(_DATE_FUNCTION.match(v))


def _date_value(value: str) -> str:
    """Render a date bound for JQL: quote an absolute date, pass a relative one bare."""
    return value if _is_relative_date(value) else _jql_quote(value)


def _end_boundary(value: str) -> str:
    """Render a ``--*-to`` (end) bound so a bare end date includes the whole end day.

    A bare ``YYYY-MM-DD`` end date alone means that day's *start* (00:00) in the
    querying account's timezone, excluding the rest of the day — the inclusive-end
    off-by-one (#30). So a bare date gets ``" 23:59"`` appended (→ ``"2026-06-18
    23:59"``), making the end day inclusive **to the minute** (Jira's JQL date-time
    resolution is minute-granular, so the final <60s sit outside its ceiling, by
    design). A relative bound (``-1w``, ``startOfDay()``) passes bare — Jira rejects a
    quoted/suffixed relative — and a value that already carries a time component is
    honored verbatim (the operator's explicit instant). Used only for ``to``/end slots;
    start bounds keep :func:`_date_value` (00:00 is already the inclusive lower bound).
    """
    v = value.strip()
    if _DATE_ONLY.match(v):
        return _jql_quote(v + " 23:59")
    return _date_value(v)


# --- status-category-changed (#79): cache-SIDE date bounds (NOT JQL) -------------------
#
# `--status-category-changed-*`, and the cache-only AND-combination of `--created/--updated-*`
# (AC#3), filter the SQLite columns directly — so a relative form like `-4w` must be
# resolved to a concrete date HERE (Jira isn't in the loop to interpret it). Bounds are
# day-granular `YYYY-MM-DD` strings compared LEXICALLY against the ISO columns —
# chronological because a single Jira account stamps one timezone offset on every row.
# This deliberately does NOT reuse `_date_value`/`_end_boundary` (those emit JQL with a
# `" 23:59"` suffix, wrong for a full-ISO string compare); keep the two paths separate.
_REL_PARTS = re.compile(r"^([+-]?)(\d+)([wdhm])$", re.IGNORECASE)
# Relative-offset unit → one-unit timedelta (scaled by the signed count). Module-level so
# it isn't rebuilt per call, and the regex↔unit mapping sits in one place.
_REL_UNIT = {
    "w": timedelta(weeks=1),
    "d": timedelta(days=1),
    "h": timedelta(hours=1),
    "m": timedelta(minutes=1),
}


def _bounds_active(bounds: tuple[str | None, str | None] | None) -> bool:
    """True if *bounds* has at least one non-None side (a date range is in play)."""
    return bounds is not None and (bounds[0] is not None or bounds[1] is not None)


def _resolve_bound_date(value: str, now: datetime) -> str:
    """A cache-side date bound → a ``YYYY-MM-DD`` (day granularity), resolved against *now*.

    Accepts a Jira relative offset (``-4w`` / ``-30d`` / ``+1h``), a bare ``YYYY-MM-DD``,
    or a full ISO timestamp (its date part is taken). Jira date *functions*
    (``startOfWeek()``) can't be evaluated off the live path → a clear raise.
    """
    v = value.strip()
    rel = _REL_PARTS.match(v)
    if rel:
        num = int(rel.group(2)) * (-1 if rel.group(1) == "-" else 1)
        return (now + _REL_UNIT[rel.group(3).lower()] * num).date().isoformat()
    if _DATE_ONLY.match(v) or (len(v) >= 10 and _DATE_ONLY.match(v[:10])):
        return v[:10]
    raise JiraHelperError(
        f"can't resolve {value!r} for a cache-side date bound; use a "
        "relative offset (-4w, -30d) or YYYY-MM-DD (Jira date functions like startOfWeek() "
        "aren't supported off the live path)"
    )


def _date_bounds(
    from_: str | None, to_: str | None, *, now: datetime | None = None
) -> tuple[str | None, str | None]:
    """``(lower_inclusive, upper_exclusive)`` ``YYYY-MM-DD`` bounds for a cache-side range (#79).

    Lower = the from-date (start-of-day, already the inclusive lower bound); upper = the day
    AFTER the to-date, so a bare end date includes the whole end day (the inclusive-end #30
    rule, expressed as an exclusive next-day ``<`` bound for the lexical column compare).
    Either side may be ``None``.
    """
    now = now or datetime.now()
    lower = _resolve_bound_date(from_, now) if from_ else None
    upper = None
    if to_:
        end = date.fromisoformat(_resolve_bound_date(to_, now))
        upper = (end + timedelta(days=1)).isoformat()
    return lower, upper


def _filter_by_status_category_changed(
    items: list[dict[str, Any]], bounds: tuple[str | None, str | None] | None
) -> list[dict[str, Any]]:
    """Keep items whose ``status_category_changed_at`` is in ``[lower, upper)`` (#79; cache-only).

    *bounds* ``None`` → identity (not active). Otherwise each item must carry
    ``status_category_changed_at`` (readers attach it when bounds are passed); a ``None`` value
    is dropped by any active bound — mirroring how :func:`_filter_by_project` drops an
    unparseable project under an include. Lexical compare on the ISO column is chronological
    (uniform account tz). Order is preserved (a prior sort holds). Used for the ``roots``
    views, where it keys on each result's *effective root* (the flat ``list`` path filters
    SQL-side in :func:`cache.flat_rows`).
    """
    if not _bounds_active(bounds):
        return items
    lower, upper = bounds
    out: list[dict[str, Any]] = []
    for item in items:
        scat = item.get("status_category_changed_at")
        if scat is None:
            continue
        if lower is not None and scat < lower:
            continue
        if upper is not None and scat >= upper:
            continue
        out.append(item)
    return out


def _resolve_assignee(name_or_id: str, config_path: str | None) -> str:
    """Map a stored name to its account-id; pass an unknown value through unchanged."""
    entry = account.get(name_or_id, config_path=config_path)
    return entry["account_id"] if entry else name_or_id


def _resolve_ids(
    assignee: list[str] | None, org_units: list[str] | None, config_path: str | None
) -> list[str]:
    """Combined, de-duped account-ids from --assignee (names/ids) + --org subtree expansion."""
    ids: list[str] = [_resolve_assignee(a, config_path) for a in (assignee or [])]
    for unit in org_units or []:
        ids.extend(org_lib.member_ids(unit, config_path=config_path))
    return dedup(ids)


def _range_clauses(field: str, from_: str | None, to: str | None) -> list[str]:
    """``field >= from`` / ``field <= to`` clauses for whichever bounds are given.

    The ``from`` bound is rendered via :func:`_date_value`, the ``to`` bound via
    :func:`_end_boundary`, so an absolute date is quoted while a relative one (``-1w``,
    ``startOfWeek()``) passes through bare (Jira rejects a quoted relative). A bare
    ``YYYY-MM-DD`` ``from`` is start-of-day (already the inclusive lower bound); a bare
    ``to`` includes the whole end day, to the minute, in the querying account's timezone.
    """
    clauses: list[str] = []
    if from_:
        clauses.append(f"{field} >= {_date_value(from_)}")
    if to:
        clauses.append(f"{field} <= {_end_boundary(to)}")
    return clauses


def _date_clauses(
    created_from: str | None,
    created_to: str | None,
    updated_from: str | None = None,
    updated_to: str | None = None,
) -> list[str]:
    """The ``created`` + ``updated`` range clauses, AND-combined with the people filter.

    ``updated`` (F044) covers *both* creation and modification — Jira stamps ``updated``
    on create — so ``updated >= -1w`` answers "active in the last week" in one clause.
    """
    return [
        *_range_clauses("created", created_from, created_to),
        *_range_clauses("updated", updated_from, updated_to),
    ]


# Jira's `statusCategory` has exactly three buckets; accept friendly aliases + the raw
# category keys and normalize to the canonical JQL name. A specific *status* (e.g.
# "Cancelled") is NOT a category — it usually lives *inside* the Done bucket — so dropping
# just it keeps completed work and is `--exclude-status`, not a category filter.
_STATUS_CATEGORIES = {
    "todo": "To Do",
    "to do": "To Do",
    "to-do": "To Do",
    "new": "To Do",
    "inprogress": "In Progress",
    "in progress": "In Progress",
    "in-progress": "In Progress",
    "indeterminate": "In Progress",
    "doing": "In Progress",
    "done": "Done",
}


def _normalize_category(value: str) -> str:
    """Map a status-category alias/key to its canonical JQL name (raise on unknown).

    Validated here (offline) rather than deferred to a Jira 400, so a typo'd category
    fails with a clear, testable message listing the three valid buckets.
    """
    try:
        return _STATUS_CATEGORIES[value.strip().lower()]
    except KeyError:
        raise JiraHelperError(
            f"unknown status category {value!r}; expected one of: To Do, In Progress, Done "
            "(aliases: todo, in-progress, done)"
        ) from None


def _in_clause(field: str, values: list[str], *, negate: bool = False) -> str:
    """``field [not] in ("a", "b")`` from already-final values (quoted, de-duped)."""
    op = "not in" if negate else "in"
    return f"{field} {op} ({', '.join(_jql_quote(v) for v in dedup(values))})"


def _status_clauses(
    status_category: list[str] | None,
    status: list[str] | None,
    exclude_status: list[str] | None,
    open_only: bool,
) -> list[str]:
    """statusCategory / status filter clauses, AND-combined with the rest of the query.

    ``open_only`` is the ``statusCategory != "Done"`` shorthand (≈ To Do + In Progress);
    ``status_category`` selects whole buckets (aliases normalized); ``status`` /
    ``exclude_status`` match specific status names (the latter is how you drop "Cancelled"
    while keeping completed work — see :data:`_STATUS_CATEGORIES`). Each is optional; the
    caller guards that ``open_only`` and ``status_category`` aren't both set.
    """
    clauses: list[str] = []
    if open_only:
        clauses.append('statusCategory != "Done"')
    if status_category:
        cats = [_normalize_category(c) for c in status_category]
        clauses.append(_in_clause("statusCategory", cats))
    if status:
        clauses.append(_in_clause("status", status))
    if exclude_status:
        clauses.append(_in_clause("status", exclude_status, negate=True))
    return clauses


def _project_of_key(key: str | None) -> str | None:
    """The project key embedded in an issue key (``PROJA-123`` → ``PROJA``).

    The project is the prefix before the final ``-<number>`` — a Jira invariant (project
    keys carry no hyphen, issue numbers are digits). Used to read a node's project where the
    dict carries no ``project`` field: the display-only ``--roots --verbose`` forest nodes,
    which omit it (flat ``list`` / ``roots`` items use their authoritative ``project`` field
    directly). Returns ``None`` when *key* is missing or has no numeric suffix.
    """
    if not key:
        return None
    head, sep, tail = key.rpartition("-")
    return head if sep and tail.isdigit() else None


def _filter_by_project(
    items: list[dict[str, Any]],
    project: list[str] | None,
    exclude_project: list[str] | None,
) -> list[dict[str, Any]]:
    """Keep items whose project passes the include/exclude filter (F047) — output-side.

    Applied to the *final* result (not the JQL): the flat ``list``, the collapsed ``roots``,
    or the ``--roots --verbose`` forest roots. So a virtual (rule-derived) root in an
    excluded project drops out even though the seed that climbed to it lives in a kept
    project — the query stays full and the project filter is post-traversal. Each item's
    project comes from its parsed ``project`` field (authoritative; flat list / collapsed
    roots) or, failing that, its key prefix (:func:`_project_of_key`; forest nodes carry no
    ``project``). Order is preserved (a prior sort holds); a no-op identity when neither set
    is given. An unparseable/``None`` project is *dropped* by an include and *kept* by an
    exclude.
    """
    if not project and not exclude_project:
        return items
    out: list[dict[str, Any]] = []
    for item in items:
        proj = item.get("project") or _project_of_key(item.get("key"))
        if project and proj not in project:
            continue
        if exclude_project and proj in exclude_project:
            continue
        out.append(item)
    return out


# Sortable fields (F046) → default descending? The CLI name is also the JQL ORDER BY field.
# Limited to fields present in BOTH the live parse and the cache row so live and cache-backed
# views sort identically — timestamps (ISO strings) sort chronologically by string compare =
# Jira's JQL order, and `key` is natural-sorted (below) to match Jira's numeric ordering.
# `status-category-changed` (#79) is the exception: NO JQL field, Issue/cache key is
# `status_category_changed_at` (via `_SORT_KEY_ALIAS`), so it is CACHE-ONLY — `list()`/`tree()`
# force the cache path and raise on the live path before any `_order_by` is built.
_SORT_FIELDS = {"created": True, "updated": True, "key": False, "status-category-changed": True}
# CLI sort name → Issue/cache-row key, where they differ (only status-category-changed today).
_SORT_KEY_ALIAS = {"status-category-changed": "status_category_changed_at"}

# An issue key split for natural sort: project + zero-padded-free integer (PROJA-123).
_KEY_SPLIT = re.compile(r"^(.*?)-(\d+)$")


def _resolve_sort(sort: str | None, asc: bool, desc: bool) -> tuple[str, bool]:
    """Resolve the --sort/--asc/--desc flags to ``(field, descending)``.

    Field defaults to ``created``; direction defaults per-field (created/updated → desc,
    key → asc) and is overridden by ``--asc``/``--desc``. ``--asc`` with ``--desc``, or an
    unknown field, raises — validated offline for a clear, testable error.
    """
    if asc and desc:
        raise JiraHelperError("--asc and --desc are mutually exclusive")
    field = (sort or "created").strip().lower()
    if field not in _SORT_FIELDS:
        raise JiraHelperError(
            f"unknown sort field {sort!r}; expected one of: "
            "created, updated, key, status-category-changed"
        )
    if asc:
        descending = False
    elif desc:
        descending = True
    else:
        descending = _SORT_FIELDS[field]
    return field, descending


def _order_by(field: str, descending: bool) -> str:
    """The JQL ``ORDER BY`` clause for a resolved sort (field == JQL field, already validated)."""
    return f"ORDER BY {field} {'DESC' if descending else 'ASC'}"


def _natural_key(key: str) -> tuple[str, int]:
    """Natural sort key for an issue key — ``"PROJA-10"`` → ``("PROJA", 10)`` so PROJA-2
    sorts before PROJA-10 (matching Jira's ``ORDER BY key``). A key without a numeric
    suffix falls back to ``(key, 0)``."""
    m = _KEY_SPLIT.match(key)
    return (m.group(1), int(m.group(2))) if m else (key, 0)


def _sort_value(issue: Issue, field: str) -> Any:
    """Python sort key for an Issue dict on *field* (key → natural; else the raw value).

    *field* is the CLI sort name; ``_SORT_KEY_ALIAS`` maps it to the Issue dict key where
    they differ (``status-category-changed`` → ``status_category_changed_at``, #79).
    """
    if field == "key":
        return _natural_key(issue.get("key") or "")
    return issue.get(_SORT_KEY_ALIAS.get(field, field)) or ""


def _sort_issues(issues: list[Issue], field: str, descending: bool) -> list[Issue]:
    """Sort issues by *field*; mirrors the JQL ORDER BY so live and cache views agree."""
    return sorted(issues, key=lambda i: _sort_value(i, field), reverse=descending)


def _assigned_clause(ids: list[str], assigned_from: str | None, assigned_to: str | None) -> str:
    """A historical ``assignee WAS IN (...)`` clause — who *was* assigned in a window (F008).

    Unlike the ``assignee in (...)`` equality (the *current* assignee), this matches
    issues whose assignee equalled one of *ids* at some instant inside the range: Jira
    evaluates ``WAS`` against the change history, so it survives reassignment. ``DURING``
    for a closed range, ``AFTER`` / ``BEFORE`` for an open-ended one. The start bound
    goes through :func:`_date_value` and the ``--to`` end through :func:`_end_boundary`
    (absolute date quoted, relative like ``-1w`` bare); a bare ``YYYY-MM-DD`` ``--to``
    includes the whole end day, to the minute, in the querying account's timezone — same
    inclusive end as ``--created-to`` / ``--updated-to``.
    Precondition: *ids* non-empty and at least one bound given (enforced by ``list``).
    """
    vals = ", ".join(_jql_quote(i) for i in ids)
    if assigned_from and assigned_to:
        window = f"DURING ({_date_value(assigned_from)}, {_end_boundary(assigned_to)})"
    elif assigned_from:
        window = f"AFTER {_date_value(assigned_from)}"
    else:
        window = f"BEFORE {_end_boundary(assigned_to)}"
    return f"assignee WAS IN ({vals}) {window}"


def _compose_jql(
    id_chunk: list[str],
    filter_clauses: list[str],
    assignee_clause: str | None = None,
    order_by: str = "ORDER BY created DESC",
) -> str:
    """One JQL string from an assignee clause + the date/status filter clauses.

    *assignee_clause* (the F008 ``assignee WAS IN ...`` historical clause) is appended
    verbatim *instead* of the default ``assignee in (...)`` equality when given;
    otherwise the equality is built from *id_chunk* as before. *filter_clauses* carries
    the date-range (F008/F044) and status (F045) clauses, AND-combined after the assignee.
    *order_by* (F046) is the trailing sort clause; the default reproduces the prior
    newest-created-first behavior.
    """
    clauses: list[str] = []
    if assignee_clause:
        clauses.append(assignee_clause)
    elif id_chunk:
        clauses.append(_in_clause("assignee", id_chunk))
    clauses.extend(filter_clauses)
    return " AND ".join(clauses) + " " + order_by


def _chunks(seq: list[str], size: int) -> list[list[str]]:
    return [seq[i : i + size] for i in range(0, len(seq), size)]


def _parse_issue(raw: dict[str, Any]) -> Issue:
    """Project a raw Jira issue onto the flat Issue shape (cache-schema aligned)."""
    f = raw.get("fields") or {}
    assignee = f.get("assignee") or {}
    return {
        "key": raw.get("key"),
        "summary": f.get("summary"),
        "status": (f.get("status") or {}).get("name"),
        # statusCategory.key (new/indeterminate/done) — language-independent, for color
        "status_category": ((f.get("status") or {}).get("statusCategory") or {}).get("key"),
        "issue_type": (f.get("issuetype") or {}).get("name"),
        "assignee": assignee.get("displayName"),
        "assignee_id": assignee.get("accountId"),
        "project": (f.get("project") or {}).get("key"),
        "parent": (f.get("parent") or {}).get("key"),
        "created": f.get("created"),
        "updated": f.get("updated"),
    }


def _linked_keys(raw: dict[str, Any]) -> list[str]:
    """The keys of every issue linked to *raw* (both link directions, de-duped)."""
    links = (raw.get("fields") or {}).get("issuelinks") or []
    keys: list[str] = []
    for link in links:
        for side in ("inwardIssue", "outwardIssue"):
            key = (link.get(side) or {}).get("key")
            if key:
                keys.append(key)
    return dedup(keys)


def _link_rows(raw: dict[str, Any]) -> list[tuple[str, str, str]]:
    """``(src, dst, type)`` for every link of *raw* (both directions, de-duped).

    Unlike ``_linked_keys`` (which flattens to bare keys for the rule engine), this
    keeps the Jira link-type name so ``sync`` can populate ``issue_link`` for a
    future ``linked_by_type`` strategy (F006).
    """
    src = raw.get("key")
    links = (raw.get("fields") or {}).get("issuelinks") or []
    rows: list[tuple[str, str, str]] = []
    for link in links:
        ltype = (link.get("type") or {}).get("name") or "relates"
        for side in ("inwardIssue", "outwardIssue"):
            dst = (link.get(side) or {}).get("key")
            if src and dst:
                rows.append((src, dst, ltype))
    return [*dict.fromkeys(rows)]


def _node_from_raw(raw: dict[str, Any]) -> Issue:
    """A parsed issue plus its ``linked_keys`` — the unit the rule engine resolves."""
    return {**_parse_issue(raw), "linked_keys": _linked_keys(raw)}


# Rule-engine traversal scratch fields — never part of the public issue shape.
_TRAVERSAL_ONLY = frozenset({"linked_keys", "linked_roots", "external_linked_keys"})


def _public_issue(node: Issue) -> Issue:
    """Drop traversal-only fields so roots output matches the plain ``list`` shape."""
    return {k: v for k, v in node.items() if k not in _TRAVERSAL_ONLY}


def _search_raw(
    client: Any, jql: str, *, with_links: bool = False, max_pages: int = _MAX_PAGES
) -> Iterator[dict[str, Any]]:
    """Yield each *raw* Jira issue for a JQL search, following ``nextPageToken``.

    The raw-emitting core of ``_search``: ``sync`` consumes it to keep the full
    payload (the cache ``raw`` column + typed ``issue_link`` rows), and passes a
    higher ``max_pages`` than the live read default.
    """
    fields = _LINK_FIELDS if with_links else _FIELDS
    token: str | None = None
    for _ in range(max_pages):
        body: dict[str, Any] = {"jql": jql, "fields": fields, "maxResults": _PAGE_SIZE}
        if token:
            body["nextPageToken"] = token
        data = client.post("/search/jql", json=body) or {}  # tolerate an empty body
        yield from data.get("issues") or []
        token = data.get("nextPageToken")
        if data.get("isLast") or not token:
            break


def _search(
    client: Any, jql: str, *, with_links: bool = False, max_pages: int = _MAX_PAGES
) -> list[Issue]:
    """Run a JQL search, parsing each issue to the flat ``Issue`` shape (to last page)."""
    parse = _node_from_raw if with_links else _parse_issue
    return [
        parse(raw) for raw in _search_raw(client, jql, with_links=with_links, max_pages=max_pages)
    ]


def _fetch_node(client: Any, key: str) -> Issue:
    """GET one issue (with linked-issue keys) as a rule-engine node."""
    raw = client.get(f"/issue/{key}", fields=",".join(_LINK_FIELDS))
    return _node_from_raw(raw or {})


def _node_fetcher(client: Any) -> tuple[Any, dict[str, Issue]]:
    """A memoized node fetcher + its memo dict, shared by roots/tree traversal.

    ``fetch`` is concurrency-safe for the #65 seed-climb parallelism: the read uses
    ``memo.get`` and the populate uses ``memo.setdefault`` (a single atomic dict op),
    so racing first-callers for the same key all return the SAME canonical node
    object — the setdefault winner's fetch result. The only cost is a bounded
    duplicate GET (at most the keys that first-miss concurrently, ≤ the worker cap);
    every later caller hits the memo. A serial caller behaves exactly as before.
    """
    memo: dict[str, Issue] = {}

    def fetch(key: str) -> Issue:
        node = memo.get(key)
        if node is None:
            node = memo.setdefault(key, _fetch_node(client, key))
        return node

    return fetch, memo


def _linked_roots_for(node: Issue, fetch, *, needs_closure: bool = False) -> list[str] | None:
    """Collapse *node*'s links to their native-subtree roots, stashing the external set.

    Climbs each link's native-parent chain via the memoized *fetch* (a 404 stops that chain)
    to assemble the native_parent map, drops the issue's OWN native descendants / self-links
    (``rule._external_linked_keys`` — stashed on the node as ``external_linked_keys`` for the
    ``linked_count`` matcher), then collapses what remains (:func:`rule._collapse_linked_roots`).

    Fetch policy: ≥2 links always climb (the map is needed to collapse). A SINGLE link climbs
    only when *needs_closure* (a ``linked`` / ``linked_count`` rule is active) — so it can be
    excluded if it is the issue's own child (A1-plus); otherwise 0/1 links → ``None`` with ZERO
    extra fetches (the engine falls back to the raw links). The shared memo + the local map
    keep each ancestor a single fetch.
    """
    links = node.get("linked_keys") or []
    if not links or (len(links) < 2 and not needs_closure):
        return None
    native_parent: dict[str, str | None] = {}
    for link in links:
        cur: str | None = link
        while cur is not None and cur not in native_parent:
            try:
                n = fetch(cur)
            except JiraApiError as exc:
                if exc.status == 404:
                    break  # dangling / not-visible ancestor stops this chain
                raise
            native_parent[cur] = n.get("parent")
            cur = n.get("parent")
    external = rule_lib._external_linked_keys(node["key"], links, native_parent)
    node["external_linked_keys"] = external
    return rule_lib._collapse_linked_roots(external, native_parent)


def _climb_to_root(
    fetch, start_key: str, rules: list[dict[str, Any]], manual: dict[str, str]
) -> tuple[Issue, dict[str, list[str]]]:
    """Climb effective parents from *start_key* to its root.

    Returns ``(root_node, climb_children)`` where ``climb_children`` maps each
    ancestor key → the child we climbed from. That lets ``tree`` splice a *virtual*
    (rule-derived) ancestor edge back into a native-only downward walk so the
    queried node never drops out of its own tree. A 404 on an ancestor (deleted or
    not-visible parent) stops the climb at the furthest *visible* node rather than
    aborting the whole traversal; other API errors still propagate.

    Concurrency (#65): runs once per seed across worker threads sharing one memo, so a
    node on a shared ancestor path is climbed by >1 thread. ``seen``/``climb_children``
    are per-call (no race). The two writes onto the *shared* node — ``linked_roots``
    here and ``external_linked_keys`` inside ``_linked_roots_for`` — are race-harmless
    because each value is a pure function of immutable node fields + a deterministic
    native-parent closure (so concurrent writers compute the IDENTICAL value, and a
    single-key dict store of a ready value can't tear), and both are stripped from output
    by ``_public_issue``. Two invariants this rests on: the ``_linked_roots_for`` call
    below must stay the EAGER ``setdefault`` default-arg (it writes ``external_linked_keys``
    first, so ``linked_roots`` present ⟹ ``external_linked_keys`` present), and any future
    ``parent:`` strategy must stay pure + independent of mutable node state.
    """
    node = fetch(start_key)
    needs = rule_lib._rules_need_link_closure(rules)
    seen: set[str] = set()
    climb_children: dict[str, list[str]] = {}
    while node["key"] not in seen:  # cycle-guard: stop if we revisit a key
        seen.add(node["key"])
        # Eager (not lazy) so external_linked_keys is co-written — see the docstring invariant.
        node.setdefault("linked_roots", _linked_roots_for(node, fetch, needs_closure=needs))
        parent_key, _ = rule_lib.effective_parent_of_node(node, rules, manual)
        if not parent_key:
            break
        try:
            parent_node = fetch(parent_key)
        except JiraApiError as exc:
            if exc.status == 404:
                break  # parent gone / not visible → current node is the visible root
            raise
        climb_children.setdefault(parent_key, []).append(node["key"])
        node = parent_node
    return node, climb_children


def _climb_all_seeds(
    fetch, seeds: list[Issue], rules: list[dict[str, Any]], manual: dict[str, str]
) -> list[tuple[Issue, dict[str, list[str]]]]:
    """Climb every seed to its root concurrently (#65), one task per seed.

    Returns each seed's ``(root, climb_children)`` in INPUT (seed) order — the single
    place the seed-climb fan-out lives (worker cap, first-exception-in-input-order,
    cancel policy), shared by :func:`_collapse_to_roots` and
    :func:`_collapse_to_root_paths`. Workers only read the shared memo (whose atomic
    fetch keeps one canonical node per key); callers fold the input-ordered results
    single-threaded, so output stays byte-identical to a serial climb.
    """
    return parallel_map(lambda seed: _climb_to_root(fetch, seed["key"], rules, manual), seeds)


def _collapse_to_roots(
    client: Any,
    seeds: list[Issue],
    rules: list[dict[str, Any]],
    manual: dict[str, str],
    *,
    field: str = "created",
    descending: bool = True,
) -> list[Issue]:
    """Walk each seed's effective-parent chain to its root; return the distinct roots."""
    fetch, memo = _node_fetcher(client)
    memo.update({s["key"]: s for s in seeds})  # prime with seeds (they carry linked_keys)

    # Climb seeds concurrently (#65, see _climb_all_seeds), then fold in INPUT order so
    # `roots.setdefault` first-wins + the trailing `_sort_issues` stay byte-identical to serial.
    roots: dict[str, Issue] = {}
    for root, _children in _climb_all_seeds(fetch, seeds, rules, manual):
        roots.setdefault(root["key"], root)
    return _sort_issues([_public_issue(r) for r in roots.values()], field, descending)


def _build_path_forest(
    nodes_by_key: dict[str, Issue],
    edges: dict[str, list[str]],
    seed_keys: set[str],
    *,
    field: str = "key",
    descending: bool = False,
) -> list[dict[str, Any]]:
    """Assemble the root→…→seed forest from a parent→children edge map.

    *edges* maps each parent key to the children climbed from it (toward the seeds);
    a node that is never a child is a forest root. Each node carries its display
    fields, and a node in *seed_keys* (an assigned ticket the climb started at) is
    tagged ``assigned_to`` so the renderer can mark the leaf. Siblings (and the forest
    roots) are ordered by the resolved sort *field* (F046; default by key ascending —
    the prior behavior). The edge map is acyclic by construction (``effective_parent``
    is a function), so the recursion terminates. Shared by the live + cache builders;
    sorting by created/updated requires those fields in *nodes_by_key*.
    """

    def sort_key(key: str) -> Any:
        return _sort_value(nodes_by_key.get(key) or {"key": key}, field)

    child_keys = {c for children in edges.values() for c in children}
    root_keys = sorted(
        (k for k in nodes_by_key if k not in child_keys), key=sort_key, reverse=descending
    )

    def build(key: str) -> dict[str, Any]:
        info = nodes_by_key.get(key) or {"key": key}
        children = sorted(edges.get(key, []), key=sort_key, reverse=descending)
        node: dict[str, Any] = {
            "key": key,
            "summary": info.get("summary"),
            "status": info.get("status"),
            "status_category": info.get("status_category"),
            "issue_type": info.get("issue_type"),
            "children": [build(c) for c in children],
        }
        if key in seed_keys and info.get("assignee"):
            node["assigned_to"] = info["assignee"]
        return node

    return [build(rk) for rk in root_keys]


def _collapse_to_root_paths(
    client: Any,
    seeds: list[Issue],
    rules: list[dict[str, Any]],
    manual: dict[str, str],
    *,
    field: str = "key",
    descending: bool = False,
) -> list[dict[str, Any]]:
    """Climb each seed to its root keeping the *path* edges; return the root→…→seed
    forest — only the climbed chains, not the roots' full subtrees (the
    ``issue list --roots --verbose`` view, with each assigned leaf marked)."""
    fetch, memo = _node_fetcher(client)
    memo.update({s["key"]: s for s in seeds})
    seed_keys = {s["key"] for s in seeds}

    # Climb every seed concurrently (#65); parallel_map returns the (root, climb_children)
    # results in INPUT (seed) order, so the single-threaded fold below reproduces the serial
    # loop exactly. Workers only read the shared memo. One pass folds both the edge map and
    # `forest_order` — the deterministic key order for nodes_by_key: seeds first (seed order),
    # then each seed's climbed ancestors/children in climb order. This is the byte-identity fix:
    # building from memo.items() instead would key off the parallel fetch-completion order and
    # make _build_path_forest's stable-sort tie-break nondeterministic. Building only from seeds
    # + climbed edges ALSO keeps the #62 restriction structural — link-closure byproducts memo
    # holds (linked_keys the engine fetched to resolve a `linked`/`linked_count` rule) are in no
    # edge, so they never enter the forest as phantom roots ("a node never a child is a root").
    results = _climb_all_seeds(fetch, seeds, rules, manual)
    raw_edges: dict[str, list[str]] = {}
    forest_order: list[str] = [s["key"] for s in seeds]
    for _root, climb_children in results:
        for parent_key, children in climb_children.items():
            raw_edges.setdefault(parent_key, []).extend(children)
            forest_order.append(parent_key)
            forest_order.extend(children)
    edges = {parent: dedup(children) for parent, children in raw_edges.items()}
    nodes_by_key = {k: memo[k] for k in dedup(forest_order) if k in memo}
    return _build_path_forest(nodes_by_key, edges, seed_keys, field=field, descending=descending)


# --- cache-backed traversal (F010 cutover; output mirrors the live shapes) -----


def _list_from_cache(
    ids: list[str] | None,
    *,
    cache_path: str | None,
    config_path: str | None,
    status_category_changed: tuple[str | None, str | None],
    updated: tuple[str | None, str | None],
    created: tuple[str | None, str | None],
    field: str,
    descending: bool,
) -> list[Issue]:
    """Flat cache-backed ``issue list`` for a cache-only status-category-changed query (#79).

    The cache twin of the live flat list: rows for *ids* (``None`` = the whole product —
    the seed-less ``--status-category-changed-from`` query, AC#2), with the date bounds
    (status-category-changed / updated / created) applied SQL-side (:func:`cache.flat_rows`).
    Each row's ``raw`` is re-parsed to the flat Issue shape with ``status_category_changed_at``
    attached so the sort (and ``--json``) can see it.
    """
    conn = cache.connect(cache_path=cache_path, config_path=config_path)
    try:
        rows = cache.flat_rows(
            conn,
            assignee_ids=ids,
            status_category_changed=status_category_changed,
            updated=updated,
            created=created,
        )
    finally:
        conn.close()
    out: list[Issue] = []
    for r in rows:
        issue = _parse_issue(json.loads(r["raw"]))
        issue["status_category_changed_at"] = r["status_category_changed_at"]
        out.append(issue)
    return _sort_issues(out, field, descending)


def _roots_from_cache(
    ids: list[str],
    *,
    cache_path: str | None,
    config_path: str | None,
    field: str = "created",
    descending: bool = True,
    status_category_changed: tuple[str | None, str | None] | None = None,
) -> list[Issue]:
    """Roots of the assignee *ids*' cached issues — re-parse each root's ``raw`` so the
    output is byte-identical to the live ``_collapse_to_roots`` shape.

    *status_category_changed* (#79) ``None`` → plain roots (unchanged shape). A bounds tuple →
    attach each root's ``status_category_changed_at`` (so the sort works) and keep only roots
    whose own value falls in range (effective-root semantics, like :func:`_filter_by_project`)."""
    conn = cache.connect(cache_path=cache_path, config_path=config_path)
    try:
        seed_keys = cache.keys_by_assignee(conn, ids)
        out: list[Issue] = []
        for root_key in cache.climb_roots(conn, seed_keys):
            row = conn.execute(
                "SELECT raw, status_category_changed_at FROM issue WHERE key = ?", (root_key,)
            ).fetchone()
            if row and row["raw"]:
                issue = _parse_issue(json.loads(row["raw"]))
                if status_category_changed is not None:
                    issue["status_category_changed_at"] = row["status_category_changed_at"]
                out.append(issue)
    finally:
        conn.close()
    out = _filter_by_status_category_changed(out, status_category_changed)
    return _sort_issues(out, field, descending)


def _root_paths_from_cache(
    ids: list[str],
    *,
    cache_path: str | None,
    config_path: str | None,
    field: str = "key",
    descending: bool = False,
    status_category_changed: tuple[str | None, str | None] | None = None,
) -> list[dict[str, Any]]:
    """Cache-backed ``issue list --roots --verbose``: the root→…→seed paths via one
    upward ``cache.climb_edges`` CTE, assembled into the same forest the live walk
    builds. An ``effective_parent`` absent from the returned chain (a dangling /
    not-yet-synced ancestor) makes its child a root — the live 404-stop equivalent.

    *status_category_changed* (#79) ``None`` → plain forest. A bounds tuple keeps only forest roots
    whose own ``status_category_changed_at`` falls in range (looked up from ``nodes_by_key`` so the
    forest dict shape stays byte-identical to the live forest — no leaked column)."""
    conn = cache.connect(cache_path=cache_path, config_path=config_path)
    try:
        seed_keys = set(cache.keys_by_assignee(conn, ids))
        rows = cache.climb_edges(conn, sorted(seed_keys))
    finally:
        conn.close()
    present = {r["key"] for r in rows}
    nodes_by_key: dict[str, Issue] = {}
    edges: dict[str, list[str]] = {}
    for r in rows:
        info: Issue = {
            "key": r["key"],
            "summary": r["summary"],
            "status": r["status"],
            "status_category": r["status_category"],
            "issue_type": r["issue_type"],
            "created": r["created"],  # F046: sort siblings by created/updated
            "updated": r["updated"],
            "status_category_changed_at": r[
                "status_category_changed_at"
            ],  # #79 sort-only (build() omits it)
        }
        if r["key"] in seed_keys and r["raw"]:
            info["assignee"] = _parse_issue(json.loads(r["raw"]))["assignee"]
        nodes_by_key[r["key"]] = info
        parent = r["effective_parent"]
        if parent and parent in present:
            edges.setdefault(parent, []).append(r["key"])
    forest = _build_path_forest(nodes_by_key, edges, seed_keys, field=field, descending=descending)
    if _bounds_active(status_category_changed):
        # Keep only forest roots whose own status_category_changed_at is in range — looked up from
        # nodes_by_key (which carries it) so the forest dicts keep their live-identical shape.
        kept = {
            n["key"]
            for n in _filter_by_status_category_changed(
                [*nodes_by_key.values()], status_category_changed
            )
        }
        forest = [root for root in forest if root["key"] in kept]
    return forest


def _tree_from_cache(
    key: str,
    *,
    cache_path: str | None,
    config_path: str | None,
    field: str = "key",
    descending: bool = False,
) -> dict[str, Any] | None:
    """Cache-backed ``tree`` (None → fall back to live: cache empty/missing or KEY absent).

    Climbs to KEY's effective root then nests every descendant by ``effective_parent``
    — virtual-aware because that column already folds native + rule + manual edges.
    Siblings are ordered by the resolved sort *field* (F046).
    """
    if not cache.path(cache_path=cache_path, config_path=config_path).exists():
        return None
    # `connect` migrates an older cache to the current schema (#84) before `subtree_rows`
    # selects `status_category_changed_at` — absent in a v2 cache synced before the upgrade.
    conn = cache.connect(cache_path=cache_path, config_path=config_path)
    try:
        if conn.execute("SELECT 1 FROM issue WHERE key = ? LIMIT 1", (key,)).fetchone() is None:
            return None
        root_keys = cache.climb_roots(conn, [key])
        rows = cache.subtree_rows(conn, root_keys[0]) if root_keys else []
    finally:
        conn.close()
    nodes = {
        r["key"]: {
            "key": r["key"],
            "summary": r["summary"],
            "status": r["status"],
            "status_category": r["status_category"],
            "issue_type": r["issue_type"],
            "effective_parent": r["effective_parent"],
            "source": r["source"],
            "created": r["created"],  # F046: sort-only, dropped before output below
            "updated": r["updated"],
            "status_category_changed_at": r[
                "status_category_changed_at"
            ],  # #79 sort-only, dropped below
            "children": [],
        }
        for r in rows
    }
    root_key = root_keys[0]
    for r in rows:
        parent = nodes.get(r["effective_parent"])
        if parent is not None and r["key"] != root_key:
            parent["children"].append(nodes[r["key"]])
    for node in nodes.values():
        node["children"].sort(key=lambda n: _sort_value(n, field), reverse=descending)
        # drop the sort-only columns so the output shape stays stable
        del node["created"], node["updated"], node["status_category_changed_at"]
    return nodes.get(root_key)


def _status_category_changed_list(
    *,
    assignee: list[str] | None,
    org: list[str] | None,
    jql: str | None,
    no_cache: bool,
    has_range: bool,
    has_dates: bool,
    has_status: bool,
    status_category_changed_from: str | None,
    status_category_changed_to: str | None,
    created_from: str | None,
    created_to: str | None,
    updated_from: str | None,
    updated_to: str | None,
    project: list[str] | None,
    exclude_project: list[str] | None,
    roots: bool,
    paths: bool,
    field: str,
    descending: bool,
    cache_path: str | None,
    config_path: str | None,
) -> list[Issue]:
    """The cache-only path for a ``--status-category-changed-*`` filter or sort (#79).

    ``status_category_changed_at`` lives only in the local cache, so this never touches Jira:
    it reads the populated cache, applies the date bounds (SQL-side for the flat list;
    post-traversal on the effective root for ``roots``), sorts, and runs the project filter.
    Combinations the cache can't express raise a clear, testable error instead of silently
    returning wrong results.
    """
    if no_cache or jql:
        raise JiraHelperError(
            "--status-category-changed-*/--sort status-category-changed are cache-only; "
            "drop --no-cache/--jql and populate the cache with `jira-helper sync run`"
        )
    if has_range or has_status:
        raise JiraHelperError(
            "--status-category-changed-*/--sort status-category-changed can't combine with "
            "--assigned-*/--status/--status-category/--exclude-status/--open (live-only filters)"
        )
    if not cache.is_populated(cache_path=cache_path, config_path=config_path):
        raise JiraHelperError(
            "--status-category-changed-*/--sort status-category-changed need a populated cache; "
            "run `jira-helper sync run` first"
        )
    ids = _resolve_ids(assignee, org, config_path)
    sc_bounds = _date_bounds(status_category_changed_from, status_category_changed_to)
    if roots:
        if has_dates:
            raise JiraHelperError(
                "--status-category-changed-* with --roots can't also take --created-*/--updated-* "
                "(combine date ranges on the flat `issue list` instead)"
            )
        if not ids:
            raise JiraHelperError(
                "issue roots with --status-category-changed-*/--sort status-category-changed "
                "needs --assignee/--org"
            )
        reader = _root_paths_from_cache if paths else _roots_from_cache
        result = reader(
            ids,
            cache_path=cache_path,
            config_path=config_path,
            field=field,
            descending=descending,
            status_category_changed=sc_bounds,
        )
    else:
        if not ids and not (status_category_changed_from or status_category_changed_to):
            raise JiraHelperError(
                "--sort status-category-changed with no --assignee/--org needs a "
                "--status-category-changed-* bound (a bare sort would dump the whole cache)"
            )
        result = _list_from_cache(
            ids or None,
            cache_path=cache_path,
            config_path=config_path,
            status_category_changed=sc_bounds,
            updated=_date_bounds(updated_from, updated_to),
            created=_date_bounds(created_from, created_to),
            field=field,
            descending=descending,
        )
    return _filter_by_project(result, project, exclude_project)


def list(
    *,
    assignee: list[str] | None = None,
    org: list[str] | None = None,
    jql: str | None = None,
    created_from: str | None = None,
    created_to: str | None = None,
    updated_from: str | None = None,
    updated_to: str | None = None,
    status_category_changed_from: str | None = None,
    status_category_changed_to: str | None = None,
    assigned_from: str | None = None,
    assigned_to: str | None = None,
    status_category: list[str] | None = None,
    status: list[str] | None = None,
    exclude_status: list[str] | None = None,
    open_only: bool = False,
    project: list[str] | None = None,
    exclude_project: list[str] | None = None,
    sort: str | None = None,
    asc: bool = False,
    desc: bool = False,
    roots: bool = False,
    paths: bool = False,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> list[Issue]:
    """F004/F005/F007/F008/F045/F046/#79: list by assignee / org / date / status / sort / JQL.

    ``--org`` expands each unit's subtree to its members' account-ids (F007). The
    combined assignee-id set is chunked across multiple searches so a whole-실
    never exceeds Jira's JQL IN-clause limit. ``roots=True`` (F006) collapses the
    result to the distinct root issues its members live under (effective parents);
    add ``paths=True`` (only with ``roots``) to instead return the root→…→assigned
    *forest* — each root with just the climbed chains down to the assigned tickets
    (the leaves tagged ``assigned_to``), not the roots' whole subtrees. This is the
    ``issue list --roots --verbose`` view.

    Date ranges AND with the people filter: ``--created-from/--to`` on the creation
    date and ``--updated-from/--to`` (F044) on last-modified — and since Jira stamps
    ``updated`` on create too, ``--updated-from -1w`` answers "created *or* modified in
    the last week" in one clause. Both accept an absolute date (``2026-06-18``) or a
    bare Jira relative expression (``-1w``, ``startOfWeek()``). Every ``--*-to`` bound is
    inclusive of the whole end day, to the minute, in the querying account's timezone (a
    bare end date is normalized to ``<date> 23:59``; see :func:`_end_boundary`).

    ``--assigned-from/--to`` (F008) instead filters by *assignee history*: ``assignee
    WAS IN (...) DURING/AFTER/BEFORE`` matches issues the id-set held at some point in
    the window (survives reassignment), so it requires ``--assignee``/``--org`` and is
    mutually exclusive with raw ``--jql``. All date-range paths are live-only (the
    cache stores only current state).

    Status filters (F045) refine any of the above (they don't stand alone — a status
    filter with no assignee/org/date/jql is rejected, to avoid scanning every matching
    issue): ``open_only`` → ``statusCategory != "Done"`` ("open only"); ``status_category``
    selects whole buckets (To Do / In Progress / Done, aliases normalized); ``status`` /
    ``exclude_status`` match specific status names (``exclude_status=["Cancelled"]`` drops
    cancelled while *keeping* completed work — a category filter can't, since Cancelled
    sits inside the Done bucket). ``open_only`` and ``status_category`` are the same axis,
    so they're mutually exclusive; any status filter is exclusive with raw ``--jql`` and
    forces the live path (the cache CTE doesn't evaluate status).

    Project filters (F047) keep/drop by project, applied to the *result* (not the query):
    ``project`` keeps only the named project key(s) and ``exclude_project`` drops them. For
    plain ``list`` this is each issue's own project; for ``roots`` / ``roots --verbose`` it
    is each result's *effective root* project — so a virtual (rule-derived) root in an
    excluded project is dropped even though the assigned ticket that climbed to it isn't (the
    query stays full, the filter is post-traversal; see :func:`_filter_by_project`). Both
    accept multiple keys, are refinements (they don't satisfy the standalone-filter gate — a
    bare project filter is still a broad sweep), are mutually exclusive with raw ``--jql``,
    and force the live path.

    Status-changed (#79) — ``--status-category-changed-from/--to`` filter on the last *status*
    transition (``status_category_changed_at``), distinct from ``updated`` (which advances on ANY
    edit, so a long-closed issue resurfaces in ``--updated-from`` on link/comment
    housekeeping). This field exists only in the local cache, so the query is **cache-only**:
    ``--no-cache`` / raw ``--jql`` / an unpopulated cache all raise (run ``sync run`` first).
    In this mode the flat list also AND-combines ``--created/--updated-*`` SQL-side against
    the cache columns (AC#3), and ``--assignee``/``--org`` is optional — omitted, it scans
    the whole synced product (AC#2). ``--assigned-*`` / status filters (live-only) can't be
    combined; for ``--roots`` the bound keys on each result's effective root (date ranges are
    flat-only there). Bounds accept ``-4w``/``-30d`` (resolved locally to a date) or
    ``YYYY-MM-DD`` (whole-day inclusive end), day-granular.

    Sort (F046): ``sort`` ∈ {created, updated, key, status-category-changed} with ``asc``/``desc``
    (default ``created`` desc; key sorts naturally, ``PROJA-2`` before ``PROJA-10``). It
    orders the flat list, the ``roots`` set, and the ``--roots --verbose`` / ``tree``
    siblings uniformly. ``--sort status-category-changed`` is cache-only (same as the filter above).
    Explicit sort flags are exclusive with raw ``--jql`` (the raw query owns its ``ORDER BY``).
    """
    has_range = bool(assigned_from or assigned_to)
    has_dates = bool(created_from or created_to or updated_from or updated_to)
    has_status = bool(status_category or status or exclude_status or open_only)
    has_project = bool(project or exclude_project)
    has_sort = sort is not None or asc or desc
    has_status_category_changed = bool(status_category_changed_from or status_category_changed_to)
    field, descending = _resolve_sort(sort, asc, desc)
    sort_is_status_category_changed = field == "status-category-changed"
    # The raw query owns the whole search (including its ORDER BY), so a date/assignee-history/
    # status/project/sort/status-category-changed filter alongside it would be dropped — raise
    # instead. (A plain --assignee/--org IS subsumed by --jql and ignored; only the explicit
    # filters, which the user clearly wants applied, error.)
    if jql and (
        has_range
        or has_dates
        or has_status
        or has_project
        or has_sort
        or has_status_category_changed
    ):
        raise JiraHelperError(
            "--jql cannot be combined with --created-*/--updated-*/--status-category-changed-*/"
            "--assigned-*/--status*/--project/--exclude-project/--sort/--asc/--desc; the raw "
            "query owns the whole search (put ORDER BY in the JQL)"
        )
    # --open is the statusCategory != Done shorthand; pairing it with an explicit
    # --status-category is the same axis (a contradictory combo would silently return empty).
    if open_only and status_category:
        raise JiraHelperError(
            "--open and --status-category are the same axis; use one "
            "(--open is shorthand for statusCategory != Done)"
        )

    # #79: a status-category-changed filter or that sort is CACHE-ONLY (the column exists
    # only locally; Jira has no equivalent JQL field). Route it off the cache, and reject
    # the combinations the cache can't serve, rather than silently returning wrong results.
    if has_status_category_changed or sort_is_status_category_changed:
        return _status_category_changed_list(
            assignee=assignee,
            org=org,
            jql=jql,
            no_cache=no_cache,
            has_range=has_range,
            has_dates=has_dates,
            has_status=has_status,
            status_category_changed_from=status_category_changed_from,
            status_category_changed_to=status_category_changed_to,
            created_from=created_from,
            created_to=created_to,
            updated_from=updated_from,
            updated_to=updated_to,
            project=project,
            exclude_project=exclude_project,
            roots=roots,
            paths=paths,
            field=field,
            descending=descending,
            cache_path=cache_path,
            config_path=config_path,
        )

    # F010 cutover: cache-backed roots for the pure assignee/org case. Raw JQL, a date/
    # assigned range, or a status filter can't be evaluated by the cache → live. A project
    # filter is output-side (post-traversal), but is kept on the live path too (has_project
    # below) so its effective-root resolution matches the --no-cache walk.
    cache_eligible = (
        not no_cache
        and not jql
        and not has_dates
        and not has_range
        and not has_status
        and not has_project
    )
    # Single exit: each branch assigns `result`, then the output-side project filter (F047)
    # is applied once. `result is None` (not falsy) gates the live path so a populated cache
    # legitimately returning [] is committed, not retried live.
    result: list[Any] | None = None
    if roots and cache_eligible:
        ids = _resolve_ids(assignee, org, config_path)
        if ids and cache.is_populated(cache_path=cache_path, config_path=config_path):
            if paths:
                result = _root_paths_from_cache(
                    ids,
                    cache_path=cache_path,
                    config_path=config_path,
                    field=field,
                    descending=descending,
                )
            else:
                result = _roots_from_cache(
                    ids,
                    cache_path=cache_path,
                    config_path=config_path,
                    field=field,
                    descending=descending,
                )

    if result is None:
        from .client import JiraClient  # local import: keep module import-light / cycle-free

        with JiraClient.from_config(config_path=config_path, profile=profile) as client:
            if jql:
                seeds = _search(client, jql, with_links=roots)
            else:
                ids = _resolve_ids(assignee, org, config_path)
                date_clauses = _date_clauses(created_from, created_to, updated_from, updated_to)
                # Status filters refine an existing bound — they're appended to every search
                # but don't, by themselves, satisfy the "needs a filter" gate below (gated on
                # date_clauses), so a bare --status-* won't trigger an unbounded scan.
                # (--project/--exclude-project are applied post-traversal, not in the JQL —
                # see _filter_by_project.)
                filter_clauses = date_clauses + _status_clauses(
                    status_category, status, exclude_status, open_only
                )
                if has_range and not ids:
                    raise JiraHelperError(
                        "issue list --assigned-from/--assigned-to needs --assignee or --org "
                        "(a value to match in the assignee change history)"
                    )
                if not ids and not date_clauses:
                    raise JiraHelperError(
                        "list needs a filter: --assignee, --org, --jql, or a "
                        "--created-*/--updated-* range (--status-*/--open/--project/"
                        "--exclude-project refine an existing filter)"
                    )
                order_by = _order_by(field, descending)
                if not ids:
                    seeds = _search(
                        client,
                        _compose_jql([], filter_clauses, order_by=order_by),
                        with_links=roots,
                    )
                else:
                    # Chunk the assignee ids into independent searches, dispatched
                    # concurrently (#65 — each batch is its own JQL search + serial
                    # pagination). parallel_map returns batch results in INPUT order, so the
                    # merge below sees the same order the serial loop did; merge by key and
                    # re-sort across batches (each batch is JQL-ordered, but the union needs a
                    # single sort). With an assigned-range, each chunk becomes an `assignee
                    # WAS IN (...)` historical clause replacing the current-assignee equality.
                    def _search_batch(batch: list[str]) -> list[Issue]:
                        clause = (
                            _assigned_clause(batch, assigned_from, assigned_to)
                            if has_range
                            else None
                        )
                        return _search(
                            client,
                            _compose_jql(
                                batch, filter_clauses, assignee_clause=clause, order_by=order_by
                            ),
                            with_links=roots,
                        )

                    # Workers only read closure vars + return fresh lists; `merged` is mutated
                    # solely here in the parent thread after each batch result arrives in order.
                    merged: dict[str, Issue] = {}
                    for batch_issues in parallel_map(_search_batch, _chunks(ids, _ASSIGNEE_BATCH)):
                        for issue in batch_issues:
                            merged.setdefault(issue["key"], issue)
                    seeds = _sort_issues([*merged.values()], field, descending)
            if roots:
                rules, manual = rule_lib.load(config_path=config_path)
                if paths:
                    result = _collapse_to_root_paths(
                        client, seeds, rules, manual, field=field, descending=descending
                    )
                else:
                    result = _collapse_to_roots(
                        client, seeds, rules, manual, field=field, descending=descending
                    )
            else:
                result = seeds
    return _filter_by_project(result, project, exclude_project)


def roots(
    *,
    assignee: list[str] | None = None,
    org: list[str] | None = None,
    jql: str | None = None,
    created_from: str | None = None,
    created_to: str | None = None,
    updated_from: str | None = None,
    updated_to: str | None = None,
    status_category_changed_from: str | None = None,
    status_category_changed_to: str | None = None,
    assigned_from: str | None = None,
    assigned_to: str | None = None,
    status_category: list[str] | None = None,
    status: list[str] | None = None,
    exclude_status: list[str] | None = None,
    open_only: bool = False,
    project: list[str] | None = None,
    exclude_project: list[str] | None = None,
    paths: bool = False,
    sort: str | None = None,
    asc: bool = False,
    desc: bool = False,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> list[Issue]:
    """F006: the root issues of an assignee/org set — sugar for ``list(..., roots=True)``.

    A complete pass-through to :func:`list` with ``roots=True`` hardcoded: every
    refinement filter ``list`` accepts is forwarded unchanged — the people set
    (``assignee``/``org``), raw ``jql``, the date ranges (``created``/``updated``/
    ``assigned`` ``_from``/``_to``), the cache-only ``status_category_changed`` ``_from``/``_to``,
    the status filters (``status_category``/``status``/``exclude_status``/``open_only``), the
    project filters (``project``/``exclude_project``), and sort (``sort``/``asc``/``desc``) —
    so ``roots(...)`` is byte-for-byte ``list(..., roots=True)``. ``list``'s own guards
    (``--jql`` exclusivity, the standalone-filter gate, same-axis conflicts, the
    status-category-changed cache-only rules) therefore apply identically; see :func:`list`
    for the filter semantics. For ``roots`` both the project filter and the
    status-category-changed bound key on each result's *effective root*.

    ``paths=True`` returns the root→…→assigned forest instead of the flat roots (the
    ``--verbose`` view).

    Example:
        jira-helper issue roots --org 플랫폼개발실 --open --project PROJA
        jira-helper issue roots --assignee alice --updated-from -1w --verbose
    Example output:
        PROJA-50 — Epic: Auth revamp [In Progress]
    """
    return list(
        assignee=assignee,
        org=org,
        jql=jql,
        created_from=created_from,
        created_to=created_to,
        updated_from=updated_from,
        updated_to=updated_to,
        status_category_changed_from=status_category_changed_from,
        status_category_changed_to=status_category_changed_to,
        assigned_from=assigned_from,
        assigned_to=assigned_to,
        status_category=status_category,
        status=status,
        exclude_status=exclude_status,
        open_only=open_only,
        project=project,
        exclude_project=exclude_project,
        roots=True,
        paths=paths,
        sort=sort,
        asc=asc,
        desc=desc,
        profile=profile,
        no_cache=no_cache,
        cache_path=cache_path,
        config_path=config_path,
    )


def tree(
    key: str,
    *,
    sort: str | None = None,
    asc: bool = False,
    desc: bool = False,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> dict[str, Any]:
    """F006: the effective hierarchy around KEY (native parents + virtual rules).

    Climbs to KEY's effective root, then expands the subtree below it via **native**
    children (``parent = X``), explicit ``manual_parents`` edges, and the
    virtual-ancestor edges discovered on the way up (so KEY always appears in its
    own tree even when a conditional rule set its parent). Each node is annotated
    with its effective parent + the rule that set it. Conditional-rule virtual
    *descendants* of nodes off the climb path aren't enumerable on the live walk
    without a full index — so when the cache is populated this reads from it instead
    (recursive CTE over ``effective_parent``, which *is* that index). The live walk
    (below) is the fallback for an empty/missing cache, ``--no-cache``, or a KEY not
    yet synced: up-walk virtual-aware, down-walk native + manual + the climbed path.

    ``sort``/``asc``/``desc`` (F046) order siblings within each level (default ``created``
    desc; key sorts naturally). The live walk's native children are in memo with full
    fields; rare manual/climb-edge children sort by key only. ``--sort status-category-changed``
    (#79) is cache-only — the live walk has no ``status_category_changed_at`` — so it raises on
    ``--no-cache`` or an unsynced KEY rather than silently sorting by nothing.
    """
    field, descending = _resolve_sort(sort, asc, desc)
    if not no_cache:
        cached = _tree_from_cache(
            key, cache_path=cache_path, config_path=config_path, field=field, descending=descending
        )
        if cached is not None:
            return cached
    if field == "status-category-changed":
        raise JiraHelperError(
            "issue tree --sort status-category-changed is cache-only; drop --no-cache and sync KEY "
            "into the cache with `jira-helper sync run`"
        )

    from .client import JiraClient

    rules, manual = rule_lib.load(config_path=config_path)
    manual_children: dict[str, list[str]] = {}
    for child, parent in manual.items():
        manual_children.setdefault(parent, []).append(child)

    with JiraClient.from_config(config_path=config_path, profile=profile) as client:
        fetch, memo = _node_fetcher(client)
        needs = rule_lib._rules_need_link_closure(rules)

        # 1. climb to the effective root (recording the virtual edges we traversed)
        root, climb_children = _climb_to_root(fetch, key, rules, manual)
        root_key = root["key"]

        # 2. expand down: native children + manual edges + climbed path (bounded, cycle-guarded)
        visited: set[str] = set()
        count = 1

        def build(k: str) -> dict[str, Any]:
            nonlocal count
            visited.add(k)
            n = fetch(k)
            n.setdefault("linked_roots", _linked_roots_for(n, fetch, needs_closure=needs))
            parent, source = rule_lib.effective_parent_of_node(n, rules, manual)
            out: dict[str, Any] = {
                "key": n["key"],
                "summary": n.get("summary"),
                "status": n.get("status"),
                "status_category": n.get("status_category"),
                "issue_type": n.get("issue_type"),
                "effective_parent": parent,
                "source": source,
                "children": [],
            }
            child_keys: list[str] = []
            if count < _TREE_MAX_NODES:
                for c in _search(
                    client, f"parent = {_jql_quote(k)} ORDER BY created ASC", with_links=True
                ):
                    memo.setdefault(c["key"], c)
                    child_keys.append(c["key"])
                child_keys.extend(manual_children.get(k, []))
                child_keys.extend(climb_children.get(k, []))
            ordered = sorted(
                dedup(child_keys),
                key=lambda ck: _sort_value(memo.get(ck) or {"key": ck}, field),
                reverse=descending,
            )
            for ck in ordered:
                if ck in visited or count >= _TREE_MAX_NODES:
                    continue
                count += 1
                out["children"].append(build(ck))
            return out

        return build(root_key)


def fetch_node(
    key: str,
    *,
    profile: str | None = None,
    config_path: str | None = None,
    needs_closure: bool = False,
) -> Issue:
    """One issue with its linked-issue keys + collapsed ``linked_roots`` (for ``rule resolve``).

    Climbs the links' native parents so a cache-miss ``rule test`` collapses + excludes the
    issue's own descendants the same way the cache path does (see :func:`_linked_roots_for`).
    *needs_closure* (set by ``rule.resolve`` when a ``linked`` / ``linked_count`` rule exists)
    enables the single-link climb so a lone self-child link is excluded live too (A1-plus).
    """
    from .client import JiraClient

    with JiraClient.from_config(config_path=config_path, profile=profile) as client:
        fetch, _ = _node_fetcher(client)
        node = fetch(key)
        node.setdefault("linked_roots", _linked_roots_for(node, fetch, needs_closure=needs_closure))
        return node


def get(
    key: str,
    *,
    profile: str | None = None,
    no_cache: bool = False,
    cache_path: str | None = None,
    config_path: str | None = None,
) -> Issue:
    """F004: one issue's fields (live)."""
    from .client import JiraClient

    with JiraClient.from_config(config_path=config_path, profile=profile) as client:
        raw = client.get(f"/issue/{key}", fields=",".join(_FIELDS))
    return _parse_issue(raw or {})  # tolerate an empty body
