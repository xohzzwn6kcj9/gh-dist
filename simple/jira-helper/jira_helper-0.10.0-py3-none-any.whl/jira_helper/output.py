"""Output rendering: human-readable by default, ``--json`` for scripting.

Pure and Typer-free so library callers can render without the CLI. The CLI
passes the resolved ``--json`` flag down as ``as_json``. Richer table rendering
lands with the features that need it; this is a minimal, dependable baseline.
"""

from __future__ import annotations

import json
from typing import Any


def to_json(data: Any) -> str:
    """Serialize *data* as pretty UTF-8 JSON (non-serializable values via ``str``)."""
    return json.dumps(data, indent=2, ensure_ascii=False, default=str)


def to_human(data: Any) -> str:
    """Render *data* as a plain, human-readable string."""
    if data is None:
        return ""
    if isinstance(data, str):
        return data
    if isinstance(data, dict):
        return "\n".join(f"{k}: {v}" for k, v in data.items())
    if isinstance(data, (list, tuple)):
        return _table(list(data))
    return str(data)


def _cell(value: Any) -> str:
    return "" if value is None else str(value)


def _table(rows: list) -> str:
    """Render a list of uniform dicts as an aligned table; else one item per line."""
    if not rows:
        return ""
    if not all(isinstance(r, dict) for r in rows):
        return "\n".join(_cell(r) for r in rows)
    columns = list(dict.fromkeys(key for row in rows for key in row))  # union, first-seen order
    widths = {c: max(len(c), *(len(_cell(r.get(c))) for r in rows)) for c in columns}
    lines = ["  ".join(c.ljust(widths[c]) for c in columns)]
    lines.append("  ".join("-" * widths[c] for c in columns))
    for row in rows:
        lines.append("  ".join(_cell(row.get(c)).ljust(widths[c]) for c in columns))
    return "\n".join(lines)


def nest_by_parent(rows: list, *, id_key: str = "key", parent_key: str = "parent") -> list:
    """Nest a flat list of issue dicts into a parent→child forest (no extra fetch).

    Each row becomes a node (a shallow copy plus a ``children`` list). A row whose
    ``parent`` is *another row in the set* is attached under it; a row whose parent
    is absent from the set (or ``None``) stays at the top level. Input order is
    preserved at every level. Self-references and pure parent-cycles are tolerated:
    a cycle's members can't sit under any root, so they are surfaced at the top
    level — the forest never silently drops a row. (Native Jira parents form a
    tree, so a cycle only arises from malformed data.)
    """
    nodes = [{**row, "children": []} for row in rows]
    by_id: dict[Any, dict] = {}
    for node in nodes:
        by_id[node.get(id_key)] = node  # last wins on duplicate keys
    roots: list[dict] = []
    for node in nodes:
        parent = by_id.get(node.get(parent_key))
        if parent is not None and parent is not node:
            parent["children"].append(node)
        else:
            roots.append(node)

    placed: set[int] = set()

    def mark(node: dict) -> None:
        if id(node) in placed:
            return
        placed.add(id(node))
        for child in node["children"]:
            mark(child)

    for root in list(roots):
        mark(root)
    for node in nodes:  # promote any node a cycle left unreachable from the roots
        if id(node) not in placed:
            roots.append(node)
            mark(node)
    return roots


def _tree_label(node: dict) -> str:
    """One tree line: ``KEY — summary [status]`` (+ ``(via <rule>)`` for a virtual edge)."""
    label = node.get("key") or ""
    if node.get("summary"):
        label += f" — {node['summary']}"
    if node.get("status"):
        label += f" [{node['status']}]"
    source = node.get("source")
    if source and source != "native":
        label += f"  (via {source})"
    return label


def format_tree(nodes: Any) -> str:
    """Render a nested node — or a forest of them — as an indented tree.

    Accepts either a single ``{"key", "summary", "status", "source"?, "children"}``
    node (the ``issue tree`` shape) or a list of such nodes (a forest, e.g. the
    ``nest_by_parent`` result). Depth is two spaces per level; a malformed cycle is
    rendered once and not re-descended.
    """
    roots = nodes if isinstance(nodes, list) else [nodes]
    lines: list[str] = []
    rendered: set[int] = set()

    def walk(node: dict, depth: int) -> None:
        if id(node) in rendered:  # guard against a malformed cycle in the input
            return
        rendered.add(id(node))
        lines.append("  " * depth + _tree_label(node))
        for child in node.get("children", []):
            walk(child, depth + 1)

    for root in roots:
        walk(root, 0)
    return "\n".join(lines)


def render(data: Any, *, as_json: bool = False) -> None:
    """Print *data* to stdout as JSON (``as_json=True``) or a human view."""
    print(to_json(data) if as_json else to_human(data))
