"""F006 — virtual-parent rules: a gitignored ``rules.yaml`` + a generic engine.

Conditional rules (first-match-wins) over the v1 matcher vocabulary
(``project`` / ``issue_type`` / ``linked_count``) with the ``linked`` /
``summary_key`` parent strategies, plus one-off ``manual_parents`` edges. The
engine is generic; company project keys live only in the user's local
``rules.yaml`` (never the repo).

``linked_count`` counts (and the ``linked`` strategy collapses) the *external* link
set — the issue's links with its OWN native descendants (and self-links) removed (see
:func:`_external_linked_keys`) — so an issue is never matched on, nor parented under,
its own subtree. A builder precomputes that set (it needs each link's native chain); when
absent the engine falls back to the raw links (the legacy behavior).

Resolution precedence for an issue's *effective* parent (``effective_parent``):

1. a ``manual_parents`` edge for the key — an explicit one-off override, always wins;
2. the first conditional rule whose ``when`` matches AND that is applicable
   (``override: true`` OR the issue has no native parent) AND whose ``parent``
   strategy yields a key (first-match-wins);
3. the issue's native Jira parent;
4. otherwise none → the issue is a root.

The pure ``effective_parent`` core is shared with ``issue`` (roots / tree
traversal); ``resolve`` is its live, single-issue wrapper (``rule test``). Store
I/O mirrors the account / org YAML stores.
"""

from __future__ import annotations

import builtins
import re
from pathlib import Path
from typing import Any

import yaml

from . import cache, config
from .errors import ConfigError

RULES_FILENAME = "rules.yaml"
_RULES_KEY = "virtual_parent_rules"
_MANUAL_KEY = "manual_parents"

# The fixed, tested v1 vocabulary (``validate`` flags anything outside it).
_WHEN_MATCHERS = frozenset({"project", "issue_type", "linked_count"})
_PARENT_STRATEGIES = frozenset({"linked", "summary_key"})

Rule = dict[str, Any]

# ``summary_key`` strategy: the parent is the issue key in the summary's *leading*
# ``[KEY]`` mention. ``_LEADING_BRACKETS`` captures the run of bracketed tags at the
# very start (whitespace-flexible, possibly several — e.g. ``[urgent][PROJA-1] …``);
# ``_ISSUE_KEY`` then keeps only the bracket contents that are themselves issue keys.
_ISSUE_KEY = re.compile(r"[A-Z][A-Z0-9_]*-\d+")
_LEADING_BRACKETS = re.compile(r"^\s*((?:\[[^\[\]]*\]\s*)+)")
_BRACKET_CONTENT = re.compile(r"\[([^\[\]]*)\]")


def _summary_parent_key(summary: str | None) -> str | None:
    """The parent key from a summary's *leading* ``[KEY]`` mention (else ``None``).

    Scans only the run of bracketed tags at the very start of the summary — so
    ``[PROJA-1] fix`` resolves but ``fix [PROJA-1]`` (not leading) and ``PROJA-1 fix``
    (no bracket) do not. Whitespace is flexible (``[ PROJA-1 ]``) and non-key tags are
    skipped (``[urgent][PROJA-1]`` → ``PROJA-1``). Returns the key only when exactly
    one *distinct* key sits in that leading run; 0 keys or 2+ distinct keys (ambiguous)
    → ``None`` → the resolver falls through to native parent / root.
    """
    if not summary:
        return None
    lead = _LEADING_BRACKETS.match(summary)
    if not lead:
        return None
    keys = [
        m.group(0)
        for content in _BRACKET_CONTENT.findall(lead.group(1))
        if (m := _ISSUE_KEY.fullmatch(content.strip()))
    ]
    uniq = [*dict.fromkeys(keys)]
    return uniq[0] if len(uniq) == 1 else None


def _collapse_linked_roots(
    linked_keys: list[str], native_parent: dict[str, str | None]
) -> list[str]:
    """The distinct "top within the linked set" of each linked key (native climb).

    For each linked key, climb its NATIVE-parent chain (via *native_parent*, which the
    caller must populate for the linked keys AND every ancestor on their chains) and keep
    the HIGHEST ancestor that is itself a linked key; a key with no in-set ancestor is its
    own top. Returns the distinct tops (first-seen order). Pure + acyclic — native parents
    never depend on the rule engine, and a per-chain ``seen`` set guards a hand-edited
    cycle; an ancestor missing from *native_parent* stops that climb (dangling-tolerant).

    This generalizes ``linked``'s single-link rule: links that all belong to one epic's
    native subtree collapse to that one epic. A single link, or links with no shared
    in-set ancestor, are each their own top — so those cases are unchanged.
    """
    in_set = set(linked_keys)
    tops: list[str] = []
    for key in linked_keys:
        top, cur, seen = key, key, set()
        while cur is not None and cur not in seen:
            seen.add(cur)
            if cur in in_set:
                top = cur
            cur = native_parent.get(cur)
        tops.append(top)
    return [*dict.fromkeys(tops)]


def _native_descends_from(key: str, ancestor: str, native_parent: dict[str, str | None]) -> bool:
    """True iff *ancestor* is a PROPER native ancestor of *key* (climb *key* up to it).

    Climbs *key*'s ``native_parent`` chain — starting at ``native_parent[key]`` so *key* is
    never treated as its own ancestor — and returns True the moment *ancestor* is reached. A
    per-chain ``seen`` set guards a hand-edited native cycle; an ancestor missing from
    *native_parent* stops the climb (dangling-tolerant → False, i.e. "not a known descendant
    → keep"). Pure + native-only, mirroring :func:`_collapse_linked_roots`'s climb.
    """
    cur, seen = native_parent.get(key), set()
    while cur is not None and cur not in seen:
        if cur == ancestor:
            return True
        seen.add(cur)
        cur = native_parent.get(cur)
    return False


def _external_linked_keys(
    key: str, linked_keys: list[str], native_parent: dict[str, str | None]
) -> list[str]:
    """*linked_keys* minus *key*'s own native descendants (and any self-link); order-preserving.

    The "external" linked set: a link that is *key*'s own native child / descendant — or
    *key* itself — is dropped, so the ``linked_count`` matcher counts only OUTWARD links and
    the ``linked`` strategy never collapses to (nor parents *key* under) its own subtree.
    Pure; descendant is by NATIVE parent only (see :func:`_native_descends_from`).
    Under-excludes when a link's native chain is not fully present in *native_parent*
    (eventually consistent — the cache fills it after a sync, same shape as the collapse).
    """
    return [k for k in linked_keys if k != key and not _native_descends_from(k, key, native_parent)]


def _rules_need_link_closure(rules: list[Rule]) -> bool:
    """True if any rule uses the ``linked`` strategy OR a ``linked_count`` matcher.

    Both need each issue's native subtree cached during ``sync``: ``linked`` to collapse a
    link set to its root, ``linked_count`` to compute the external count (own-descendant
    exclusion). The single gate shared by ``sync``'s closure widening + post-closure
    recompute so the two never drift, and by the live builder's single-link exclusion.
    """
    return any(
        r.get("parent") == "linked" or "linked_count" in (r.get("when") or {}) for r in rules
    )


def path(*, config_path: str | None = None) -> Path:
    """Resolve the rules.yaml location (beside the config)."""
    return config.config_dir(config_path) / RULES_FILENAME


# --- store I/O (edges) --------------------------------------------------------


def _read(config_path: str | None) -> tuple[list[Rule], list[dict[str, str]]]:
    """Load (conditional rules, manual edges) from rules.yaml (empties if absent)."""
    p = path(config_path=config_path)
    if not p.exists():
        return [], []
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    if not isinstance(data, dict):
        return [], []
    rules = data.get(_RULES_KEY) or []
    manual = data.get(_MANUAL_KEY) or []
    return (
        rules if isinstance(rules, builtins.list) else [],
        manual if isinstance(manual, builtins.list) else [],
    )


def _write(config_path: str | None, rules: list[Rule], manual: list[dict[str, str]]) -> Path:
    p = path(config_path=config_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    # sort_keys=False keeps authored rule order (first-match-wins is order-sensitive).
    p.write_text(
        yaml.safe_dump(
            {_RULES_KEY: rules, _MANUAL_KEY: manual}, sort_keys=False, allow_unicode=True
        ),
        encoding="utf-8",
    )
    return p


def _manual_index(manual: list[dict[str, str]]) -> dict[str, str]:
    """child → parent map from the manual edges.

    First edge for a child wins — matching ``add``'s first-match upsert and
    ``validate``'s "first is canonical, the rest are ``duplicate_child``" so the
    resolver, the writer, and the linter all agree on which edge governs.
    """
    index: dict[str, str] = {}
    for e in manual:
        child, parent = e.get("child"), e.get("parent")
        if child and parent:
            index.setdefault(child, parent)
    return index


def load(*, config_path: str | None = None) -> tuple[list[Rule], dict[str, str]]:
    """Parsed conditional rules + a child→parent manual-edge index (the engine inputs)."""
    rules, manual = _read(config_path)
    return rules, _manual_index(manual)


# --- pure resolution engine (no I/O) -----------------------------------------


def _matches(
    when: dict[str, Any], *, project: str | None, issue_type: str | None, linked_count: int
) -> bool:
    """True when every present v1 matcher equals the issue's attribute."""
    if "project" in when and when["project"] != project:
        return False
    if "issue_type" in when and when["issue_type"] != issue_type:
        return False
    if "linked_count" in when and when["linked_count"] != linked_count:
        return False
    return True


def _apply_strategy(
    strategy: Any,
    *,
    linked_keys: list[str],
    summary: str | None,
    linked_roots: list[str] | None = None,
) -> str | None:
    """Virtual parent key for a strategy (``None`` = unresolved).

    ``linked`` = the single issue the links collapse to — *linked_roots* (the distinct
    native-subtree roots of the links, precomputed by the caller) when provided, else the
    raw *linked_keys* (the legacy ``len == 1`` behavior). ``summary_key`` = the key in the
    summary's leading ``[KEY]`` mention (see :func:`_summary_parent_key`).
    """
    if strategy == "linked":
        roots = linked_keys if linked_roots is None else linked_roots
        uniq = [*dict.fromkeys(roots)]
        return uniq[0] if len(uniq) == 1 else None
    if strategy == "summary_key":
        return _summary_parent_key(summary)
    return None


def effective_parent(
    *,
    key: str,
    project: str | None,
    issue_type: str | None,
    native_parent: str | None,
    linked_keys: list[str] | None,
    rules: list[Rule],
    manual: dict[str, str],
    summary: str | None = None,
    linked_roots: list[str] | None = None,
    external_linked_keys: list[str] | None = None,
) -> tuple[str | None, str | None]:
    """The effective parent of an issue + the source that set it.

    Returns ``(parent_key, source)`` where *source* is the firing rule's ``name``,
    ``"manual"``, ``"native"``, or ``None`` (a root). See the module docstring for
    the precedence. Pure — callers supply the issue's attributes + the rule set.

    *external_linked_keys* (the precomputed link set with *key*'s own native descendants /
    self-links removed) drives BOTH the ``linked_count`` matcher (it counts external links,
    not the raw total) AND the ``linked`` collapse — so an issue is never matched on, nor
    parented under, its own subtree. When ``None`` (no native map available) it falls back to
    the raw *linked_keys*, the legacy behavior. A builder supplies it (and a *linked_roots*
    collapsed from the SAME external set); see :func:`_external_linked_keys`.
    """
    links = linked_keys or []
    external = links if external_linked_keys is None else external_linked_keys
    # Every path self-guards (parent != key): a self-edge from a hand-edited store
    # is treated as "no parent" rather than declaring an issue its own parent.
    if manual.get(key) and manual[key] != key:
        return manual[key], "manual"
    for rule in rules:
        when = rule.get("when") or {}
        if not _matches(when, project=project, issue_type=issue_type, linked_count=len(external)):
            continue
        if native_parent and not rule.get("override", False):
            continue  # a non-override rule only fills an empty slot
        parent = _apply_strategy(
            rule.get("parent"), linked_keys=external, summary=summary, linked_roots=linked_roots
        )
        if parent and parent != key:
            return parent, rule.get("name") or "(unnamed rule)"
    if native_parent and native_parent != key:
        return native_parent, "native"
    return None, None


def effective_parent_of_node(
    node: dict[str, Any], rules: list[Rule], manual: dict[str, str]
) -> tuple[str | None, str | None]:
    """``effective_parent`` over an issue *node* dict (the shape ``issue``/cache emit).

    The single place the node-dict → engine-args mapping lives, shared by ``issue``
    traversal and ``resolve`` so the two never drift.
    """
    return effective_parent(
        key=node["key"],
        project=node.get("project"),
        issue_type=node.get("issue_type"),
        native_parent=node.get("parent"),
        linked_keys=node.get("linked_keys"),
        rules=rules,
        manual=manual,
        summary=node.get("summary"),
        linked_roots=node.get("linked_roots"),
        external_linked_keys=node.get("external_linked_keys"),
    )


# --- public API ---------------------------------------------------------------


def list(*, config_path: str | None = None) -> dict[str, Any]:
    """F006: the parsed conditional rules + manual edges (as stored)."""
    rules, manual = _read(config_path)
    return {_RULES_KEY: rules, _MANUAL_KEY: manual}


def add(child: str, parent: str, *, config_path: str | None = None) -> dict[str, str]:
    """F006: append/update a manual parent edge (child → parent; upsert by child)."""
    if child == parent:
        raise ConfigError(f"a manual edge cannot point an issue at itself ({child})")
    rules, manual = _read(config_path)
    for edge in manual:
        if edge.get("child") == child:
            edge["parent"] = parent
            break
    else:
        manual.append({"child": child, "parent": parent})
    _write(config_path, rules, manual)
    return {"child": child, "parent": parent}


def remove(child: str, *, config_path: str | None = None) -> bool:
    """F006: drop the manual edge for *child*; return whether one was removed."""
    rules, manual = _read(config_path)
    kept = [e for e in manual if e.get("child") != child]
    if len(kept) == len(manual):
        return False
    _write(config_path, rules, kept)
    return True


def _node_from_cache(
    key: str, *, cache_path: str | None, config_path: str | None
) -> dict[str, Any] | None:
    """Reconstruct KEY's rule-engine node from cached columns + ``issue_link`` (None if
    not cached). ``linked_keys`` unions both link directions to match ``_linked_keys``."""
    if not cache.path(cache_path=cache_path, config_path=config_path).exists():
        return None
    conn = cache.connect(cache_path=cache_path, config_path=config_path)
    try:
        row = conn.execute(
            "SELECT project, issue_type, native_parent, summary FROM issue WHERE key = ?", (key,)
        ).fetchone()
        if row is None:
            return None
        return cache.engine_node(
            conn,
            key=key,
            project=row["project"],
            issue_type=row["issue_type"],
            native_parent=row["native_parent"],
            summary=row["summary"],
        )
    finally:
        conn.close()


def resolve(
    key: str,
    *,
    profile: str | None = None,
    config_path: str | None = None,
    cache_path: str | None = None,
    no_cache: bool = False,
) -> dict[str, Any]:
    """F006 (``rule test``): the effective parent for KEY + which rule fired.

    Reads KEY from the cache when populated (F010 cutover); otherwise fetches it live
    (also the fallback for a not-yet-synced KEY). ``--no-cache`` forces the live read.
    """
    rules, manual = load(config_path=config_path)
    node = None
    if not no_cache:
        node = _node_from_cache(key, cache_path=cache_path, config_path=config_path)
    if node is None:
        from . import issue  # local import: ``issue`` imports us at module load

        node = issue.fetch_node(
            key,
            profile=profile,
            config_path=config_path,
            needs_closure=_rules_need_link_closure(rules),
        )
    parent, source = effective_parent_of_node(node, rules, manual)
    linked = node.get("linked_keys") or []
    external = node.get("external_linked_keys")
    return {
        "key": node["key"],
        "native_parent": node.get("parent"),
        "effective_parent": parent,
        "source": source,
        "linked_keys": linked,
        # The link set the matcher/collapse actually used: own native descendants removed
        # (falls back to the raw links when no native map was available — see effective_parent).
        "external_linked_keys": external if external is not None else linked,
    }


def validate(*, config_path: str | None = None) -> list[dict[str, Any]]:
    """F006: schema + ambiguity + cycle checks ([] = clean). Mirrors ``org validate``."""
    rules, manual = _read(config_path)
    problems: list[dict[str, Any]] = []

    def report(level: str, code: str, where: str, message: str) -> None:
        problems.append({"level": level, "code": code, "rule": where, "message": message})

    seen_names: set[str] = set()
    for i, rule in enumerate(rules):
        name = rule.get("name") or f"#{i}"
        if not rule.get("name"):
            report("error", "missing_name", name, "rule has no name")
        if name in seen_names:
            report("error", "duplicate_name", name, f"duplicate rule name {name!r}")
        seen_names.add(name)
        when = rule.get("when")
        if not isinstance(when, dict) or not when:
            # A rule with no matchers is already broken; don't pile consequential
            # strategy/ambiguity noise on top — report once and move on.
            report("error", "bad_when", name, "rule has no 'when' matchers")
            continue
        for matcher in when:
            if matcher not in _WHEN_MATCHERS:
                report("error", "unknown_matcher", name, f"unknown 'when' matcher {matcher!r}")
        strategy = rule.get("parent")
        if strategy not in _PARENT_STRATEGIES:
            report("error", "unknown_strategy", name, f"unknown parent strategy {strategy!r}")
        # ``parent: linked`` no longer warns on a missing ``linked_count: 1`` guard — it now
        # collapses a set of links that form one native subtree to that single root, so
        # dropping the guard is the supported way to use it on multi-link issues.
        if strategy == "summary_key" and "project" not in when:
            report(
                "warning",
                "broad_summary_key",
                name,
                "parent: summary_key without a 'when' project scans every project's summaries",
            )

    seen_children: set[str] = set()
    for edge in manual:
        child, parent = edge.get("child"), edge.get("parent")
        if not child or not parent:
            report("error", "bad_edge", str(edge), "manual edge needs both 'child' and 'parent'")
            continue
        if child == parent:
            report("error", "self_loop", child, f"manual edge {child!r} points at itself")
        if child in seen_children:
            report("error", "duplicate_child", child, f"duplicate manual edge for {child!r}")
        seen_children.add(child)

    # Exclude self-loops (already reported as `self_loop`) so they aren't
    # double-reported as a `cycle`.
    index = {c: p for c, p in _manual_index(manual).items() if c != p}
    for start in index:
        chain: set[str] = set()
        cur: str | None = start
        while cur is not None:
            if cur in chain:
                report("error", "cycle", start, f"manual parent chain cycles at {cur!r}")
                break
            chain.add(cur)
            cur = index.get(cur)
    return problems
